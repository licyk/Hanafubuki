# Hanafubuki extension SDK

Two crates, unpacked side by side, to depend on by path:

- `hanafubuki-extension-sdk` — `run`, `Handler`, `Host`, `Ui`, and the
  protocol's types re-exported.
- `hanafubuki-extension-protocol` — the method names, params, results,
  `RpcError` and the error codes of the backend protocol.

The SDK is not published on crates.io and the application's repository is not
public. Keep both directories in your project and refer to the SDK by path:

```toml title="Cargo.toml"
[dependencies]
hanafubuki-extension-sdk = { path = "vendor/hanafubuki-extension-sdk" }
serde_json = "1"
```

Each crate builds on its own; the protocol's `schema` feature, which the
application's interface export enables, adds JSON Schema and is not needed by a
backend.
