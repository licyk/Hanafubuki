//! The method registry against `docs/rules/extensions.md`'s permission
//! table of the host API: every host API method is in a row, and every
//! method a row names is in the registry.

use std::collections::BTreeSet;

use hanafubuki_extension_protocol::{Direction, METHODS};

/// The backticked method names (those with a dot) in the first column of
/// the table under "### The host API".
fn table_methods() -> BTreeSet<String> {
    let path = concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../../../docs/rules/extensions.md"
    );
    let document = std::fs::read_to_string(path).unwrap();
    let section = document.split("\n### The host API\n").nth(1).unwrap();
    let section = section.split("\n### ").next().unwrap();
    section
        .lines()
        .filter(|line| line.starts_with('|') && !line.starts_with("| ---"))
        .skip(1)
        .flat_map(|line| {
            let first = line.split('|').nth(1).unwrap_or_default();
            first
                .split('`')
                .skip(1)
                .step_by(2)
                .filter(|name| name.contains('.'))
                .map(str::to_string)
                .collect::<Vec<_>>()
        })
        .collect()
}

#[test]
fn the_permission_table_lists_every_host_api_method() {
    let table = table_methods();
    let registry: BTreeSet<String> = METHODS
        .iter()
        .filter(|spec| spec.direction == Direction::BackendToHost)
        .map(|spec| spec.name.to_string())
        .collect();
    let missing: Vec<_> = registry.difference(&table).collect();
    assert!(missing.is_empty(), "not in the table: {missing:?}");
    let unknown: Vec<_> = table.difference(&registry).collect();
    assert!(unknown.is_empty(), "not in METHODS: {unknown:?}");
}
