//! The instance a provider callback names, on the wire: its id and its
//! components, each `{ path, external }`; `validateSpec` carries one only
//! for an instance that exists. An update check carries it with the
//! instance's values, and its answer reads whatever the backend leaves out.

use hanafubuki_extension_protocol::{
    CheckUpdateParams, CheckUpdateResult, InstallPlanParams, ProviderComponent, ProviderInstance,
    ValidateSpecParams,
};
use serde_json::{json, Map};

#[test]
fn a_plan_names_the_instances_components_with_whether_each_is_external() {
    let params = InstallPlanParams {
        type_id: "com.example:tool".to_string(),
        kind: "reinstall".to_string(),
        recreate_components: ["core".into()].into(),
        values: Map::new(),
        instance: ProviderInstance {
            id: "one".to_string(),
            components: [
                (
                    "core".to_string(),
                    ProviderComponent {
                        path: "/instances/one/core".to_string(),
                        external: false,
                    },
                ),
                (
                    "node".to_string(),
                    ProviderComponent {
                        path: "/opt/node".to_string(),
                        external: true,
                    },
                ),
            ]
            .into(),
        },
    };
    let wire = serde_json::to_value(params).unwrap();
    assert_eq!(wire["recreateComponents"], json!(["core"]));
    assert_eq!(
        wire["instance"],
        json!({
            "id": "one",
            "components": {
                "core": { "path": "/instances/one/core", "external": false },
                "node": { "path": "/opt/node", "external": true },
            },
        })
    );
}

#[test]
fn validate_spec_names_an_instance_only_when_there_is_one() {
    let created = ValidateSpecParams {
        type_id: "com.example:tool".to_string(),
        values: Map::new(),
        instance: None,
    };
    assert!(serde_json::to_value(&created)
        .unwrap()
        .get("instance")
        .is_none());
    // A peer that knows no components still reads.
    let read: ProviderInstance = serde_json::from_value(json!({ "id": "one" })).unwrap();
    assert!(read.components.is_empty());
}

#[test]
fn an_update_check_carries_the_values_and_the_instance_and_its_answer_reads_tolerantly() {
    let params = CheckUpdateParams {
        type_id: "com.example:tool".to_string(),
        values: json!({ "version": "latest" }).as_object().unwrap().clone(),
        instance: ProviderInstance {
            id: "one".to_string(),
            components: Default::default(),
        },
    };
    assert_eq!(
        serde_json::to_value(&params).unwrap(),
        json!({
            "type": "com.example:tool",
            "values": { "version": "latest" },
            "instance": { "id": "one", "components": {} },
        })
    );
    let read: CheckUpdateParams = serde_json::from_value(json!({ "type": "a:b" })).unwrap();
    assert!(read.values.is_empty() && read.instance.id.is_empty());

    let answer: CheckUpdateResult = serde_json::from_value(json!({
        "current": "b4100",
        "latest": "b4200",
        "hasUpdate": true,
        "notes": "faster",
        "channel": "stable",
    }))
    .unwrap();
    assert_eq!(
        answer,
        CheckUpdateResult {
            components: Vec::new(),
            current: Some("b4100".to_string()),
            latest: Some("b4200".to_string()),
            has_update: true,
            notes: Some("faster".to_string()),
        }
    );
    // An answer that says nothing more than that it is current.
    let empty: CheckUpdateResult = serde_json::from_value(json!({})).unwrap();
    assert_eq!(empty, CheckUpdateResult::default());
    assert_eq!(
        serde_json::to_value(&empty).unwrap(),
        json!({ "hasUpdate": false })
    );
}
