//! An instance as `instances.get` answers it, on the wire: its components
//! in a provider callback's shape, each `{ path, external }`.

use hanafubuki_extension_protocol::{InstanceView, ProviderComponent};
use serde_json::json;

#[test]
fn an_instance_names_its_components_with_whether_each_is_external() {
    let view = InstanceView {
        id: "one".to_string(),
        name: "One".to_string(),
        type_id: "com.example:tool".to_string(),
        path: "/instances/one".to_string(),
        running: false,
        components: [
            (
                "core".to_string(),
                ProviderComponent {
                    path: "/instances/one/core".to_string(),
                    external: false,
                },
            ),
            (
                "node".to_string(),
                ProviderComponent {
                    path: "/opt/node".to_string(),
                    external: true,
                },
            ),
        ]
        .into(),
    };
    assert_eq!(
        serde_json::to_value(&view).unwrap(),
        json!({
            "id": "one",
            "name": "One",
            "type": "com.example:tool",
            "path": "/instances/one",
            "running": false,
            "components": {
                "core": { "path": "/instances/one/core", "external": false },
                "node": { "path": "/opt/node", "external": true },
            },
        })
    );
}

#[test]
fn an_instance_from_a_peer_without_components_reads_with_none() {
    let read: InstanceView = serde_json::from_value(json!({
        "id": "one",
        "name": "One",
        "type": "com.example:tool",
        "path": "/instances/one",
        "running": true,
    }))
    .unwrap();
    assert!(read.running);
    assert!(read.components.is_empty());
}
