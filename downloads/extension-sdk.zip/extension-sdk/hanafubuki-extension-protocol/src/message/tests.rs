use serde_json::json;

use super::*;
use crate::codes;

#[test]
fn each_kind_round_trips() {
    for message in [
        Message::request(Id::Number(7), "ping", json!({})),
        Message::request(Id::Text("a".to_string()), "host.info", Value::Null),
        Message::notification("event", json!({ "topic": "settings" })),
        Message::response(Id::Number(7), Ok(json!({ "ok": true }))),
        Message::response(
            Id::Number(8),
            Err(RpcError::new(codes::PERMISSION_DENIED, "no")),
        ),
    ] {
        assert_eq!(Message::decode(&message.encode()).unwrap(), message);
    }
}

#[test]
fn unknown_members_are_ignored_and_jsonrpc_is_not_checked() {
    let message = Message::decode(br#"{"id":1,"method":"ping","extra":[1],"jsonrpc":"1.0"}"#);
    assert_eq!(
        message.unwrap(),
        Message::request(Id::Number(1), "ping", Value::Null)
    );
    let response = Message::decode(br#"{"id":1,"jsonrpc":"2.0"}"#).unwrap();
    assert_eq!(response, Message::response(Id::Number(1), Ok(Value::Null)));
}

#[test]
fn an_error_without_an_id_is_a_response_to_no_request() {
    let message =
        Message::decode(br#"{"id":null,"error":{"code":-32700,"message":"parse"}}"#).unwrap();
    assert!(
        matches!(message, Message::Response { id: None, outcome: Err(error) } if error.code == codes::PARSE_ERROR)
    );
}

#[test]
fn what_is_not_a_message_is_refused() {
    for body in [
        &b"not json"[..],
        b"[1, 2]",
        b"{}",
        b"{\"method\": 3}",
        b"{\"id\": {}, \"method\": \"ping\"}",
        b"{\"id\": 1, \"error\": \"broken\"}",
    ] {
        assert!(
            Message::decode(body).is_err(),
            "{}",
            String::from_utf8_lossy(body)
        );
    }
}
