//! Read-only host preferences, also the complete `preferences` event payload.

use serde::{Deserialize, Serialize};

use crate::HostMirrors;

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct HostPreferences {
    /// The configured language: en, zh or auto, as host.info exposes it.
    pub locale: String,
    /// The default instance directory in native form; null before settings load.
    pub instances_dir: Option<String>,
    /// Download mirror policy; null before settings load.
    pub mirrors: Option<HostMirrors>,
    pub network: HostNetworkPreferences,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct HostNetworkPreferences {
    pub proxy_mode: HostProxyMode,
    /// Whether a proxy address is configured, not whether it is active or reachable.
    /// The address and its credentials are never part of this projection.
    pub proxy_configured: bool,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum HostProxyMode {
    #[default]
    System,
    Manual,
    Disabled,
}
