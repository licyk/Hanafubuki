//! A JSON-RPC error and the codes this protocol uses.

use std::fmt;

use serde::{Deserialize, Serialize};
use serde_json::Value;

/// The error codes: JSON-RPC's own, and this protocol's in the range
/// JSON-RPC leaves to servers (`-32000` to `-32099`).
pub mod codes {
    pub const PARSE_ERROR: i64 = -32700;
    pub const INVALID_REQUEST: i64 = -32600;
    pub const METHOD_NOT_FOUND: i64 = -32601;
    pub const INVALID_PARAMS: i64 = -32602;
    pub const INTERNAL_ERROR: i64 = -32603;
    /// The extension was not granted the permission the method needs.
    pub const PERMISSION_DENIED: i64 = -32001;
    /// The call did not get its answer within its bound.
    pub const TIMED_OUT: i64 = -32002;
    /// What the method does failed (a download, a process that would not
    /// start).
    pub const REQUEST_FAILED: i64 = -32003;
    /// The peer is gone: the channel closed before the answer came.
    pub const UNAVAILABLE: i64 = -32004;
    /// Too many of the peer's calls are being answered already.
    pub const BUSY: i64 = -32005;
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct RpcError {
    pub code: i64,
    #[serde(default)]
    pub message: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub data: Option<Value>,
}

impl RpcError {
    pub fn new(code: i64, message: impl Into<String>) -> Self {
        Self {
            code,
            message: message.into(),
            data: None,
        }
    }

    pub fn method_not_found(method: &str) -> Self {
        Self::new(codes::METHOD_NOT_FOUND, format!("no method {method}"))
    }

    pub fn invalid_params(message: impl fmt::Display) -> Self {
        Self::new(codes::INVALID_PARAMS, format!("invalid params: {message}"))
    }

    pub fn permission_denied(message: impl Into<String>) -> Self {
        Self::new(codes::PERMISSION_DENIED, message)
    }

    pub fn failed(message: impl Into<String>) -> Self {
        Self::new(codes::REQUEST_FAILED, message)
    }
}

impl fmt::Display for RpcError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{} ({})", self.message, self.code)
    }
}

impl std::error::Error for RpcError {}
