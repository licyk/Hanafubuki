//! The management catalog through the host API (`tools.list`,
//! `tools.call`): its tools as the catalog describes them, and a call of
//! one. What a tool answers is the catalog's own result, as the
//! application's other callers of the catalog get it.

use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};

/// What a client may assume about a tool.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ToolAnnotations {
    /// Reads only; never asks for confirmation.
    pub read_only: bool,
    /// Removes, replaces or overwrites what the user has.
    pub destructive: bool,
    /// Repeating it with the same arguments has no further effect.
    pub idempotent: bool,
    /// Reaches the network (a Git remote, a registry, a download).
    pub open_world: bool,
}

/// One tool of the management catalog.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ToolDescriptor {
    pub name: String,
    pub title: String,
    /// What it does, what it needs first, and which tool follows it.
    pub description: String,
    /// The `management` level that may call it: `read` or `confirm`.
    pub scope: String,
    pub annotations: ToolAnnotations,
    /// The JSON Schema of its arguments.
    pub input_schema: Map<String, Value>,
    /// It serves the built-in WebUI families' instances only (an instance
    /// of another type is refused, one that adopts a built-in type's
    /// management included).
    pub built_in_only: bool,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ToolsListResult {
    /// Every tool, reads first; a mutation is listed whatever the
    /// extension was granted.
    pub tools: Vec<ToolDescriptor>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["name"])))]
pub struct ToolsCallParams {
    /// A tool's name, as `tools.list` lists it.
    pub name: String,
    /// Its arguments, as its `inputSchema` describes them; none when
    /// absent.
    pub arguments: Value,
}
