//! Wire contracts for the instance types supplied by extensions.

use std::collections::{BTreeMap, BTreeSet};

use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};

/// The instance a provider callback is about.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ProviderInstance {
    pub id: String,
    /// Where each of its type's components is, by name: what a plan's
    /// `{component.<name>}` resolves to.
    pub components: BTreeMap<String, ProviderComponent>,
}

/// One component of a [`ProviderInstance`] or an [`crate::InstanceView`].
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ProviderComponent {
    /// The folder, as the platform writes it.
    pub path: String,
    /// A folder of the user's that the instance does not own: a plan never
    /// empties, replaces or removes it (the host refuses `unpack` and
    /// `git-clone` into it), and nothing deletes it with the instance.
    pub external: bool,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ValidateSpecParams {
    #[serde(rename = "type")]
    pub type_id: String,
    /// The install parameters' values, each its field's kind, after the
    /// host's own checks.
    pub values: Map<String, Value>,
    /// The instance whose values change, when it exists (a reinstall with
    /// new values); absent when one is created.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub instance: Option<ProviderInstance>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ValidateSpecResult {
    /// What is wrong, by parameter; none when the values are good.
    pub issues: BTreeMap<String, String>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct InstallPlanParams {
    #[serde(rename = "type")]
    pub type_id: String,
    /// `install` (a first install or a retry), `reinstall` (repeat installation with optional component rebuilds)
    /// or `update` (a ready instance's).
    pub kind: String,
    /// Component names the host will remove before executing the steps.
    pub recreate_components: BTreeSet<String>,
    pub values: Map<String, Value>,
    pub instance: ProviderInstance,
}

/// An instance's effective configuration for its read-only whole-launch check.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct LaunchPreflightParams {
    #[serde(rename = "type")]
    pub type_id: String,
    pub instance: ProviderInstance,
    pub values: Map<String, Value>,
    pub launch_values: Map<String, Value>,
}

/// The launch choices of the instance currently being edited.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct LaunchOptionsParams {
    #[serde(rename = "type")]
    pub type_id: String,
    pub instance: ProviderInstance,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct LaunchOptionsResult {
    /// Choice values by the launch fields' optionsSource names.
    pub options: BTreeMap<String, Vec<String>>,
}

/// A short maintenance reply, optionally followed by a plan that the host executes.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ManageResult {
    pub notice: Option<String>,
    /// Uses the same step documents as provider.installPlan, under the instance maintenance permit.
    pub steps: Option<Vec<Value>>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct InstallPlanResult {
    /// Steps as a declarative type's `install.steps` are written:
    /// `{ "kind": "write-file", "path": "{component.core}/a", ... }`.
    pub steps: Vec<Value>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct LaunchPlanParams {
    /// The effective values of the instance's separately editable launch form.
    pub launch_values: Map<String, Value>,
    #[serde(rename = "type")]
    pub type_id: String,
    pub role: String,
    pub port: u16,
    pub values: Map<String, Value>,
    pub instance: ProviderInstance,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["argv"])))]
pub struct LaunchPlanResult {
    /// As a declarative server's `command`: placeholders allowed.
    pub argv: Vec<String>,
    pub env: BTreeMap<String, String>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct CheckUpdateParams {
    #[serde(rename = "type")]
    pub type_id: String,
    /// The instance's install parameters' values, as `provider.installPlan`
    /// gets them.
    pub values: Map<String, Value>,
    pub instance: ProviderInstance,
}

/// A component named by the extension's type, with the versions reported by the backend.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ComponentUpdateResult {
    pub name: String,
    pub current: Option<String>,
    pub latest: Option<String>,
    pub has_update: bool,
}

/// What an update check of one instance found. A failed check is an
/// error, which the host records on the instance.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["hasUpdate"])))]
pub struct CheckUpdateResult {
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub components: Vec<ComponentUpdateResult>,
    /// The version installed, as the user reads it.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub current: Option<String>,
    /// The version the type's `update` would install, as the user reads it.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub latest: Option<String>,
    /// An applicable update is available (possibly installed externally): an
    /// instance its values pin to a version has none.
    pub has_update: bool,
    /// Anything more for the user, such as what the update brings.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub notes: Option<String>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ManageParams {
    #[serde(rename = "type")]
    pub type_id: String,
    pub operation: String,
    /// User input after applying the operation form.
    pub values: Map<String, Value>,
    pub instance: ProviderInstance,
}
