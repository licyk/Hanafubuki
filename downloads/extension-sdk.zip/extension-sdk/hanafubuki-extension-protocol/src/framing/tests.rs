use super::*;

fn decode_all(decoder: &mut FrameDecoder) -> Result<Vec<Vec<u8>>, FrameError> {
    let mut frames = Vec::new();
    while let Some(frame) = decoder.next_frame()? {
        frames.push(frame);
    }
    Ok(frames)
}

#[test]
fn a_frame_round_trips() {
    let mut decoder = FrameDecoder::default();
    decoder.push(&encode_frame(br#"{"jsonrpc":"2.0"}"#));
    assert_eq!(
        decode_all(&mut decoder).unwrap(),
        vec![br#"{"jsonrpc":"2.0"}"#.to_vec()]
    );
    assert!(!decoder.has_partial());
}

#[test]
fn frames_arrive_one_byte_at_a_time() {
    let mut stream = encode_frame(b"first");
    stream.extend(encode_frame("second, with ü".as_bytes()));
    let mut decoder = FrameDecoder::default();
    let mut frames = Vec::new();
    for byte in stream {
        decoder.push(&[byte]);
        frames.extend(decode_all(&mut decoder).unwrap());
    }
    assert_eq!(
        frames,
        vec![b"first".to_vec(), "second, with ü".as_bytes().to_vec()]
    );
    assert!(!decoder.has_partial());
}

#[test]
fn several_frames_in_one_read_and_a_partial_one_waits() {
    let mut stream = encode_frame(b"a");
    stream.extend(encode_frame(b"bb"));
    let third = encode_frame(b"ccc");
    stream.extend(&third[..third.len() - 1]);
    let mut decoder = FrameDecoder::default();
    decoder.push(&stream);
    assert_eq!(
        decode_all(&mut decoder).unwrap(),
        vec![b"a".to_vec(), b"bb".to_vec()]
    );
    assert!(decoder.has_partial());
    decoder.push(b"c");
    assert_eq!(decode_all(&mut decoder).unwrap(), vec![b"ccc".to_vec()]);
}

#[test]
fn other_headers_and_their_case_are_accepted() {
    let mut decoder = FrameDecoder::default();
    decoder.push(b"content-length: 2\r\nContent-Type: application/json\r\n\r\n{}");
    assert_eq!(decode_all(&mut decoder).unwrap(), vec![b"{}".to_vec()]);
}

#[test]
fn a_frame_over_the_bound_is_refused_before_its_body_is_read() {
    let mut decoder = FrameDecoder::with_max(8);
    decoder.push(b"Content-Length: 9\r\n\r\n");
    assert_eq!(
        decoder.next_frame(),
        Err(FrameError::TooLarge { length: 9, max: 8 })
    );
    let mut decoder = FrameDecoder::default();
    decoder.push(format!("Content-Length: {}\r\n\r\n", MAX_FRAME_BYTES + 1).as_bytes());
    assert!(matches!(
        decoder.next_frame(),
        Err(FrameError::TooLarge { .. })
    ));
}

#[test]
fn a_frame_at_the_bound_is_read() {
    let mut decoder = FrameDecoder::with_max(4);
    decoder.push(&encode_frame(b"1234"));
    assert_eq!(decode_all(&mut decoder).unwrap(), vec![b"1234".to_vec()]);
}

#[test]
fn bad_headers_are_refused() {
    for stream in [
        &b"Content-Length: two\r\n\r\n"[..],
        b"Content-Type: application/json\r\n\r\n{}",
        b"not a header\r\n\r\n",
        b"Content-Length: -1\r\n\r\n",
        b"Content-Length: 2\xff\r\n\r\n{}",
    ] {
        let mut decoder = FrameDecoder::default();
        decoder.push(stream);
        assert!(
            matches!(decoder.next_frame(), Err(FrameError::BadHeader(_))),
            "{}",
            String::from_utf8_lossy(stream)
        );
    }
}

#[test]
fn headers_without_an_end_are_refused_once_past_their_bound() {
    let mut decoder = FrameDecoder::default();
    decoder.push(b"Content-Length: 2\r\n");
    assert_eq!(decoder.next_frame(), Ok(None));
    decoder.push(&vec![b'x'; MAX_HEADER_BYTES]);
    assert!(matches!(
        decoder.next_frame(),
        Err(FrameError::BadHeader(_))
    ));
}
