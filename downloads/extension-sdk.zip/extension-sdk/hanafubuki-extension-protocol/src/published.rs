//! The MCP tools a backend publishes on the host management MCP server,
//! beside the ones its manifest declares: the ones `initialize` states, and
//! those `tools.register` adds or `tools.unregister` removes while it runs.

use serde::{Deserialize, Serialize};

/// An MCP tool a backend publishes on the host management MCP server:
/// listed by `tools/list` as `ext_<extension>__<name>` and handled by the
/// backend as `service.<name>`. A local name uses ASCII letters, digits,
/// underscores or hyphens; the schema's root is an object.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ToolDeclaration {
    pub name: String,
    pub description: String,
    #[serde(default)]
    pub input_schema: serde_json::Map<String, serde_json::Value>,
}

/// `tools.register`: each tool is added, or replaces one of the backend's
/// (or the manifest's) by name; one that does not read refuses the whole
/// message, and none is registered.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ToolsRegisterParams {
    pub tools: Vec<ToolDeclaration>,
}

/// `tools.unregister`: names removed; a name the backend did not have is
/// ignored. A manifest's tool is not removed: the backend's over it is, and
/// the manifest's is listed again.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ToolsUnregisterParams {
    pub names: Vec<String>,
}
