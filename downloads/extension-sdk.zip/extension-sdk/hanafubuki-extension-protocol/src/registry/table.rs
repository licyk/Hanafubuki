//! The registry's one table: every method of protocol version 1, in both
//! directions.

#[cfg_attr(not(feature = "schema"), allow(unused_imports))]
use crate::{
    event_topics, hooks, method, CheckUpdateParams, CheckUpdateResult, DownloadFetchParams,
    DownloadFetchResult, Event, EventsSubscribeParams, EventsSubscribeResult, FrameCallParams,
    FrameEmitParams, GitCloneParams, GitPullParams, HostInfoResult, InitializeParams,
    InitializeResult, InstallPlanParams, InstallPlanResult, InstanceConfigurationResult,
    InstanceView, InstancesGetParams, InstancesImportParams, InstancesImportResult,
    InstancesOfTypeParams, InstancesResult, InstancesScanParams, InstancesScanResult,
    LaunchOptionsParams, LaunchOptionsResult, LaunchPlanParams, LaunchPlanResult,
    LaunchPreflightParams, LogWriteParams, ManageParams, ManageResult, MigrateParams, NoticeResult,
    PanelActionParams, PanelQueryParams, ProcessCancelParams, ProcessExit, ProcessOutput,
    ProcessRunParams, ProcessRunResult, PythonEnsureParams, PythonEnsureResult, ServersResult,
    ServersStatusParams, ServiceParams, ServicesCallParams, SettingsPatchParams, SettingsResult,
    StoragePathResult, ToolsRegisterParams, ToolsUnregisterParams, UiCallParams, UiEmitParams,
    UiNotifyParams, UiProgressParams, UiPromptParams, UiPromptResult, UiStateParams,
    UiTaskCenterOpenParams, ValidateSpecParams, ValidateSpecResult, WebviewNavigateParams,
    WebviewPageParams, WebviewPagesParams, WebviewPagesResult,
};

use super::{
    notification, to_backend, to_host, Bound, Direction, MethodSpec, Payload, Permission,
    Requirement, ANY_LEVEL, CALL, INSTANCE_TYPES, MANAGE, MANAGEMENT, NOTHING, OWN_TYPES, READ, UI,
};
#[cfg_attr(not(feature = "schema"), allow(unused_imports))]
use crate::tools::{ToolsCallParams, ToolsListResult};
#[cfg_attr(not(feature = "schema"), allow(unused_imports))]
use crate::{
    DiagnosticsCollectResult, HostPreferences, HttpRequestParams, HttpRequestResult,
    RuntimeResolveParams, RuntimeResolveResult, RuntimeStatusParams, RuntimeStatusResult,
};

/// Every method, the host API's first, each direction in the order
/// `docs/extension-protocol.md` lists it.
pub const METHODS: &[MethodSpec] = &[
    to_host(
        method::HOST_INFO,
        "The application's version, locale, platform and instance directory.",
        Payload::Empty,
        typed!(HostInfoResult),
        NOTHING,
    ),
    to_host(
        method::HOST_PREFERENCES,
        "Reads the current locale, default instance directory, mirror policy and network \
         preferences. Contains no proxy address or credentials. Subscribe to preferences \
         for complete snapshots after related settings change; this method is read-only.",
        Payload::Empty,
        typed!(HostPreferences),
        NOTHING,
    ),
    to_host(
        method::RUNTIME_STATUS,
        "Reads existing runtime readiness without preparing tools. Missing modules are unavailable; failed preparation is failed, never ready.",
        typed!(RuntimeStatusParams), typed!(RuntimeStatusResult), NOTHING,
    ),
    to_host(
        method::RUNTIME_RESOLVE,
        "Prepares or waits for the existing runtime authority and returns its executable path. Requires processes; backend stop cancels waiting. Invalid tool is INVALID_PARAMS, refusal PERMISSION_DENIED, preparation failure REQUEST_FAILED.",
        typed!(RuntimeResolveParams), typed!(RuntimeResolveResult),
        Permission { requires: &[Requirement::Processes], text: "processes" },
    ),
    MethodSpec {
        notification: true,
        ..to_host(
            method::LOG_WRITE,
            "Writes a line to its backend log.",
            typed!(LogWriteParams),
            Payload::Empty,
            NOTHING,
        )
    },
    to_host(
        method::SETTINGS_GET,
        "Its own settings' values.",
        Payload::Empty,
        typed!(SettingsResult),
        NOTHING,
    ),
    to_host(
        method::SETTINGS_PATCH,
        "Patches only this extension's declared settings; null unsets an override. \
         Returns canonical values and emits its settings event after persistence. \
         An undeclared field or invalid value refuses the whole write (REQUEST_FAILED); \
         malformed params are INVALID_PARAMS. Needs no permission and takes no extension id.",
        typed!(SettingsPatchParams),
        typed!(SettingsResult),
        NOTHING,
    ),
    to_host(
        method::STORAGE_PATH,
        "Its data directory.",
        Payload::Empty,
        typed!(StoragePathResult),
        NOTHING,
    ),
    to_host(
        method::INSTANCES_LIST,
        "Every instance, read only.",
        Payload::Empty,
        typed!(InstancesResult),
        Permission {
            requires: &[Requirement::Instances { levels: READ }],
            text: "`instances = read` or `all`",
        },
    ),
    to_host(
        method::INSTANCES_GET,
        "One instance, as `instances.list` lists it.",
        typed!(InstancesGetParams),
        typed!(InstanceView),
        Permission {
            requires: &[Requirement::Instances { levels: READ }],
            text: "`instances = read` or `all`",
        },
    ),
    to_host(
        method::INSTANCES_CONFIGURATION,
        "The declared non-secret install and launch fields of one instance of its own types.",
        typed!(InstancesGetParams),
        typed!(InstanceConfigurationResult),
        Permission {
            requires: &[Requirement::Instances { levels: OWN_TYPES }],
            text: "`instances = own-types` or `all`; only its own types",
        },
    ),
    to_host(
        method::INSTANCES_OF_TYPE,
        "The instances of its own types.",
        typed!(InstancesOfTypeParams),
        typed!(InstancesResult),
        Permission {
            requires: &[Requirement::Instances { levels: OWN_TYPES }],
            text: "`instances = own-types` or `all`",
        },
    ),
    to_host(
        method::INSTANCES_SCAN,
        "Runs the application's discovery on one directory and attaches what it finds.",
        typed!(InstancesScanParams),
        typed!(InstancesScanResult),
        Permission {
            requires: &[Requirement::RegisterInstances],
            text: "`registerInstances = true`; any absolute directory",
        },
    ),
    to_host(
        method::INSTANCES_IMPORT,
        "Imports one directory as a ready instance of a registered type.",
        typed!(InstancesImportParams),
        typed!(InstancesImportResult),
        Permission {
            requires: &[
                Requirement::RegisterInstances,
                Requirement::Instances { levels: OWN_TYPES },
            ],
            text: "`registerInstances = true` and `instances = own-types` (a type of its own) \
                   or `all` (any registered type); any absolute directory",
        },
    ),
    to_host(
        method::SERVERS_STATUS,
        "The server roles of its own types' instances.",
        typed!(ServersStatusParams),
        typed!(ServersResult),
        Permission {
            requires: &[Requirement::Instances { levels: OWN_TYPES }],
            text: "`instances = own-types` or `all`",
        },
    ),
    to_host(
        method::WEBVIEW_PAGES,
        "The embedded WebUI pages of its own types' instances that are open: which launch and page, the role, whether presented or parked, and the authorized address.",
        typed!(WebviewPagesParams),
        typed!(WebviewPagesResult),
        Permission {
            requires: &[Requirement::Instances { levels: OWN_TYPES }],
            text: "`instances = own-types` or `all`",
        },
    ),
    to_host(
        method::WEBVIEW_SHOW,
        "Asks the application window to show one page of one launch of its own instance. The page must be one the launch authorizes; the window routes to it as the user picking it would.",
        typed!(WebviewPageParams),
        Payload::Empty,
        Permission {
            requires: &[Requirement::Instances { levels: OWN_TYPES }],
            text: "`instances = own-types` or `all`; the instance of one of its types and the launch its current one",
        },
    ),
    to_host(
        method::WEBVIEW_CLOSE,
        "Closes one page of one launch of its own instance that waits off screen. The page on screen is closed with its workspace, so that is refused.",
        typed!(WebviewPageParams),
        Payload::Empty,
        Permission {
            requires: &[Requirement::Instances { levels: OWN_TYPES }],
            text: "`instances = own-types` or `all`; the instance of one of its types and the launch its current one",
        },
    ),
    to_host(
        method::WEBVIEW_RELOAD,
        "Reloads the document of one open page of one launch of its own instance. The page keeps its session.",
        typed!(WebviewPageParams),
        Payload::Empty,
        Permission {
            requires: &[Requirement::Instances { levels: OWN_TYPES }],
            text: "`instances = own-types` or `all`; the instance of one of its types and the launch its current one",
        },
    ),
    to_host(
        method::WEBVIEW_NAVIGATE,
        "Navigates one open page of one launch of its own instance to an HTTP(S) address on the page's authorized origin. Another origin is PERMISSION_DENIED; the address is otherwise validated as a launch's browser address is.",
        typed!(WebviewNavigateParams),
        Payload::Empty,
        Permission {
            requires: &[Requirement::Instances { levels: OWN_TYPES }],
            text: "`instances = own-types` or `all`; the instance of one of its types, the launch its current one, and the address on the page's authorized origin",
        },
    ),
    to_host(
        method::PROCESS_RUN,
        "Runs a program with retained task output. Optional instanceId attributes its activity to an instance of its type.",
        typed!(ProcessRunParams),
        typed!(ProcessRunResult),
        Permission {
            requires: &[Requirement::Processes],
            text: "`processes = true`; the working directory inside its data directory, or \
                   with `filesystem = own-instances` one of its own instances' directories",
        },
    ),
    to_host(
        method::PROCESS_CANCEL,
        "Cancels one of its tasks.",
        typed!(ProcessCancelParams),
        Payload::Empty,
        Permission {
            requires: &[Requirement::Processes],
            text: "`processes = true`",
        },
    ),
    to_host(
        method::DOWNLOAD_FETCH,
        "Downloads a file into its data directory through the application's proxy and reports transfer progress in the Task Center.",
        typed!(DownloadFetchParams),
        typed!(DownloadFetchResult),
        Permission {
            requires: &[Requirement::Network],
            text: "the URL's host matching a `network` entry; the destination inside its data \
                   directory",
        },
    ),
    to_host(
        method::HTTP_REQUEST,
        "Makes a bounded HTTP request through the host proxy. Returns actual HTTP status \
         (including non-2xx), repeated headers and UTF-8 text. INVALID_PARAMS for invalid \
         URL, headers or bounds; PERMISSION_DENIED for an ungranted host; REQUEST_FAILED \
         for transport errors, timeout, a response exceeding its limits or non-UTF-8.",
        typed!(HttpRequestParams),
        typed!(HttpRequestResult),
        Permission {
            requires: &[Requirement::Network],
            text: "the URL and every redirect host matching a `network` entry",
        },
    ),
    to_host(
        method::EVENTS_SUBSCRIBE,
        "Replaces its subscription to settings, preferences, instance, server and task events.",
        typed!(EventsSubscribeParams),
        typed!(EventsSubscribeResult),
        Permission {
            requires: &[
                Requirement::Topic {
                    topic: event_topics::INSTANCE,
                    levels: ANY_LEVEL,
                },
                Requirement::Topic {
                    topic: event_topics::SERVER,
                    levels: OWN_TYPES,
                },
                Requirement::ManagementTopic {
                    topic: event_topics::TASK,
                    levels: MANAGE,
                },
            ],
            text: "per topic: `settings` and `preferences` nothing; `instance` any `instances` level but `none`; \
                   `server` `own-types` or `all`; `task` `management = confirm`",
        },
    ),
    to_host(
        method::UI_PROMPT,
        "Queues one question for the main window. Its answer arrives as ui.prompt.result.",
        typed!(UiPromptParams),
        Payload::Empty,
        NOTHING,
    ),
    to_host(
        method::UI_NOTIFY,
        "Shows a notice in the Task Center.",
        typed!(UiNotifyParams),
        Payload::Empty,
        NOTHING,
    ),
    to_host(
        method::UI_PROGRESS,
        "Shows or updates a Task Center activity. With showOnHome, Home shows it while running; with showOnManage, the instance's management panel does.",
        typed!(UiProgressParams),
        Payload::Empty,
        NOTHING,
    ),
    to_host(
        method::PYTHON_ENSURE,
        "Installs a standalone Python as one of its tasks.",
        typed!(PythonEnsureParams),
        typed!(PythonEnsureResult),
        Permission {
            requires: &[Requirement::Processes],
            text: "`processes = true`; the destination strictly below its data directory, or \
                   with `filesystem = own-instances` one of its own instances' directories",
        },
    ),
    to_host(
        method::GIT_CLONE,
        "Clones a repository with the application's Git as one of its tasks.",
        typed!(GitCloneParams),
        typed!(ProcessRunResult),
        Permission {
            requires: &[Requirement::Processes, Requirement::Network],
            text: "`processes = true`; the remote's host matching a `network` entry, or a \
                   `file` URL of a repository inside what it may use; the destination as \
                   `python.ensure`'s, not existing",
        },
    ),
    to_host(
        method::GIT_PULL,
        "Fast-forwards a repository with the application's Git as one of its tasks.",
        typed!(GitPullParams),
        typed!(ProcessRunResult),
        Permission {
            requires: &[Requirement::Processes, Requirement::Network],
            text: "`processes = true`; the directory as `process.run`'s `cwd`, its `origin` \
                   checked as `git.clone`'s URL",
        },
    ),
    MethodSpec {
        bound: &[Bound::ConcurrentCalls, Bound::Call],
        ..to_host(
            method::SERVICES_CALL,
            "Calls a method another extension's backend exports.",
            typed!(ServicesCallParams),
            Payload::Any,
            Permission {
                requires: &[Requirement::Dependency],
                text: "a dependency on the target in its manifest, and the method in the \
                       target's `exports`",
            },
        )
    },
    to_host(
        method::TOOLS_LIST,
        "The management catalog's tools, each with its schema and the `management` level that \
         may call it.",
        Payload::Empty,
        typed!(ToolsListResult),
        Permission {
            requires: &[Requirement::Management { levels: MANAGEMENT }],
            text: "`management = read` or `confirm`",
        },
    ),
    to_host(
        method::TOOLS_CALL,
        "Runs one tool of the management catalog; answers the tool's own result.",
        typed!(ToolsCallParams),
        Payload::Any,
        Permission {
            requires: &[Requirement::Management { levels: MANAGEMENT }],
            text: "`management = read` for a read tool; `confirm` for a mutation, which runs \
                   once the user allows it in the main window",
        },
    ),
    notification(
        method::UI_FRAME_EMIT,
        Direction::BackendToHost,
        "An event for its open frames of one id, optionally scoped to one instance.",
        typed!(FrameEmitParams),
        NOTHING,
    ),
    notification(
        method::UI_EMIT,
        Direction::BackendToHost,
        "Its UI's whole state, optionally scoped to one instance.",
        typed!(UiEmitParams),
        Permission {
            requires: &[Requirement::Hook { hook: hooks::UI }],
            text: "nothing; heard only from a backend that announced the hook `ui`",
        },
    ),
    notification(
        method::UI_TASK_CENTER_OPEN,
        Direction::BackendToHost,
        "Brings one of its Task Center tabs forward in the windows.",
        typed!(UiTaskCenterOpenParams),
        Permission {
            requires: &[Requirement::Hook { hook: hooks::UI }],
            text: "nothing; heard only from a backend that announced the hook `ui`",
        },
    ),
    notification(
        method::TOOLS_REGISTER,
        Direction::BackendToHost,
        "Adds MCP tools, or replaces its own or the manifest's by name.",
        typed!(ToolsRegisterParams),
        NOTHING,
    ),
    notification(
        method::TOOLS_UNREGISTER,
        Direction::BackendToHost,
        "Removes its MCP tools by name; a manifest's is listed again.",
        typed!(ToolsUnregisterParams),
        NOTHING,
    ),
    to_backend(
        method::DIAGNOSTICS_COLLECT_INSTANCE,
        "Collects bounded text documents for an instance of this extension's type.",
        (typed!(InstancesGetParams), typed!(DiagnosticsCollectResult)),
        Permission { requires: &[Requirement::Hook { hook: hooks::INSTANCE_DIAGNOSTICS }], text: "announced diagnostics.collectInstance hook" },
        &[Bound::Call, Bound::TimeoutsInARow, Bound::DiagnosticDocuments, Bound::DiagnosticBytes],
    ),
    to_backend(
        method::DIAGNOSTICS_COLLECT,
        "Collects bounded named text documents for the host-owned diagnostic workspace. Invalid documents fail with REQUEST_FAILED; the call deadline is TIMED_OUT. Other contributors continue after failure.",
        (Payload::Empty, typed!(DiagnosticsCollectResult)),
        Permission { requires: &[Requirement::Hook { hook: hooks::DIAGNOSTICS }], text: "announced diagnostics hook" },
        &[Bound::Call, Bound::TimeoutsInARow, Bound::DiagnosticDocuments, Bound::DiagnosticBytes],
    ),
    to_backend(
        method::INITIALIZE,
        "The first message: the protocol version, what it was granted, and the hooks it \
         implements.",
        (typed!(InitializeParams), typed!(InitializeResult)),
        NOTHING,
        &[Bound::Start, Bound::Initialize],
    ),
    to_backend(
        hooks::MIGRATE,
        "After an update, before `activate`: its data from an earlier version.",
        (typed!(MigrateParams), Payload::Any),
        Permission {
            requires: &[Requirement::Hook {
                hook: hooks::MIGRATE,
            }],
            text: "announced; after an update",
        },
        &[Bound::Start, Bound::Hook],
    ),
    to_backend(
        hooks::ACTIVATE,
        "The end of its start.",
        (Payload::Empty, Payload::Any),
        Permission {
            requires: &[Requirement::Hook {
                hook: hooks::ACTIVATE,
            }],
            text: "announced",
        },
        &[Bound::Start, Bound::Hook],
    ),
    to_backend(
        method::PING,
        "Whether it still answers.",
        (Payload::Empty, Payload::Empty),
        NOTHING,
        &[Bound::PingReply, Bound::PingInterval],
    ),
    to_backend(
        hooks::DEACTIVATE,
        "The first step of its stop.",
        (Payload::Empty, Payload::Any),
        Permission {
            requires: &[Requirement::Hook {
                hook: hooks::DEACTIVATE,
            }],
            text: "announced",
        },
        &[Bound::StopStep],
    ),
    to_backend(
        hooks::UNINSTALL,
        "Before its extension is uninstalled.",
        (Payload::Empty, Payload::Any),
        Permission {
            requires: &[Requirement::Hook {
                hook: hooks::UNINSTALL,
            }],
            text: "announced",
        },
        &[Bound::Hook],
    ),
    to_backend(
        method::SHUTDOWN,
        "The last message: it answers, then exits once its stdin ends.",
        (Payload::Empty, Payload::Empty),
        NOTHING,
        &[Bound::StopStep],
    ),
    to_backend(
        method::PROVIDER_VALIDATE_SPEC,
        "Checks the install parameters' values of a type it provides.",
        (typed!(ValidateSpecParams), typed!(ValidateSpecResult)),
        Permission {
            requires: &[INSTANCE_TYPES],
            text: "a type it provides (`provider = \"backend\"`)",
        },
        CALL,
    ),
    to_backend(
        method::PROVIDER_INSTALL_PLAN,
        "The install, reinstall or update steps of an instance of a type it provides.",
        (typed!(InstallPlanParams), typed!(InstallPlanResult)),
        Permission {
            requires: &[INSTANCE_TYPES],
            text: "a type it provides (`provider = \"backend\"`)",
        },
        CALL,
    ),
    to_backend(
        method::PROVIDER_LAUNCH_PREFLIGHT,
        "Checks an instance before its declared server roles start. A refusal is an RPC error.",
        (typed!(LaunchPreflightParams), Payload::Empty),
        Permission { requires: &[INSTANCE_TYPES], text: "a type it owns with launch.preflight enabled" },
        CALL,
    ),
    to_backend(
        method::PROVIDER_LAUNCH_PLAN,
        "The command of one server role of an instance of a type it provides.",
        (typed!(LaunchPlanParams), typed!(LaunchPlanResult)),
        Permission {
            requires: &[INSTANCE_TYPES],
            text: "a type it provides (`provider = \"backend\"`)",
        },
        CALL,
    ),
    to_backend(
        method::PROVIDER_LAUNCH_OPTIONS,
        "Lists current choices by source for the launch fields of one instance.",
        (typed!(LaunchOptionsParams), typed!(LaunchOptionsResult)),
        Permission { requires: &[INSTANCE_TYPES], text: "a launch select of its type declares optionsSource" },
        CALL,
    ),
    to_backend(
        method::PROVIDER_CHECK_UPDATE,
        "Whether an applicable update exists for this instance. The update may be installed externally.",
        (typed!(CheckUpdateParams), typed!(CheckUpdateResult)),
        Permission {
            requires: &[INSTANCE_TYPES],
            text: "a type it provides that declares `update-check`",
        },
        CALL,
    ),
    to_backend(
        "provider.manage.{operation}",
        "An operation of its own one of its types declares (`management.operations`).",
        (typed!(ManageParams), typed!(ManageResult)),
        Permission {
            requires: &[INSTANCE_TYPES],
            text: "a type it provides that declares the operation",
        },
        CALL,
    ),
    to_backend(
        method::UI_PANEL_QUERY,
        "The data of a block of one of its schema panels: `{rows}` for `info` and `table`, \
         `{lines}` for `log`.",
        (typed!(PanelQueryParams), Payload::Any),
        Permission {
            requires: &[UI],
            text: "a schema panel with a block that is queried",
        },
        CALL,
    ),
    to_backend(
        method::UI_PANEL_ACTION,
        "An action of one of its schema panels was pressed.",
        (typed!(PanelActionParams), typed!(NoticeResult)),
        Permission {
            requires: &[UI],
            text: "a schema panel with the action",
        },
        CALL,
    ),
    to_backend(
        method::UI_FRAME_CALL,
        "A call one of its frames' pages made; what it answers is what the page's call \
         resolves with.",
        (typed!(FrameCallParams), Payload::Any),
        Permission {
            requires: &[UI],
            text: "a frame",
        },
        CALL,
    ),
    to_backend(
        method::UI_STATE,
        "Its UI's state where it is shown.",
        (typed!(UiStateParams), Payload::Any),
        Permission {
            requires: &[Requirement::Hook { hook: hooks::UI }],
            text: "announced the hook `ui`; answered within the bridge's 10 s",
        },
        CALL,
    ),
    to_backend(
        method::UI_CALL,
        "An action of its UI, answered to its caller only.",
        (typed!(UiCallParams), Payload::Any),
        Permission {
            requires: &[Requirement::Hook { hook: hooks::UI }],
            text: "announced the hook `ui`; answered within the bridge's 10 s",
        },
        CALL,
    ),
    to_backend(
        "service.{method}",
        "Handles an exported service for a dependent extension or a published tool for the management MCP endpoint.",
        (typed!(ServiceParams), Payload::Any),
        Permission {
            requires: &[Requirement::ContributesAny {
                keys: &["backend.exports", "contributes.mcpTools"],
            }],
            text: "declared in backend.exports for services.call, or in contributes.mcpTools for management MCP calls",
        },
        CALL,
    ),
    notification(
        method::EVENT,
        Direction::HostToBackend,
        "Something it subscribed to changed.",
        typed!(Event),
        NOTHING,
    ),
    notification(
        method::PROCESS_OUTPUT,
        Direction::HostToBackend,
        "Output of one of its tasks.",
        typed!(ProcessOutput),
        NOTHING,
    ),
    notification(
        method::UI_PROMPT_RESULT,
        Direction::HostToBackend,
        "The user answered or dismissed this backend's question.",
        typed!(UiPromptResult),
        NOTHING,
    ),
    notification(
        method::PROCESS_EXIT,
        Direction::HostToBackend,
        "One of its tasks ended.",
        typed!(ProcessExit),
        NOTHING,
    ),
];
