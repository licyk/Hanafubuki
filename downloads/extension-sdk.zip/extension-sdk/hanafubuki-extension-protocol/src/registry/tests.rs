use std::collections::BTreeSet;

use super::*;
use crate::methods::{hooks, method};
use crate::SERVICE_PREFIX;

/// The values of the `pub const`s in `methods.rs`' module `module`.
fn constants(module: &str) -> Vec<&'static str> {
    let source = include_str!("../methods.rs");
    let start = source
        .find(&format!("pub mod {module} {{"))
        .unwrap_or_else(|| panic!("no module {module}"));
    let body = &source[start..start + source[start..].find("\n}\n").unwrap()];
    body.lines()
        .filter_map(|line| line.trim().strip_prefix("pub const "))
        .map(|constant| constant.split('"').nth(1).unwrap())
        .collect()
}

fn named(name: &str) -> bool {
    METHODS.iter().any(|spec| spec.name == name)
}

#[test]
fn every_method_and_hook_name_is_in_the_registry() {
    let prefixes = [method::PROVIDER_MANAGE_PREFIX, SERVICE_PREFIX];
    for name in constants("method").into_iter().chain(constants("hooks")) {
        if name == hooks::UI || name == hooks::DIAGNOSTICS {
            continue;
        }
        let listed = if prefixes.contains(&name) {
            METHODS.iter().any(|spec| {
                spec.name
                    .strip_prefix(name)
                    .is_some_and(|rest| rest.starts_with('{'))
            })
        } else {
            named(name)
        };
        assert!(listed, "{name} is not in METHODS");
    }
    assert!(named("service.{method}"));
}

#[test]
fn a_name_is_listed_once_per_direction() {
    let mut seen = BTreeSet::new();
    for spec in METHODS {
        assert!(
            seen.insert((spec.name, spec.direction == Direction::BackendToHost)),
            "{} is listed twice",
            spec.name
        );
    }
}

#[test]
fn only_a_notification_has_no_result() {
    for spec in METHODS {
        assert!(spec.result.is_some() || spec.notification, "{}", spec.name);
        if spec.result.is_none() {
            assert!(spec.bound.is_empty(), "{}", spec.name);
        }
    }
}

#[test]
fn every_topic_constant_is_a_topic_and_capabilities_list_the_host_api() {
    let topics: BTreeSet<_> = constants("event_topics").into_iter().collect();
    assert_eq!(topics, TOPICS.iter().map(|topic| topic.name).collect());
    let capabilities = host_capabilities();
    assert!(capabilities
        .methods
        .iter()
        .any(|name| name == method::TOOLS_CALL));
    assert!(!capabilities
        .methods
        .iter()
        .any(|name| name == method::INITIALIZE));
    assert!(capabilities.topics.iter().any(|topic| topic == "task"));
}
