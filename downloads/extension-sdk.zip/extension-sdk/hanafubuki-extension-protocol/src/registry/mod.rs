//! The method registry: every method of protocol version 1 in both
//! directions, with what it carries, what it needs and its bounds. The
//! host's dispatch and the permission table of `docs/rules/extensions.md`
//! are tested against it, and `hanafubuki-interface-export` writes it out as
//! OpenRPC (`sdk/interfaces/backend/`). What a method does is
//! `docs/extension-protocol.md`'s prose.

use serde::Serialize;

use crate::methods::{event_topics, HostCapabilities, InstancesAccess, ManagementAccess};

/// One method, as one direction of the channel uses it.
#[derive(Clone, Copy, Debug)]
pub struct MethodSpec {
    /// Its name; a part in braces is filled in by the call
    /// (`provider.manage.{operation}`, `service.{method}`).
    pub name: &'static str,
    pub direction: Direction,
    /// One line on what it is for.
    pub summary: &'static str,
    pub params: Payload,
    /// What a request answers; none when it is only a notification.
    pub result: Option<Payload>,
    /// It is (also) sent as a notification, which nothing answers.
    pub notification: bool,
    pub permission: Permission,
    pub bound: &'static [Bound],
}

/// A subscription's data schema, not the surrounding `event` envelope.
#[derive(Clone, Copy, Debug)]
pub struct TopicSpec {
    pub name: &'static str,
    pub summary: &'static str,
    pub payload: Payload,
    pub permission: Permission,
}

/// Who calls whom.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "kebab-case")]
pub enum Direction {
    /// The host calls the backend.
    HostToBackend,
    /// The host API: the backend calls the host.
    BackendToHost,
}

/// A method's params or result.
#[derive(Clone, Copy, Debug)]
pub enum Payload {
    /// `{}`: nothing to send or to answer.
    Empty,
    /// Any JSON, the extension's own: what the other side does not read.
    Any,
    /// A type of this crate.
    Typed {
        name: &'static str,
        schema: SchemaFn,
    },
}

/// Adds the type's schema to the generator's definitions and returns a
/// reference to it.
#[cfg(feature = "schema")]
pub type SchemaFn = fn(&mut schemars::SchemaGenerator) -> schemars::Schema;
/// Without the `schema` feature a type is known by its name only.
#[cfg(not(feature = "schema"))]
pub type SchemaFn = ();

#[cfg(feature = "schema")]
macro_rules! typed {
    ($type:ident) => {
        Payload::Typed {
            name: stringify!($type),
            schema: schemars::SchemaGenerator::subschema_for::<$type>,
        }
    };
}

#[cfg(not(feature = "schema"))]
macro_rules! typed {
    ($type:ident) => {
        Payload::Typed {
            name: stringify!($type),
            schema: (),
        }
    };
}

/// What must hold for the call: for a host API method what the extension
/// was granted, for a call the host makes what the backend announced or the
/// extension contributes.
#[derive(Clone, Copy, Debug, Serialize)]
pub struct Permission {
    /// Every one of them; none for a method anyone may call.
    pub requires: &'static [Requirement],
    /// The same in words, with what the requirements do not say (the
    /// directories a path may name).
    pub text: &'static str,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(tag = "kind", rename_all = "camelCase")]
pub enum Requirement {
    /// `permissions.instances` at one of `levels`.
    Instances { levels: &'static [InstancesAccess] },
    /// `permissions.processes = true`.
    Processes,
    /// `permissions.registerInstances = true`.
    RegisterInstances,
    /// A `permissions.network` entry matching the host the call reaches.
    Network,
    /// A dependency on the target in its manifest, the target exporting the
    /// method.
    Dependency,
    /// Subscribing to `topic` needs `permissions.instances` at one of
    /// `levels`.
    Topic {
        topic: &'static str,
        levels: &'static [InstancesAccess],
    },
    /// `permissions.management` at one of `levels`.
    Management { levels: &'static [ManagementAccess] },
    /// Subscribing to `topic` needs `permissions.management` at one of
    /// `levels`.
    ManagementTopic {
        topic: &'static str,
        levels: &'static [ManagementAccess],
    },
    /// The backend listed `hook` in `initialize`'s answer.
    Hook { hook: &'static str },
    /// The extension contributes what the call is about, under the
    /// manifest's `key`.
    Contributes { key: &'static str },
    /// The method is declared through one of these manifest entries.
    ContributesAny { keys: &'static [&'static str] },
}

/// A bound a method's call is held to; the host's values are
/// `hanafubuki-extensions`' `BackendBounds` and busy limit. Every message is
/// also held to `MAX_FRAME_BYTES`.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize)]
#[serde(rename_all = "camelCase")]
pub enum Bound {
    /// The most of a backend's calls the host answers at once; another is
    /// `BUSY`.
    ConcurrentCalls,
    /// The whole start, `initialize` to `activate`.
    Start,
    Initialize,
    /// `migrate`, `activate` and `uninstall`.
    Hook,
    /// Any other call the host makes.
    Call,
    PingReply,
    /// How often `ping` is sent.
    PingInterval,
    /// Each step of a stop: `deactivate`, `shutdown`, the exit.
    StopStep,
    /// The calls in a row that may miss their bound before the channel ends.
    TimeoutsInARow,
    DiagnosticDocuments,
    DiagnosticBytes,
}

const NOTHING: Permission = Permission {
    requires: &[],
    text: "nothing",
};
const HOST_CALL: &[Bound] = &[Bound::ConcurrentCalls];
const CALL: &[Bound] = &[Bound::Call, Bound::TimeoutsInARow];
const READ: &[InstancesAccess] = &[InstancesAccess::Read, InstancesAccess::All];
const OWN_TYPES: &[InstancesAccess] = &[InstancesAccess::OwnTypes, InstancesAccess::All];
const ANY_LEVEL: &[InstancesAccess] = &[
    InstancesAccess::Read,
    InstancesAccess::OwnTypes,
    InstancesAccess::All,
];
const MANAGEMENT: &[ManagementAccess] = &[ManagementAccess::Read, ManagementAccess::Confirm];
const MANAGE: &[ManagementAccess] = &[ManagementAccess::Confirm];
const INSTANCE_TYPES: Requirement = Requirement::Contributes {
    key: "contributes.instanceTypes",
};
const UI: Requirement = Requirement::Contributes {
    key: "contributes.ui",
};

/// A host API request.
const fn to_host(
    name: &'static str,
    summary: &'static str,
    params: Payload,
    result: Payload,
    permission: Permission,
) -> MethodSpec {
    MethodSpec {
        name,
        direction: Direction::BackendToHost,
        summary,
        params,
        result: Some(result),
        notification: false,
        permission,
        bound: HOST_CALL,
    }
}

/// A request the host makes.
const fn to_backend(
    name: &'static str,
    summary: &'static str,
    (params, result): (Payload, Payload),
    permission: Permission,
    bound: &'static [Bound],
) -> MethodSpec {
    MethodSpec {
        name,
        direction: Direction::HostToBackend,
        summary,
        params,
        result: Some(result),
        notification: false,
        permission,
        bound,
    }
}

/// A notification, which nothing answers.
const fn notification(
    name: &'static str,
    direction: Direction,
    summary: &'static str,
    params: Payload,
    permission: Permission,
) -> MethodSpec {
    MethodSpec {
        name,
        direction,
        summary,
        params,
        result: None,
        notification: true,
        permission,
        bound: &[],
    }
}

mod table;

pub use table::METHODS;

mod topics;
pub use topics::TOPICS;

/// What `host.info` says this host serves: the host API in [`METHODS`]
/// and [`TOPICS`].
pub fn host_capabilities() -> HostCapabilities {
    HostCapabilities {
        methods: METHODS
            .iter()
            .filter(|spec| spec.direction == Direction::BackendToHost)
            .map(|spec| spec.name.to_string())
            .collect(),
        topics: TOPICS.iter().map(|topic| topic.name.to_string()).collect(),
    }
}

#[cfg(test)]
mod tests;
