#[cfg_attr(not(feature = "schema"), allow(unused_imports))]
use crate::{HostPreferences, SettingsResult};

use super::{
    event_topics, Payload, Permission, Requirement, TopicSpec, ANY_LEVEL, MANAGE, NOTHING,
    OWN_TYPES,
};

/// Every subscription topic, its payload and its admission requirement.
pub const TOPICS: &[TopicSpec] = &[
    TopicSpec {
        name: event_topics::SETTINGS,
        summary: "This extension's canonical settings values after a successful write.",
        payload: typed!(SettingsResult),
        permission: NOTHING,
    },
    TopicSpec {
        name: event_topics::PREFERENCES,
        summary: "The complete host.preferences snapshot after related host settings change. \
                  A proxy address change also notifies when the public snapshot looks unchanged. \
                  Contains no proxy address or credentials; read host.preferences on subscription or restart.",
        payload: typed!(HostPreferences),
        permission: NOTHING,
    },
    TopicSpec {
        name: event_topics::INSTANCE,
        summary: "An instance view that changed, or {id, removed:true}; own-types hears only its own types.",
        payload: Payload::Any,
        permission: Permission {
            requires: &[Requirement::Instances { levels: ANY_LEVEL }],
            text: "any instances level but none",
        },
    },
    TopicSpec {
        name: event_topics::SERVER,
        summary: "A server view that changed, or {instanceId, role, removed:true}.",
        payload: Payload::Any,
        permission: Permission {
            requires: &[Requirement::Instances { levels: OWN_TYPES }],
            text: "instances = own-types or all",
        },
    },
    TopicSpec {
        name: event_topics::TASK,
        summary: "{phase, activity} for an activity started by this extension's tools.call mutation.",
        payload: Payload::Any,
        permission: Permission {
            requires: &[Requirement::Management { levels: MANAGE }],
            text: "management = confirm",
        },
    },
];
