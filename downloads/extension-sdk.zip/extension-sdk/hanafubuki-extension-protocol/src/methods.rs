//! The methods of protocol version 1, their params and their results. Every
//! type decodes tolerantly (`#[serde(default)]`): a member a peer leaves
//! out takes its default, one this version does not know is ignored. With
//! the `schema` feature each derives its JSON Schema, which lists as
//! `required` only what the reading side cannot do without.

use std::collections::BTreeMap;

use serde::{Deserialize, Serialize};
use serde_json::{Map, Value};

use crate::{ProviderComponent, ToolDeclaration};

/// The protocol version this crate speaks; `initialize` carries it both
/// ways, and the host refuses a backend that answers with another.
pub const PROTOCOL_VERSION: u32 = 1;

/// Method names.
pub mod method {
    // The host calls the backend.
    pub const INITIALIZE: &str = "initialize";
    pub const PING: &str = "ping";
    pub const SHUTDOWN: &str = "shutdown";
    /// A notification of something the backend subscribed to ([`super::Event`]).
    pub const EVENT: &str = "event";
    /// A notification of output of a process the backend started.
    pub const PROCESS_OUTPUT: &str = "process.output";
    /// A notification that a process the backend started ended.
    pub const PROCESS_EXIT: &str = "process.exit";
    /// The instance types the backend provides (`provider = "backend"`).
    pub const PROVIDER_VALIDATE_SPEC: &str = "provider.validateSpec";
    pub const PROVIDER_INSTALL_PLAN: &str = "provider.installPlan";
    pub const PROVIDER_LAUNCH_PREFLIGHT: &str = "provider.launchPreflight";
    pub const PROVIDER_LAUNCH_PLAN: &str = "provider.launchPlan";
    pub const PROVIDER_LAUNCH_OPTIONS: &str = "provider.launchOptions";
    /// Whether an instance of a type it provides that declares
    /// `update-check` has an update ([`crate::CheckUpdateParams`]).
    pub const PROVIDER_CHECK_UPDATE: &str = "provider.checkUpdate";
    /// `provider.manage.<operation>`: an operation of its own one of its
    /// types declares.
    pub const PROVIDER_MANAGE_PREFIX: &str = "provider.manage.";
    /// The data of a block of one of its schema panels.
    pub const UI_PANEL_QUERY: &str = "ui.panel.query";
    /// An action of one of its schema panels was pressed.
    pub const UI_PANEL_ACTION: &str = "ui.panel.action";
    /// A call one of its frames made.
    pub const UI_FRAME_CALL: &str = "ui.frame.call";
    /// The state of its UI ([`super::UiStateParams`]); only with the hook
    /// [`super::hooks::UI`].
    pub const UI_STATE: &str = "ui.state";
    /// An action of its UI ([`super::UiCallParams`]); only with the hook
    /// [`super::hooks::UI`].
    pub const UI_CALL: &str = "ui.call";

    // The backend calls the host.
    pub const HOST_INFO: &str = "host.info";
    pub const HOST_PREFERENCES: &str = "host.preferences";
    pub const RUNTIME_STATUS: &str = "runtime.status";
    pub const RUNTIME_RESOLVE: &str = "runtime.resolve";
    pub const DIAGNOSTICS_COLLECT_INSTANCE: &str = "diagnostics.collectInstance";
    pub const DIAGNOSTICS_COLLECT: &str = "diagnostics.collect";
    pub const LOG_WRITE: &str = "log.write";
    pub const SETTINGS_GET: &str = "settings.get";
    pub const SETTINGS_PATCH: &str = "settings.patch";
    pub const STORAGE_PATH: &str = "storage.path";
    pub const INSTANCES_LIST: &str = "instances.list";
    pub const INSTANCES_CONFIGURATION: &str = "instances.configuration";
    pub const INSTANCES_GET: &str = "instances.get";
    pub const INSTANCES_OF_TYPE: &str = "instances.ofType";
    /// Discovery on one directory ([`super::InstancesScanParams`]); needs
    /// `registerInstances`.
    pub const INSTANCES_SCAN: &str = "instances.scan";
    /// One directory imported as an instance ([`super::InstancesImportParams`]);
    /// needs `registerInstances` and `instances = own-types` or `all`.
    pub const INSTANCES_IMPORT: &str = "instances.import";
    pub const PROCESS_RUN: &str = "process.run";
    pub const PROCESS_CANCEL: &str = "process.cancel";
    pub const DOWNLOAD_FETCH: &str = "download.fetch";
    pub const HTTP_REQUEST: &str = "http.request";
    pub const SERVERS_STATUS: &str = "servers.status";
    /// The embedded WebUI pages of its own types' instances that are open
    /// ([`super::WebviewPagesParams`]); needs `instances = own-types`.
    pub const WEBVIEW_PAGES: &str = "webview.pages";
    /// Asks the application window to show one of those pages
    /// ([`super::WebviewPageParams`]); the launch must authorize it.
    pub const WEBVIEW_SHOW: &str = "webview.show";
    /// Closes one of those pages that is waiting off screen.
    pub const WEBVIEW_CLOSE: &str = "webview.close";
    /// Reloads one of those pages.
    pub const WEBVIEW_RELOAD: &str = "webview.reload";
    /// Navigates one of those pages within its authorized origin
    /// ([`super::WebviewNavigateParams`]).
    pub const WEBVIEW_NAVIGATE: &str = "webview.navigate";
    pub const EVENTS_SUBSCRIBE: &str = "events.subscribe";
    pub const UI_PROMPT: &str = "ui.prompt";
    pub const UI_PROMPT_RESULT: &str = "ui.prompt.result";
    pub const UI_NOTIFY: &str = "ui.notify";
    pub const UI_PROGRESS: &str = "ui.progress";
    /// A notification: brings a Task Center tab forward, this extension's
    /// ([`super::UiTaskCenterOpenParams`]).
    pub const UI_TASK_CENTER_OPEN: &str = "ui.taskCenter.open";
    /// A notification: MCP tools added, or replaced by name
    /// ([`super::ToolsRegisterParams`]); the sessions that list tools hear it.
    pub const TOOLS_REGISTER: &str = "tools.register";
    /// A notification: MCP tools removed by name
    /// ([`super::ToolsUnregisterParams`]).
    pub const TOOLS_UNREGISTER: &str = "tools.unregister";
    pub const PYTHON_ENSURE: &str = "python.ensure";
    pub const GIT_CLONE: &str = "git.clone";
    pub const GIT_PULL: &str = "git.pull";
    pub const SERVICES_CALL: &str = "services.call";
    /// The management catalog's tools ([`super::ToolsListResult`]); needs
    /// `management`.
    pub const TOOLS_LIST: &str = "tools.list";
    /// One tool of the management catalog run ([`super::ToolsCallParams`]);
    /// needs `management`, a mutation `management = confirm`.
    pub const TOOLS_CALL: &str = "tools.call";
    /// A notification: an event for its frames.
    pub const UI_FRAME_EMIT: &str = "ui.frame.emit";
    /// A notification: its UI's state changed ([`super::UiEmitParams`]).
    pub const UI_EMIT: &str = "ui.emit";
}

/// `service.<method>`: how the host forwards another extension's
/// `services.call` to the backend that exports the method.
pub const SERVICE_PREFIX: &str = "service.";

/// The hooks a backend may implement, which the host calls (each a method
/// of the same name) only when `initialize`'s answer lists it.
pub mod hooks {
    pub const ACTIVATE: &str = "activate";
    pub const DEACTIVATE: &str = "deactivate";
    pub const MIGRATE: &str = "migrate";
    pub const UNINSTALL: &str = "uninstall";
    /// Not a method: a backend that lists it answers `ui.state` and
    /// `ui.call`, and its `ui.emit` is heard.
    pub const UI: &str = "ui";
    pub const INSTANCE_DIAGNOSTICS: &str = "diagnostics.collectInstance";
    pub const DIAGNOSTICS: &str = "diagnostics";
}

/// What `events.subscribe` subscribes to.
pub mod event_topics {
    pub const INSTANCE: &str = "instance";
    pub const SERVER: &str = "server";
    pub const SETTINGS: &str = "settings";
    pub const PREFERENCES: &str = "preferences";
    /// The Task Center activities its own `tools.call` mutations started:
    /// `{ phase, activity }`, `phase` `start`, `progress` or `end`.
    pub const TASK: &str = "task";
}

/// Which instances the extension may read.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum InstancesAccess {
    #[default]
    None,
    /// Every instance, read only (`instances.list`, `instances.get`).
    Read,
    /// The instances of its own types (`instances.ofType`, `servers.status`);
    /// with `registerInstances`, `instances.import` of its own types.
    OwnTypes,
    /// Both; with `registerInstances`, `instances.import` of any type.
    All,
}

/// What the extension may do through the management catalog
/// (`tools.list`, `tools.call`). Never more than asking the user: the
/// catalog's trusted scope is not an extension's to have.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum ManagementAccess {
    #[default]
    None,
    /// The read tools.
    Read,
    /// Every tool; each mutation runs only once the user confirms it.
    Confirm,
}

/// Where the extension's processes may run.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum FilesystemAccess {
    /// Its own data directory.
    #[default]
    ExtensionData,
    /// Its own data directory and the directories of its own types'
    /// instances.
    OwnInstances,
}

/// What the extension was granted at install.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Permissions {
    pub instances: InstancesAccess,
    pub processes: bool,
    /// Hosts `download.fetch`, `git.clone` and `git.pull` may reach: a
    /// name, or `*.` and a suffix.
    pub network: Vec<String>,
    pub filesystem: FilesystemAccess,
    /// `instances.scan` and `instances.import`: it may add instances.
    pub register_instances: bool,
    /// The management catalog's tools.
    pub management: ManagementAccess,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ExtensionInfo {
    pub id: String,
    pub version: String,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct HostInfo {
    pub version: String,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct InitializeParams {
    pub protocol_version: u32,
    pub extension: ExtensionInfo,
    pub permissions: Permissions,
    pub host: HostInfo,
    pub data_dir: String,
    pub locale: String,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["protocolVersion"])))]
pub struct InitializeResult {
    pub protocol_version: u32,
    /// The hooks it implements ([`hooks`]); another name is ignored.
    pub hooks: Vec<String>,
    /// The MCP tools it publishes on the host management MCP server
    /// ([`crate::ToolDeclaration`]), beside the ones its manifest declares
    /// and over one of those by name. Changed later by `tools.register` and
    /// `tools.unregister`.
    #[serde(default)]
    pub tools: Vec<ToolDeclaration>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct MigrateParams {
    pub from_version: String,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct HostInfoResult {
    pub version: String,
    pub protocol_version: u32,
    pub locale: String,
    /// `linux`, `macos` or `windows`.
    pub platform: String,
    /// Where the application creates an instance unless the user chooses
    /// otherwise (the setting new instances default to), as native text;
    /// none before the settings are read.
    pub instances_dir: Option<String>,
    /// What this host serves, so a backend can probe for a method or topic
    /// without a new protocol version.
    pub capabilities: HostCapabilities,
    /// The user's download mirrors, which a backend applies itself; none
    /// before the settings are read.
    pub mirrors: Option<HostMirrors>,
}

/// The download mirrors the user chose in Settings, as the built-in
/// launcher gets them.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct HostMirrors {
    /// The user leaves the mirrors to `sd_webui_all_in_one`'s detection:
    /// the built-in launcher passes `auto_mirror` with the switches below,
    /// which Settings then shows disabled, and uses the mirrors it resolves.
    pub automatic: bool,
    pub pypi: HostMirror,
    pub github: HostMirror,
    pub huggingface: HostMirror,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct HostMirror {
    pub enabled: bool,
    /// The user's own mirror URL; none for the default mirror (PyPI has
    /// no custom one).
    pub custom: Option<String>,
}

/// The host API's methods (requests and notifications) and the event
/// topics this host serves, whatever the extension was granted.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct HostCapabilities {
    pub methods: Vec<String>,
    pub topics: Vec<String>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct LogWriteParams {
    /// `error`, `warn`, `info` (the default) or `debug`.
    pub level: String,
    pub message: String,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct SettingsResult {
    pub values: Map<String, Value>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["patch"])))]
pub struct SettingsPatchParams {
    /// This extension's declared fields only; null unsets an override.
    pub patch: Map<String, Value>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct StoragePathResult {
    pub path: String,
}

/// An instance as an extension reads it.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct InstanceView {
    pub id: String,
    pub name: String,
    #[serde(rename = "type")]
    pub type_id: String,
    pub path: String,
    /// A launch of it has not ended, or one of its servers runs.
    pub running: bool,
    /// Where each of its type's components is, by name, as a provider
    /// callback names them; empty when they cannot be resolved.
    pub components: BTreeMap<String, ProviderComponent>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["id"])))]
pub struct InstancesGetParams {
    pub id: String,
}

/// Non-secret install and launch fields of an instance of the caller's types.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct InstanceConfigurationResult {
    pub values: Map<String, Value>,
    pub launch_values: Map<String, Value>,
    pub values_truncated: bool,
    pub launch_values_truncated: bool,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct InstancesOfTypeParams {
    /// One of its types; all of them when absent.
    #[serde(rename = "type")]
    pub type_id: Option<String>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct InstancesResult {
    pub instances: Vec<InstanceView>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["path"])))]
pub struct InstancesScanParams {
    /// An absolute directory.
    pub path: String,
}

/// What scanning a directory found.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct InstancesScanResult {
    /// The instances it added.
    pub attached: Vec<String>,
    /// Every result that is not a plain attachment, as the application's
    /// discovery writes it (`kind`, `path`, `message`, `instanceId`,
    /// `type`): read tolerantly.
    pub warnings: Vec<Value>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["type", "path"])))]
pub struct InstancesImportParams {
    /// A registered type.
    #[serde(rename = "type")]
    pub type_id: String,
    /// An absolute directory: the instance's root.
    pub path: String,
    /// Generated from the type when absent.
    pub name: Option<String>,
    /// Where a declared component is, absolute or relative to `path`;
    /// `<path>/<name>` when absent.
    pub component_paths: BTreeMap<String, String>,
    /// Its install parameters' values; the defaults for what is absent.
    pub values: Map<String, Value>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct InstancesImportResult {
    pub id: String,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["argv"])))]
pub struct ProcessRunParams {
    /// Attribute the activity to an instance of this extension.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub instance_id: Option<String>,
    /// The program and its arguments; no shell.
    pub argv: Vec<String>,
    /// Its data directory when absent.
    pub cwd: Option<String>,
    pub env: BTreeMap<String, String>,
    /// Apply the host's current proxy to this process only, over env.
    pub use_host_proxy: bool,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ProcessRunResult {
    pub task_id: String,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["taskId"])))]
pub struct ProcessCancelParams {
    pub task_id: String,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ProcessOutput {
    pub task_id: String,
    /// `stdout` or `stderr`.
    pub stream: String,
    /// The bytes as text, invalid UTF-8 replaced.
    pub data: String,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ProcessExit {
    pub task_id: String,
    /// `exited`, `failed` or `cancelled`.
    pub status: String,
    pub exit_code: Option<i32>,
    pub error: Option<String>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["url", "destination"])))]
pub struct DownloadFetchParams {
    pub url: String,
    /// The SHA-256 the bytes must have, hex.
    pub sha256: Option<String>,
    /// Relative to its data directory, or absolute inside it.
    pub destination: String,
    /// Direct by default; otherwise resolve the source through host mirrors.
    pub source: crate::DownloadSource,
    /// Reuse digest-verified host cache entries only when sha256 is supplied.
    pub cache: bool,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct DownloadFetchResult {
    pub path: String,
    pub sha256: String,
}

/// One server role of one of its instances.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ServerView {
    pub instance_id: String,
    pub role: String,
    /// `starting`, `running`, `restarting`, `stopping`, `stopped` or `failed`.
    pub status: String,
    pub endpoint: Option<String>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ServersStatusParams {
    /// One of its instances; all of them when absent.
    pub instance_id: Option<String>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ServersResult {
    pub servers: Vec<ServerView>,
}

/// One embedded WebUI page the application holds open for an instance of
/// the extension's types.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct WebviewPageView {
    pub instance_id: String,
    /// The launch operation the page belongs to; names it with `pageId` in
    /// the other `webview.*` methods.
    pub operation_id: String,
    pub page_id: String,
    /// The server role whose interface the page is.
    pub role: String,
    /// `presented`, `parked` or `cleanupRequired`.
    pub state: String,
    /// The address the page was authorized for, not the document it has
    /// since navigated to.
    pub url: String,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct WebviewPagesParams {
    /// One of its instances; all of them when absent.
    pub instance_id: Option<String>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct WebviewPagesResult {
    pub pages: Vec<WebviewPageView>,
}

/// Names one page of one launch of one of its instances.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["instanceId", "operationId"])))]
#[serde(default, rename_all = "camelCase")]
pub struct WebviewPageParams {
    pub instance_id: String,
    pub operation_id: String,
    /// One of the launch's pages; with none, the page the instance shows
    /// or showed last, else the launch's first.
    pub page_id: Option<String>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[cfg_attr(
    feature = "schema",
    schemars(extend("required" = ["instanceId", "operationId", "pageId", "url"]))
)]
#[serde(default, rename_all = "camelCase")]
pub struct WebviewNavigateParams {
    pub instance_id: String,
    pub operation_id: String,
    /// Required: the page to navigate, which must be open.
    pub page_id: String,
    /// An HTTP(S) address on the page's authorized origin (`scheme`, `host`
    /// and `port` equal); another origin is `PERMISSION_DENIED`.
    pub url: String,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct EventsSubscribeParams {
    /// [`event_topics`]; the subscription replaces the previous one.
    pub topics: Vec<String>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct EventsSubscribeResult {
    pub topics: Vec<String>,
}

/// What the `event` notification carries: an instance (an
/// [`InstanceView`]), a server (a [`ServerView`]) or the settings values
/// that changed.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct Event {
    pub topic: String,
    pub data: Value,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct UiNotifyParams {
    pub message: String,
    /// `info` (the default), `warning` or `error`.
    pub level: String,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct UiProgressParams {
    /// Show this running activity in the Home status dock.
    pub show_on_home: bool,
    /// Show this running activity in the corner of the instance's
    /// management panel while it is open.
    pub show_on_manage: bool,
    /// Optional owner instance of the extension's type. Scoped and global ids are independent.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub instance_id: Option<String>,
    /// Its own name for the work; a later call with the same id updates it.
    pub id: String,
    pub title: String,
    pub completed: Option<u64>,
    pub total: Option<u64>,
    /// The work ended; with `error`, it failed.
    pub done: bool,
    pub error: Option<String>,
}

/// `ui.taskCenter.open`: bring one of this extension's Task Center tabs
/// forward, whose panel or frame the manifest declares in `taskCenter.tabs`
/// and whose contribution id is `<id>:<panel or frame>`, as its side shows
/// it. A tab the application does not list is ignored.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct UiTaskCenterOpenParams {
    /// The panel's or frame's own id, as `contributes.ui` names it.
    pub tab: String,
}

/// What a provider operation or a panel action answers.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct NoticeResult {
    /// What to tell the user, if anything.
    pub notice: Option<String>,
    /// An HTTP(S) address the user's browser is asked to open, for an
    /// `openUrl` toolbar shortcut that declared none; checked by the host.
    pub url: Option<String>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["version", "destination"])))]
pub struct PythonEnsureParams {
    /// A version the application installs (`3.11`).
    pub version: String,
    /// Where it goes: relative to its data directory, or absolute inside
    /// what it may write.
    pub destination: String,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct PythonEnsureResult {
    /// Its end is a `process.exit` notification of this task.
    pub task_id: String,
    /// The interpreter, once the task ended well.
    pub python_path: String,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["url", "destination"])))]
pub struct GitCloneParams {
    /// `http(s)`, `ssh` or `git` (its host granted), or a `file` URL of a
    /// repository inside what it may use.
    pub url: String,
    /// A directory that does not exist yet, as `destination` is anywhere.
    pub destination: String,
    pub branch: Option<String>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["dir"])))]
pub struct GitPullParams {
    /// A repository inside what it may use, as `process.run`'s `cwd`.
    pub dir: String,
}

/// Where a panel or a frame is shown: in an instance's management, that
/// instance.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct PanelContext {
    pub instance_id: Option<String>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct PanelQueryParams {
    pub panel: String,
    pub block: String,
    pub context: PanelContext,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct PanelActionParams {
    pub panel: String,
    pub action: String,
    /// Its form's values, read against the form by the host.
    pub values: Map<String, Value>,
    pub context: PanelContext,
    /// The `list` row it was pressed on (the row's `id`); none for an
    /// actions block's button.
    pub row: Option<String>,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["extension", "method"])))]
pub struct ServicesCallParams {
    /// The extension whose backend answers; the caller depends on it.
    pub extension: String,
    /// One of the methods it exports.
    pub method: String,
    pub params: Value,
}

/// What the host forwards to the exporting backend as
/// `service.<method>`'s params.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ServiceParams {
    /// The calling extension's id, or `mcp:hanafubuki` for its published MCP tool.
    pub caller: String,
    /// As the caller sent them.
    pub params: Value,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct FrameCallParams {
    /// The frame's id, as its `contributes.ui` entry names it.
    pub frame: String,
    /// What the frame's page called, as it named it.
    pub method: String,
    pub params: Value,
    pub context: PanelContext,
}

/// An event for the extension's frames: delivered to each open frame
/// `frame` names, which hands it to its page's listeners of `event`.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["frame", "event"])))]
pub struct FrameEmitParams {
    /// Deliver only to this instance. Omission broadcasts to every view.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub instance_id: Option<String>,
    pub frame: String,
    pub event: String,
    pub payload: Value,
}

/// The state of the extension's UI, where it is shown (`ui.state`).
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct UiStateParams {
    pub context: PanelContext,
}

/// An action of the extension's UI (`ui.call`), with what the UI sent.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct UiCallParams {
    pub action: String,
    pub args: Value,
    pub context: PanelContext,
}

/// The extension's UI state changed (`ui.emit`): `state` is pushed to its
/// UI as it is.
#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct UiEmitParams {
    /// Deliver only to this instance. Omission broadcasts to every view.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub instance_id: Option<String>,
    pub state: Value,
}
