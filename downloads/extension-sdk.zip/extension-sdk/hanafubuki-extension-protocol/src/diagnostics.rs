use serde::{Deserialize, Serialize};

pub const DIAGNOSTIC_MAX_DOCUMENTS: usize = 32;
pub const DIAGNOSTIC_MAX_BYTES: usize = crate::MAX_FRAME_BYTES / 8;

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct DiagnosticDocument {
    /// One file name, never a path; the host owns the diagnostic directory.
    pub name: String,
    /// Plain text or serialized JSON. The host writes these bytes unchanged.
    pub text: String,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct DiagnosticsCollectResult {
    /// At most 32 documents, with at most 524288 aggregate UTF-8 name/text bytes.
    pub documents: Vec<DiagnosticDocument>,
}
