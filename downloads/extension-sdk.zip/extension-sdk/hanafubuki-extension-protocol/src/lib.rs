//! The protocol between the application and an extension's backend
//! (`docs/extension-protocol.md`): JSON-RPC 2.0 messages framed as LSP frames
//! (`Content-Length` headers) over the backend's stdin and stdout. The host
//! side is `hanafubuki-extensions`, the backend side
//! `hanafubuki-extension-sdk`; both read and write through this crate.
//!
//! What a peer sends is decoded tolerantly: a field this version does not
//! know is ignored, a missing one takes its default. A frame that is not a
//! frame, or a body that is not a JSON-RPC message, is an error of the
//! channel, which its reader ends.
//!
//! [`METHODS`] lists every method with its params, result, permission and
//! bounds; the `schema` feature adds the JSON Schema of each params and
//! result type, for the interface export (`hanafubuki-interface-export`).

mod diagnostics;
mod error;
mod framing;
mod message;
mod methods;
mod network;
mod preferences;
mod prompts;
mod provider;
mod published;
mod registry;
mod runtime;
mod tools;

pub use diagnostics::{
    DiagnosticDocument, DiagnosticsCollectResult, DIAGNOSTIC_MAX_BYTES, DIAGNOSTIC_MAX_DOCUMENTS,
};
pub use error::{codes, RpcError};
pub use framing::{encode_frame, FrameDecoder, FrameError, MAX_FRAME_BYTES, MAX_HEADER_BYTES};
pub use message::{Id, Message};
pub use methods::{
    event_topics, hooks, method, DownloadFetchParams, DownloadFetchResult, Event,
    EventsSubscribeParams, EventsSubscribeResult, ExtensionInfo, FilesystemAccess, FrameCallParams,
    FrameEmitParams, GitCloneParams, GitPullParams, HostCapabilities, HostInfo, HostInfoResult,
    HostMirror, HostMirrors, InitializeParams, InitializeResult, InstanceConfigurationResult,
    InstanceView, InstancesAccess, InstancesGetParams, InstancesImportParams,
    InstancesImportResult, InstancesOfTypeParams, InstancesResult, InstancesScanParams,
    InstancesScanResult, LogWriteParams, ManagementAccess, MigrateParams, NoticeResult,
    PanelActionParams, PanelContext, PanelQueryParams, Permissions, ProcessCancelParams,
    ProcessExit, ProcessOutput, ProcessRunParams, ProcessRunResult, PythonEnsureParams,
    PythonEnsureResult, ServerView, ServersResult, ServersStatusParams, ServiceParams,
    ServicesCallParams, SettingsPatchParams, SettingsResult, StoragePathResult, UiCallParams,
    UiEmitParams, UiNotifyParams, UiProgressParams, UiStateParams, UiTaskCenterOpenParams,
    WebviewNavigateParams, WebviewPageParams, WebviewPageView, WebviewPagesParams,
    WebviewPagesResult, PROTOCOL_VERSION, SERVICE_PREFIX,
};
pub use network::{
    DownloadSource, HttpHeader, HttpMethod, HttpRequestParams, HttpRequestResult, HTTP_MAX_BYTES,
    HTTP_MAX_HEADER_BYTES, HTTP_TIMEOUT_MS,
};
pub use preferences::{HostNetworkPreferences, HostPreferences, HostProxyMode};
pub use prompts::{PromptKind, UiPromptParams, UiPromptResult};
pub use provider::{
    CheckUpdateParams, CheckUpdateResult, ComponentUpdateResult, InstallPlanParams,
    InstallPlanResult, LaunchOptionsParams, LaunchOptionsResult, LaunchPlanParams,
    LaunchPlanResult, LaunchPreflightParams, ManageParams, ManageResult, ProviderComponent,
    ProviderInstance, ValidateSpecParams, ValidateSpecResult,
};
pub use published::{ToolDeclaration, ToolsRegisterParams, ToolsUnregisterParams};
pub use registry::{
    host_capabilities, Bound, Direction, MethodSpec, Payload, Permission, Requirement, SchemaFn,
    TopicSpec, METHODS, TOPICS,
};
pub use runtime::{
    RuntimeResolveParams, RuntimeResolveResult, RuntimeStatus, RuntimeStatusParams,
    RuntimeStatusResult, RuntimeTool, RuntimeToolStatus,
};
pub use tools::{ToolAnnotations, ToolDescriptor, ToolsCallParams, ToolsListResult};
