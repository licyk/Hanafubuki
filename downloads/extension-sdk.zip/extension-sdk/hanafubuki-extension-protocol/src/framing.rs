//! LSP framing: each message is a header section, lines ending in `\r\n`
//! and closed by an empty line, then a body of exactly `Content-Length`
//! bytes. Other headers (`Content-Type`) are ignored. A frame is bounded:
//! its headers by [`MAX_HEADER_BYTES`], its body by the decoder's maximum
//! ([`MAX_FRAME_BYTES`] unless given), so a peer cannot make its reader
//! buffer without end.

use std::fmt;

/// The largest body a frame may carry.
pub const MAX_FRAME_BYTES: usize = 4 * 1024 * 1024;
/// The largest header section a frame may have, its closing empty line
/// included.
pub const MAX_HEADER_BYTES: usize = 1024;

const HEADER_END: &[u8] = b"\r\n\r\n";
const CONTENT_LENGTH: &str = "content-length";

/// Why a byte stream is not frames; the stream cannot be read further.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum FrameError {
    BadHeader(String),
    TooLarge { length: usize, max: usize },
}

impl fmt::Display for FrameError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::BadHeader(reason) => write!(formatter, "a frame's header is bad: {reason}"),
            Self::TooLarge { length, max } => write!(
                formatter,
                "a frame of {length} bytes is larger than the {max} allowed"
            ),
        }
    }
}

impl std::error::Error for FrameError {}

/// The bytes of one message as a frame.
pub fn encode_frame(body: &[u8]) -> Vec<u8> {
    let mut frame = format!("Content-Length: {}\r\n\r\n", body.len()).into_bytes();
    frame.extend_from_slice(body);
    frame
}

/// Splits a byte stream, given in pieces of any size, into frame bodies.
pub struct FrameDecoder {
    buffer: Vec<u8>,
    max_frame: usize,
    /// The length of the body being read, once its headers are.
    body: Option<usize>,
}

impl Default for FrameDecoder {
    fn default() -> Self {
        Self::with_max(MAX_FRAME_BYTES)
    }
}

impl FrameDecoder {
    pub fn with_max(max_frame: usize) -> Self {
        Self {
            buffer: Vec::new(),
            max_frame,
            body: None,
        }
    }

    pub fn push(&mut self, bytes: &[u8]) {
        self.buffer.extend_from_slice(bytes);
    }

    /// Whether part of a frame is waiting for the rest.
    pub fn has_partial(&self) -> bool {
        self.body.is_some() || !self.buffer.is_empty()
    }

    /// The next whole frame's body, `None` until one is there. After an
    /// error the stream is not frames, and the decoder keeps failing.
    pub fn next_frame(&mut self) -> Result<Option<Vec<u8>>, FrameError> {
        let length = match self.body {
            Some(length) => length,
            None => match self.headers()? {
                Some(length) => length,
                None => return Ok(None),
            },
        };
        if self.buffer.len() < length {
            return Ok(None);
        }
        self.body = None;
        let rest = self.buffer.split_off(length);
        Ok(Some(std::mem::replace(&mut self.buffer, rest)))
    }

    /// Reads a header section at the front of the buffer, once it is all
    /// there, and returns its body's length.
    fn headers(&mut self) -> Result<Option<usize>, FrameError> {
        let Some(end) = self
            .buffer
            .windows(HEADER_END.len())
            .position(|window| window == HEADER_END)
        else {
            if self.buffer.len() > MAX_HEADER_BYTES {
                return Err(FrameError::BadHeader(format!(
                    "no end of the headers within {MAX_HEADER_BYTES} bytes"
                )));
            }
            return Ok(None);
        };
        if end + HEADER_END.len() > MAX_HEADER_BYTES {
            return Err(FrameError::BadHeader(format!(
                "headers longer than {MAX_HEADER_BYTES} bytes"
            )));
        }
        let length = content_length(&self.buffer[..end])?;
        if length > self.max_frame {
            return Err(FrameError::TooLarge {
                length,
                max: self.max_frame,
            });
        }
        self.buffer.drain(..end + HEADER_END.len());
        self.body = Some(length);
        Ok(Some(length))
    }
}

fn content_length(headers: &[u8]) -> Result<usize, FrameError> {
    let text = std::str::from_utf8(headers)
        .map_err(|_| FrameError::BadHeader("headers are not text".to_string()))?;
    let mut length = None;
    for line in text.split("\r\n") {
        let (name, value) = line
            .split_once(':')
            .ok_or_else(|| FrameError::BadHeader(format!("`{line}` is not a header")))?;
        if name.trim().eq_ignore_ascii_case(CONTENT_LENGTH) {
            length = Some(value.trim().parse::<usize>().map_err(|_| {
                FrameError::BadHeader(format!("Content-Length `{}` is not a length", value.trim()))
            })?);
        }
    }
    length.ok_or_else(|| FrameError::BadHeader("no Content-Length".to_string()))
}

#[cfg(test)]
mod tests;
