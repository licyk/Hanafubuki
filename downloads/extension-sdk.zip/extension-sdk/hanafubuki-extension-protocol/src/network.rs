//! Bounded HTTP requests and opt-in download policies.

use serde::{Deserialize, Serialize};

/// Leaves room for JSON escaping, headers and the RPC envelope.
pub const HTTP_MAX_BYTES: u64 = (crate::MAX_FRAME_BYTES / 8) as u64;
pub const HTTP_MAX_HEADER_BYTES: usize = crate::MAX_FRAME_BYTES / 64;
pub const HTTP_TIMEOUT_MS: u64 = 30_000;

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "UPPERCASE")]
pub enum HttpMethod {
    #[default]
    Get,
    Head,
    Post,
    Put,
    Patch,
    Delete,
    Options,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default)]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["name", "value"])))]
pub struct HttpHeader {
    pub name: String,
    pub value: String,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
#[cfg_attr(feature = "schema", schemars(extend("required" = ["url"])))]
pub struct HttpRequestParams {
    pub url: String,
    pub method: HttpMethod,
    /// Repeated names are preserved; no host credentials are added.
    pub headers: Vec<HttpHeader>,
    /// UTF-8 text. Binary resources use download.fetch.
    pub body: Option<String>,
    /// Response body bytes, from 1 through HTTP_MAX_BYTES (524288).
    pub max_bytes: u64,
    /// Whole-request timeout, from 1 through HTTP_TIMEOUT_MS (30000).
    pub timeout_ms: u64,
}

impl Default for HttpRequestParams {
    fn default() -> Self {
        Self {
            url: String::new(),
            method: HttpMethod::Get,
            headers: Vec::new(),
            body: None,
            max_bytes: HTTP_MAX_BYTES,
            timeout_ms: HTTP_TIMEOUT_MS,
        }
    }
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct HttpRequestResult {
    /// The actual HTTP status, including non-success responses.
    pub status: u16,
    pub headers: Vec<HttpHeader>,
    /// UTF-8 text; a binary response is an error.
    pub body: String,
}

#[cfg_attr(feature = "schema", derive(schemars::JsonSchema))]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum DownloadSource {
    #[default]
    Direct,
    Github,
    Huggingface,
}
