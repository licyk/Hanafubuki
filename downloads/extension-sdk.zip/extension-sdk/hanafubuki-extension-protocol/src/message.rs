//! A JSON-RPC 2.0 message: a request, a notification or a response.
//! Decoded tolerantly: `jsonrpc` is not checked and unknown members are
//! ignored; what decides the kind is which of `method`, `id`, `result` and
//! `error` it has.

use serde::{Deserialize, Serialize};
use serde_json::{json, Map, Value};

use crate::RpcError;

/// A request's id, as the peer that sent it wrote it.
#[derive(Clone, Debug, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(untagged)]
pub enum Id {
    Number(i64),
    Text(String),
}

#[derive(Clone, Debug, PartialEq)]
pub enum Message {
    Request {
        id: Id,
        method: String,
        params: Value,
    },
    Notification {
        method: String,
        params: Value,
    },
    /// The answer to the request `id`; `None` when the peer could not read
    /// which request it answers.
    Response {
        id: Option<Id>,
        outcome: Result<Value, RpcError>,
    },
}

impl Message {
    pub fn request(id: Id, method: &str, params: Value) -> Self {
        Self::Request {
            id,
            method: method.to_string(),
            params,
        }
    }

    pub fn notification(method: &str, params: Value) -> Self {
        Self::Notification {
            method: method.to_string(),
            params,
        }
    }

    pub fn response(id: Id, outcome: Result<Value, RpcError>) -> Self {
        Self::Response {
            id: Some(id),
            outcome,
        }
    }

    /// The message a frame's body holds.
    pub fn decode(body: &[u8]) -> Result<Self, String> {
        let value: Value =
            serde_json::from_slice(body).map_err(|error| format!("not JSON: {error}"))?;
        let Value::Object(mut object) = value else {
            return Err("not a JSON-RPC message: not an object".to_string());
        };
        let id = match object.remove("id") {
            None | Some(Value::Null) => None,
            Some(id) => Some(
                Id::deserialize(id)
                    .map_err(|_| "its id is not a number or a string".to_string())?,
            ),
        };
        let params = object.remove("params").unwrap_or(Value::Null);
        if let Some(method) = object.remove("method") {
            let Value::String(method) = method else {
                return Err("its method is not a string".to_string());
            };
            return Ok(match id {
                Some(id) => Self::Request { id, method, params },
                None => Self::Notification { method, params },
            });
        }
        if let Some(error) = object.remove("error") {
            let error = RpcError::deserialize(error)
                .map_err(|error| format!("its error does not read: {error}"))?;
            return Ok(Self::Response {
                id,
                outcome: Err(error),
            });
        }
        match (id, object.remove("result")) {
            (Some(id), result) => Ok(Self::Response {
                id: Some(id),
                outcome: Ok(result.unwrap_or(Value::Null)),
            }),
            (None, _) => Err("not a JSON-RPC message: no method and no id".to_string()),
        }
    }

    /// The message as a frame's body.
    pub fn encode(&self) -> Vec<u8> {
        let mut object = Map::new();
        object.insert("jsonrpc".to_string(), json!("2.0"));
        match self {
            Self::Request { id, method, params } => {
                object.insert("id".to_string(), json!(id));
                object.insert("method".to_string(), json!(method));
                object.insert("params".to_string(), params.clone());
            }
            Self::Notification { method, params } => {
                object.insert("method".to_string(), json!(method));
                object.insert("params".to_string(), params.clone());
            }
            Self::Response { id, outcome } => {
                object.insert("id".to_string(), json!(id));
                match outcome {
                    Ok(result) => object.insert("result".to_string(), result.clone()),
                    Err(error) => object.insert("error".to_string(), json!(error)),
                };
            }
        }
        serde_json::to_vec(&object).unwrap_or_default()
    }
}

#[cfg(test)]
mod tests;
