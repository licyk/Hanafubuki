//! The fault-injection backend speaks the protocol over its stdio. Its
//! being a test of this package also makes Cargo build it for the
//! workspace's tests, which find it beside their own binaries
//! (`test_support::test_backend`).

#![cfg(feature = "test-support")]

use std::io::{Read, Write};
use std::process::{Command, Stdio};

use hanafubuki_extension_protocol::{encode_frame, method, FrameDecoder, Id, Message};
use serde_json::json;

#[test]
fn it_initializes_and_shuts_down() {
    let data = tempfile_dir();
    let mut backend = Command::new(env!("CARGO_BIN_EXE_hanafubuki-test-backend"))
        .env("HANAFUBUKI_EXTENSION_DATA", &data)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .unwrap();
    let mut input = backend.stdin.take().unwrap();
    for (id, name) in [(1, method::INITIALIZE), (2, method::SHUTDOWN)] {
        let request = Message::request(Id::Number(id), name, json!({ "protocolVersion": 1 }));
        input.write_all(&encode_frame(&request.encode())).unwrap();
    }
    let mut output = Vec::new();
    backend
        .stdout
        .take()
        .unwrap()
        .read_to_end(&mut output)
        .unwrap();
    assert!(backend.wait().unwrap().success());
    let mut decoder = FrameDecoder::default();
    decoder.push(&output);
    let mut answered = Vec::new();
    while let Some(body) = decoder.next_frame().unwrap() {
        if let Message::Response {
            id: Some(id),
            outcome,
        } = Message::decode(&body).unwrap()
        {
            answered.push((id, outcome.unwrap()));
        }
    }
    assert!(answered.contains(&(Id::Number(2), json!({}))));
    let _ = std::fs::remove_dir_all(data);
}

fn tempfile_dir() -> std::path::PathBuf {
    let dir = std::env::temp_dir().join(format!("hanafubuki-test-backend-{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    dir
}
