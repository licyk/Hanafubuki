//! The backend's loop: read the application's messages, answer them.

use std::io::{ErrorKind, Read, Write};
use std::sync::Arc;

use hanafubuki_extension_protocol::{
    hooks, method, FrameDecoder, InitializeParams, InitializeResult, Message, RpcError,
    ToolDeclaration, UiCallParams, UiStateParams, PROTOCOL_VERSION,
};
use serde_json::{json, Value};

use crate::{Diagnostics, Host, InstanceDiagnostics, Ui};

/// What a backend does. Every method but [`Self::notification`] runs on a
/// thread of its own, so it may call the application through `host` and
/// wait.
pub trait Handler: Send + Sync + 'static {
    /// The hooks it implements (`protocol::hooks`); the application calls
    /// only these, through [`Self::request`]. `ui` is announced by
    /// [`Self::ui`], not here.
    fn hooks(&self) -> Vec<String> {
        Vec::new()
    }

    /// Its UI, when it has one: the hook `ui` is then announced (whatever
    /// [`Self::initialize`] answers), and `ui.state` and `ui.call` go to it
    /// instead of [`Self::request`].
    fn ui(&self) -> Option<&dyn Ui> {
        None
    }

    /// Its diagnostic documents, if any. The SDK announces `diagnostics`
    /// and dispatches `diagnostics.collect` to this provider.
    fn diagnostics(&self) -> Option<&dyn Diagnostics> {
        None
    }

    fn instance_diagnostics(&self) -> Option<&dyn InstanceDiagnostics> {
        None
    }

    /// The MCP tools it publishes on the host management MCP server beside
    /// the ones its manifest declares (and over one of those by name):
    /// each listed as `ext_<extension>__<name>` and called as
    /// `service.<name>` in [`Self::request`]. Changed while it runs with
    /// [`Host::register_tools`] and [`Host::unregister_tools`].
    fn tools(&self) -> Vec<ToolDeclaration> {
        Vec::new()
    }

    /// The answer to `initialize`: this protocol's version, its hooks and
    /// its tools.
    fn initialize(
        &self,
        host: &Host,
        params: &InitializeParams,
    ) -> Result<InitializeResult, RpcError> {
        let _ = (host, params);
        Ok(InitializeResult {
            protocol_version: PROTOCOL_VERSION,
            hooks: self.hooks(),
            tools: self.tools(),
        })
    }

    fn ping(&self, host: &Host) -> Result<(), RpcError> {
        let _ = host;
        Ok(())
    }

    /// Any other request: a hook, or a method of its own.
    fn request(&self, host: &Host, method: &str, params: Value) -> Result<Value, RpcError> {
        let _ = (host, params);
        Err(RpcError::method_not_found(method))
    }

    /// A notification (an event, a process's output). Runs on the loop's
    /// thread, so it returns quickly and never waits for a call.
    fn notification(&self, host: &Host, method: &str, params: Value) {
        let _ = (host, method, params);
    }

    /// The application asked it to shut down; [`run`] returns once this
    /// does and the answer is sent.
    fn shutdown(&self, host: &Host) {
        let _ = host;
    }
}

/// Runs `handler` over stdin and stdout until the application asks it to
/// shut down or closes stdin. An error is a stream that is not the
/// protocol.
pub fn run(handler: impl Handler) -> Result<(), String> {
    run_on(handler, std::io::stdin(), std::io::stdout())
}

/// [`run`] over any pair of streams.
pub fn run_on(
    handler: impl Handler,
    mut reader: impl Read,
    writer: impl Write + Send + 'static,
) -> Result<(), String> {
    let handler = Arc::new(handler);
    let host = Host::new(Box::new(writer));
    let mut decoder = FrameDecoder::default();
    let mut buffer = vec![0u8; 64 * 1024];
    let ended = loop {
        let read = match reader.read(&mut buffer) {
            Ok(0) => break Ok(()),
            Ok(read) => read,
            Err(error) if error.kind() == ErrorKind::Interrupted => continue,
            Err(error) => break Err(format!("read stdin: {error}")),
        };
        decoder.push(&buffer[..read]);
        match receive(&mut decoder, &handler, &host) {
            Ok(false) => {}
            Ok(true) => break Ok(()),
            Err(error) => break Err(error),
        }
    };
    host.close();
    ended
}

/// Handles every whole message `decoder` holds; `true` once one was
/// `shutdown`.
fn receive(
    decoder: &mut FrameDecoder,
    handler: &Arc<impl Handler>,
    host: &Host,
) -> Result<bool, String> {
    while let Some(body) = decoder.next_frame().map_err(|error| error.to_string())? {
        match Message::decode(&body)? {
            Message::Response {
                id: Some(id),
                outcome,
            } => host.resolve(&id, outcome),
            Message::Response { id: None, .. } => {}
            Message::Request { id, method, .. } if method == method::SHUTDOWN => {
                handler.shutdown(host);
                let _ = host.send(&Message::response(id, Ok(json!({}))));
                return Ok(true);
            }
            Message::Request { id, method, params } => {
                let (handler, host) = (handler.clone(), host.clone());
                std::thread::spawn(move || {
                    let outcome = dispatch(handler.as_ref(), &host, &method, params);
                    let _ = host.send(&Message::response(id, outcome));
                });
            }
            Message::Notification { method, params } => handler.notification(host, &method, params),
        }
    }
    Ok(false)
}

fn dispatch(
    handler: &impl Handler,
    host: &Host,
    method: &str,
    params: Value,
) -> Result<Value, RpcError> {
    match method {
        method::INITIALIZE => {
            let params: InitializeParams =
                serde_json::from_value(params).map_err(RpcError::invalid_params)?;
            host.initialized(params.clone());
            let mut result = handler.initialize(host, &params)?;
            if handler.ui().is_some() && !result.hooks.iter().any(|hook| hook == hooks::UI) {
                result.hooks.push(hooks::UI.to_string());
            }
            if handler.diagnostics().is_some()
                && !result.hooks.iter().any(|hook| hook == hooks::DIAGNOSTICS)
            {
                result.hooks.push(hooks::DIAGNOSTICS.to_string());
            }
            if handler.instance_diagnostics().is_some()
                && !result
                    .hooks
                    .iter()
                    .any(|hook| hook == hooks::INSTANCE_DIAGNOSTICS)
            {
                result.hooks.push(hooks::INSTANCE_DIAGNOSTICS.to_string());
            }
            Ok(serde_json::to_value(result).unwrap_or_default())
        }
        method::PING => handler.ping(host).map(|()| json!({})),
        method::DIAGNOSTICS_COLLECT_INSTANCE => match handler.instance_diagnostics() {
            Some(diagnostics) => {
                let params: hanafubuki_extension_protocol::InstancesGetParams =
                    serde_json::from_value(params).map_err(RpcError::invalid_params)?;
                serde_json::to_value(diagnostics.collect_instance(host, &params.id)?)
                    .map_err(|error| RpcError::failed(error.to_string()))
            }
            None => handler.request(host, method, params),
        },
        method::DIAGNOSTICS_COLLECT => match handler.diagnostics() {
            Some(diagnostics) => diagnostics.collect(host).and_then(|result| {
                serde_json::to_value(result).map_err(|error| RpcError::failed(error.to_string()))
            }),
            None => handler.request(host, method, params),
        },
        method::UI_STATE | method::UI_CALL => match handler.ui() {
            Some(ui) => ui_request(ui, host, method, params),
            None => handler.request(host, method, params),
        },
        _ => handler.request(host, method, params),
    }
}

fn ui_request(ui: &dyn Ui, host: &Host, method: &str, params: Value) -> Result<Value, RpcError> {
    if method == method::UI_STATE {
        let params: UiStateParams =
            serde_json::from_value(params).map_err(RpcError::invalid_params)?;
        return ui.state(host, &params.context);
    }
    let params: UiCallParams = serde_json::from_value(params).map_err(RpcError::invalid_params)?;
    ui.call(host, &params.action, params.args, &params.context)
}

#[cfg(test)]
mod tests;
