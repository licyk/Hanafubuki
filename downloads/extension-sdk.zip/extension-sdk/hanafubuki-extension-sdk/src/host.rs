//! The application, as a backend calls it.

use std::collections::HashMap;
use std::io::Write;
use std::sync::atomic::{AtomicBool, AtomicI64, Ordering};
use std::sync::mpsc;
use std::sync::{Arc, OnceLock};

use hanafubuki_extension_protocol::{
    codes, encode_frame, method, FrameEmitParams, Id, InitializeParams, LogWriteParams, Message,
    RpcError, ToolDeclaration, ToolsRegisterParams, ToolsUnregisterParams, UiEmitParams,
};
use parking_lot::Mutex;
use serde::de::DeserializeOwned;
use serde::Serialize;
use serde_json::Value;

/// The application at the other end of stdin and stdout. Clones are the
/// same connection; any thread may call.
#[derive(Clone)]
pub struct Host {
    inner: Arc<Inner>,
}

type Pending = mpsc::Sender<Result<Value, RpcError>>;

struct Inner {
    writer: Mutex<Box<dyn Write + Send>>,
    pending: Mutex<HashMap<i64, Pending>>,
    next_id: AtomicI64,
    closed: AtomicBool,
    initialize: OnceLock<InitializeParams>,
}

impl Host {
    pub(crate) fn new(writer: Box<dyn Write + Send>) -> Self {
        Self {
            inner: Arc::new(Inner {
                writer: Mutex::new(writer),
                pending: Mutex::new(HashMap::new()),
                next_id: AtomicI64::new(1),
                closed: AtomicBool::new(false),
                initialize: OnceLock::new(),
            }),
        }
    }

    /// What `initialize` said: the extension, its permissions, its data
    /// directory, the locale. `None` before it came.
    pub fn initialize_params(&self) -> Option<&InitializeParams> {
        self.inner.initialize.get()
    }

    /// Calls `method` and waits for its answer; fails with
    /// `codes::UNAVAILABLE` once the application closed the connection.
    pub fn call(&self, method: &str, params: Value) -> Result<Value, RpcError> {
        let id = self.inner.next_id.fetch_add(1, Ordering::Relaxed);
        let (sender, answer) = mpsc::channel();
        self.inner.pending.lock().insert(id, sender);
        if self.inner.closed.load(Ordering::Acquire) {
            self.inner.pending.lock().remove(&id);
            return Err(unavailable());
        }
        if let Err(error) = self.send(&Message::request(Id::Number(id), method, params)) {
            self.inner.pending.lock().remove(&id);
            return Err(RpcError::new(codes::UNAVAILABLE, error.to_string()));
        }
        answer.recv().unwrap_or_else(|_| Err(unavailable()))
    }

    /// [`Self::call`] with typed params and result.
    pub fn call_as<P: Serialize, R: DeserializeOwned>(
        &self,
        method: &str,
        params: &P,
    ) -> Result<R, RpcError> {
        let params = serde_json::to_value(params).map_err(RpcError::invalid_params)?;
        let result = self.call(method, params)?;
        serde_json::from_value(result)
            .map_err(|error| RpcError::new(codes::INTERNAL_ERROR, error.to_string()))
    }

    /// Sends a notification, which has no answer.
    pub fn notify(&self, method: &str, params: Value) -> std::io::Result<()> {
        self.send(&Message::notification(method, params))
    }

    /// Adds MCP tools, or replaces this backend's (or the manifest's) by
    /// name (`tools.register`); the sessions that list tools hear it. A tool
    /// the host cannot list refuses the whole message on the host's side,
    /// and none is registered.
    pub fn register_tools(&self, tools: Vec<ToolDeclaration>) {
        let params = serde_json::to_value(ToolsRegisterParams { tools }).unwrap_or_default();
        let _ = self.notify(method::TOOLS_REGISTER, params);
    }

    /// Removes MCP tools by name (`tools.unregister`); a manifest's is
    /// listed again once the backend's over it is removed.
    pub fn unregister_tools(&self, names: &[&str]) {
        let params = ToolsUnregisterParams {
            names: names.iter().map(|name| name.to_string()).collect(),
        };
        let _ = self.notify(
            method::TOOLS_UNREGISTER,
            serde_json::to_value(params).unwrap_or_default(),
        );
    }

    /// Sends `event` to its frame `frame` (`ui.frame.emit`): each open frame
    /// of that id hands it to its page's listeners of the event. No other
    /// extension's frame hears it.
    pub fn emit_frame(&self, frame: &str, event: &str, payload: Value) -> std::io::Result<()> {
        self.emit_frame_for(None, frame, event, payload)
    }

    /// Sends an event to the frame for one instance, or broadcasts with `None`.
    pub fn emit_frame_for(
        &self,
        instance_id: Option<&str>,
        frame: &str,
        event: &str,
        payload: Value,
    ) -> std::io::Result<()> {
        let params = FrameEmitParams {
            instance_id: instance_id.map(str::to_string),
            frame: frame.to_string(),
            event: event.to_string(),
            payload,
        };
        self.notify(
            method::UI_FRAME_EMIT,
            serde_json::to_value(params).unwrap_or_default(),
        )
    }

    /// Pushes `state` as its UI's new state (`ui.emit`) to every window
    /// and frame showing it. Only a backend whose handler has a
    /// [`crate::Ui`] is heard, once its row exposed the UI: a state sent
    /// before (during `activate`) is dropped, and a window reads
    /// [`crate::Ui::state`] when it starts showing it anyway.
    pub fn emit_state(&self, state: Value) -> std::io::Result<()> {
        self.emit_state_for(None, state)
    }

    /// Pushes state for one instance, or broadcasts with `None`.
    pub fn emit_state_for(&self, instance_id: Option<&str>, state: Value) -> std::io::Result<()> {
        let params = UiEmitParams {
            instance_id: instance_id.map(str::to_string),
            state,
        };
        self.notify(
            method::UI_EMIT,
            serde_json::to_value(params).unwrap_or_default(),
        )
    }

    /// Writes a line to the extension's log.
    pub fn log(&self, level: &str, message: &str) {
        let params = LogWriteParams {
            level: level.to_string(),
            message: message.to_string(),
        };
        let _ = self.notify(
            method::LOG_WRITE,
            serde_json::to_value(params).unwrap_or_default(),
        );
    }

    pub(crate) fn initialized(&self, params: InitializeParams) {
        let _ = self.inner.initialize.set(params);
    }

    pub(crate) fn send(&self, message: &Message) -> std::io::Result<()> {
        let frame = encode_frame(&message.encode());
        let mut writer = self.inner.writer.lock();
        writer.write_all(&frame)?;
        writer.flush()
    }

    /// Hands the answer to the call `id`; one nobody waits for is dropped.
    pub(crate) fn resolve(&self, id: &Id, outcome: Result<Value, RpcError>) {
        let Id::Number(id) = id else {
            return;
        };
        if let Some(waiting) = self.inner.pending.lock().remove(id) {
            let _ = waiting.send(outcome);
        }
    }

    /// The connection ended: every call waiting fails, and later ones too.
    pub(crate) fn close(&self) {
        self.inner.closed.store(true, Ordering::Release);
        self.inner.pending.lock().clear();
    }
}

fn unavailable() -> RpcError {
    RpcError::new(codes::UNAVAILABLE, "the application closed the connection")
}
