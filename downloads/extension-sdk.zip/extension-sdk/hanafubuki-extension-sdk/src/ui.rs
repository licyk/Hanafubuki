//! A backend's UI in the owner protocol: the state its panels' `state`
//! blocks and its frames show, and the actions they call.

use hanafubuki_extension_protocol::{PanelContext, RpcError};
use serde_json::Value;

use crate::Host;

/// What a backend's UI is (the hook `ui`). A [`crate::Handler`] whose
/// [`crate::Handler::ui`] returns one announces the hook and has `ui.state`
/// and `ui.call` answered by it; each runs on a thread of its own. The
/// backend pushes a new state with [`Host::emit_state`].
pub trait Ui: Send + Sync {
    /// Its state where it is shown (`ui.state`): what a window reads when it
    /// starts showing it, and again when the UI is exposed anew.
    fn state(&self, host: &Host, context: &PanelContext) -> Result<Value, RpcError>;

    /// One of its actions (`ui.call`), answered to its caller only. An
    /// error keeps its kind: `invalid_params` is `invalid`,
    /// `permission_denied` `forbidden`, any other `failed`.
    fn call(
        &self,
        host: &Host,
        action: &str,
        args: Value,
        context: &PanelContext,
    ) -> Result<Value, RpcError> {
        let _ = (host, args, context);
        Err(RpcError::invalid_params(format!("no action `{action}`")))
    }
}
