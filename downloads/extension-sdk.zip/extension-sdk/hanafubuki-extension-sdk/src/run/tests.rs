use std::io::{PipeReader, Write};
use std::sync::Arc;
use std::time::{Duration, Instant};

use hanafubuki_extension_protocol::{codes, encode_frame, hooks, FrameDecoder, Id, PanelContext};
use parking_lot::Mutex;
use serde_json::json;

use super::*;

/// Collects what the backend writes.
#[derive(Clone, Default)]
struct Written(Arc<Mutex<Vec<u8>>>);

impl Write for Written {
    fn write(&mut self, bytes: &[u8]) -> std::io::Result<usize> {
        self.0.lock().extend_from_slice(bytes);
        Ok(bytes.len())
    }

    fn flush(&mut self) -> std::io::Result<()> {
        Ok(())
    }
}

impl Written {
    fn messages(&self) -> Vec<Message> {
        let mut decoder = FrameDecoder::default();
        decoder.push(&self.0.lock());
        let mut messages = Vec::new();
        while let Some(body) = decoder.next_frame().unwrap() {
            messages.push(Message::decode(&body).unwrap());
        }
        messages
    }

    /// The answer to `id`, once it is written.
    fn answer(&self, id: i64) -> Result<Value, RpcError> {
        let deadline = Instant::now() + Duration::from_secs(10);
        loop {
            for message in self.messages() {
                if let Message::Response {
                    id: Some(Id::Number(answered)),
                    outcome,
                } = message
                {
                    if answered == id {
                        return outcome;
                    }
                }
            }
            assert!(Instant::now() < deadline, "no answer to {id}");
            std::thread::sleep(Duration::from_millis(10));
        }
    }
}

struct Echo;

struct WithDiagnostics;

impl Handler for WithDiagnostics {
    fn diagnostics(&self) -> Option<&dyn Diagnostics> {
        Some(self)
    }
}

impl Diagnostics for WithDiagnostics {
    fn collect(
        &self,
        _host: &Host,
    ) -> Result<hanafubuki_extension_protocol::DiagnosticsCollectResult, RpcError> {
        Ok(hanafubuki_extension_protocol::DiagnosticsCollectResult {
            documents: vec![hanafubuki_extension_protocol::DiagnosticDocument {
                name: "state.json".into(),
                text: "{\"ready\":true}".into(),
            }],
        })
    }
}

#[test]
fn diagnostics_provider_is_announced_and_called_over_the_real_loop() {
    let (mut input, written, loop_thread) = running_with(WithDiagnostics);
    send(
        &mut input,
        Message::request(Id::Number(1), method::INITIALIZE, json!({})),
    );
    assert_eq!(
        written.answer(1).unwrap()["hooks"],
        json!([hooks::DIAGNOSTICS])
    );
    send(
        &mut input,
        Message::request(
            Id::Number(2),
            method::DIAGNOSTICS_COLLECT,
            json!({"future": true}),
        ),
    );
    assert_eq!(
        written.answer(2).unwrap(),
        json!({"documents":[{"name":"state.json", "text":"{\"ready\":true}"}]})
    );
    drop(input);
    assert_eq!(loop_thread.join().unwrap(), Ok(()));
}

impl Handler for Echo {
    fn hooks(&self) -> Vec<String> {
        vec![hooks::ACTIVATE.to_string()]
    }

    fn request(&self, host: &Host, method: &str, params: Value) -> Result<Value, RpcError> {
        match method {
            "echo" => Ok(params),
            // Calls the application and answers with what it said.
            "ask" => host.call("host.info", Value::Null),
            _ => Err(RpcError::method_not_found(method)),
        }
    }
}

fn send(input: &mut impl Write, message: Message) {
    input.write_all(&encode_frame(&message.encode())).unwrap();
}

fn running() -> (
    std::io::PipeWriter,
    Written,
    std::thread::JoinHandle<Result<(), String>>,
) {
    running_with(Echo)
}

fn running_with(
    handler: impl Handler,
) -> (
    std::io::PipeWriter,
    Written,
    std::thread::JoinHandle<Result<(), String>>,
) {
    let (reader, input): (PipeReader, _) = std::io::pipe().unwrap();
    let written = Written::default();
    let output = written.clone();
    let loop_thread = std::thread::spawn(move || run_on(handler, reader, output));
    (input, written, loop_thread)
}

/// A handler with a UI: its state is its context, `push` emits its args.
struct WithUi;

impl Handler for WithUi {
    fn ui(&self) -> Option<&dyn Ui> {
        Some(self)
    }
}

impl Ui for WithUi {
    fn state(&self, _host: &Host, context: &PanelContext) -> Result<Value, RpcError> {
        Ok(json!({ "shownFor": context.instance_id }))
    }

    fn call(
        &self,
        host: &Host,
        action: &str,
        args: Value,
        _context: &PanelContext,
    ) -> Result<Value, RpcError> {
        match action {
            "push" => {
                host.emit_state(args).unwrap();
                Ok(json!({}))
            }
            _ => Err(RpcError::invalid_params(format!("no action `{action}`"))),
        }
    }
}

#[test]
fn it_answers_initialize_ping_its_requests_and_shuts_down() {
    let (mut input, written, loop_thread) = running();
    send(
        &mut input,
        Message::request(
            Id::Number(1),
            method::INITIALIZE,
            json!({ "protocolVersion": 1 }),
        ),
    );
    let initialized: InitializeResult = serde_json::from_value(written.answer(1).unwrap()).unwrap();
    assert_eq!(
        initialized,
        InitializeResult {
            protocol_version: PROTOCOL_VERSION,
            hooks: vec!["activate".to_string()],
            tools: Vec::new()
        }
    );
    send(
        &mut input,
        Message::request(Id::Number(2), method::PING, Value::Null),
    );
    assert_eq!(written.answer(2), Ok(json!({})));
    send(
        &mut input,
        Message::request(Id::Number(3), "echo", json!([1, 2])),
    );
    assert_eq!(written.answer(3), Ok(json!([1, 2])));
    send(
        &mut input,
        Message::request(Id::Number(4), "nothing", Value::Null),
    );
    assert_eq!(written.answer(4).unwrap_err().code, codes::METHOD_NOT_FOUND);
    send(
        &mut input,
        Message::request(Id::Number(5), method::SHUTDOWN, Value::Null),
    );
    assert_eq!(loop_thread.join().unwrap(), Ok(()));
    assert_eq!(written.answer(5), Ok(json!({})));
}

#[test]
fn a_handler_calls_the_application_while_the_loop_reads_its_answer() {
    let (mut input, written, loop_thread) = running();
    send(
        &mut input,
        Message::request(Id::Number(1), "ask", Value::Null),
    );
    // The backend's own call to the host is the first request it writes.
    let deadline = Instant::now() + Duration::from_secs(10);
    let asked = loop {
        let asked = written
            .messages()
            .into_iter()
            .find_map(|message| match message {
                Message::Request { id, method, .. } if method == "host.info" => Some(id),
                _ => None,
            });
        if let Some(asked) = asked {
            break asked;
        }
        assert!(Instant::now() < deadline, "the backend did not call");
        std::thread::sleep(Duration::from_millis(10));
    };
    send(
        &mut input,
        Message::response(asked, Ok(json!({ "version": "9" }))),
    );
    assert_eq!(written.answer(1), Ok(json!({ "version": "9" })));
    drop(input);
    assert_eq!(loop_thread.join().unwrap(), Ok(()));
}

#[test]
fn a_stream_that_is_not_frames_ends_the_loop() {
    let (mut input, _written, loop_thread) = running();
    input.write_all(b"hello\r\n\r\n").unwrap();
    assert!(loop_thread.join().unwrap().is_err());
}

#[test]
fn a_handler_with_a_ui_announces_it_answers_its_state_and_calls_and_emits() {
    let (mut input, written, loop_thread) = running_with(WithUi);
    send(
        &mut input,
        Message::request(Id::Number(1), method::INITIALIZE, json!({})),
    );
    assert_eq!(written.answer(1).unwrap()["hooks"], json!([hooks::UI]));
    send(
        &mut input,
        Message::request(
            Id::Number(2),
            method::UI_STATE,
            json!({ "context": { "instanceId": "i-1" }, "future": 1 }),
        ),
    );
    assert_eq!(written.answer(2), Ok(json!({ "shownFor": "i-1" })));
    send(
        &mut input,
        Message::request(
            Id::Number(3),
            method::UI_CALL,
            json!({ "action": "push", "args": { "jobs": 2 } }),
        ),
    );
    assert_eq!(written.answer(3), Ok(json!({})));
    assert!(written.messages().contains(&Message::notification(
        method::UI_EMIT,
        json!({ "state": { "jobs": 2 } })
    )));
    send(
        &mut input,
        Message::request(Id::Number(4), method::UI_CALL, json!({ "action": "x" })),
    );
    assert_eq!(written.answer(4).unwrap_err().code, codes::INVALID_PARAMS);
    send(
        &mut input,
        Message::request(Id::Number(5), method::UI_STATE, json!({ "context": 3 })),
    );
    assert_eq!(written.answer(5).unwrap_err().code, codes::INVALID_PARAMS);
    drop(input);
    assert_eq!(loop_thread.join().unwrap(), Ok(()));
}

#[test]
fn a_handler_without_a_ui_announces_none_and_hears_its_methods_as_requests() {
    let (mut input, written, loop_thread) = running();
    send(
        &mut input,
        Message::request(Id::Number(1), method::INITIALIZE, json!({})),
    );
    assert_eq!(
        written.answer(1).unwrap()["hooks"],
        json!([hooks::ACTIVATE])
    );
    send(
        &mut input,
        Message::request(Id::Number(2), method::UI_STATE, json!({})),
    );
    assert_eq!(written.answer(2).unwrap_err().code, codes::METHOD_NOT_FOUND);
    drop(input);
    assert_eq!(loop_thread.join().unwrap(), Ok(()));
}

#[test]
fn emit_frame_sends_the_event_to_its_frame_as_a_notification() {
    let written = Written::default();
    let host = Host::new(Box::new(written.clone()));
    host.emit_frame("main", "progress", json!({ "done": 1 }))
        .unwrap();
    assert_eq!(
        written.messages(),
        [Message::notification(
            method::UI_FRAME_EMIT,
            json!({ "frame": "main", "event": "progress", "payload": { "done": 1 } })
        )]
    );
}
