use std::collections::{BTreeMap, BTreeSet};

use hanafubuki_extension_protocol::{Direction, METHODS};

/// The values of the protocol's `method` constants, by constant name.
fn method_names() -> BTreeMap<&'static str, &'static str> {
    let source = include_str!("../../../hanafubuki-extension-protocol/src/methods.rs");
    let start = source.find("pub mod method {").unwrap();
    let body = &source[start..start + source[start..].find("\n}\n").unwrap()];
    body.lines()
        .filter_map(|line| line.trim().strip_prefix("pub const "))
        .map(|constant| {
            let name = constant.split(':').next().unwrap();
            (name, constant.split('"').nth(1).unwrap())
        })
        .collect()
}

/// The methods `source` sends: each `method::NAME` it names.
fn sent(source: &str) -> BTreeSet<&'static str> {
    let names = method_names();
    source
        .split("method::")
        .skip(1)
        .map(|rest| {
            let constant: String = rest
                .chars()
                .take_while(|character| character.is_ascii_uppercase() || *character == '_')
                .collect();
            *names
                .get(constant.as_str())
                .unwrap_or_else(|| panic!("no method constant {constant}"))
        })
        .collect()
}

#[test]
fn every_host_api_method_of_the_registry_has_a_wrapper() {
    let wrapped: BTreeSet<_> = sent(include_str!("../calls.rs"))
        .union(&sent(include_str!("../host.rs")))
        .copied()
        .collect();
    let registry: BTreeSet<_> = METHODS
        .iter()
        .filter(|spec| spec.direction == Direction::BackendToHost)
        .map(|spec| spec.name)
        .collect();
    assert_eq!(wrapped, registry);
}
