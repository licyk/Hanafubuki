//! Where the fault-injection backend (`hanafubuki-test-backend`, built
//! with this crate's `test-support` feature) is, for tests in any crate of
//! the workspace.

use std::path::PathBuf;

/// The test backend binary beside the running test's own: Cargo puts a
/// workspace's binaries in the directory above a test's `deps/`.
pub fn test_backend() -> PathBuf {
    let current = std::env::current_exe().expect("the running test's path");
    let profile = current
        .parent()
        .and_then(|deps| deps.parent())
        .expect("a test runs from <target>/<profile>/deps");
    let backend = profile.join(format!(
        "hanafubuki-test-backend{}",
        std::env::consts::EXE_SUFFIX
    ));
    assert!(
        backend.is_file(),
        "{} is not built: run the workspace's tests with --all-features, or `cargo build -p \
         hanafubuki-extension-sdk --features test-support --bin hanafubuki-test-backend`",
        backend.display()
    );
    backend
}
