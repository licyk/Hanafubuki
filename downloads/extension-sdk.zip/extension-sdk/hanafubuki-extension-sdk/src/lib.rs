//! Writing an extension's backend in Rust (`docs/extension-protocol.md`).
//!
//! A backend is a program the application starts with the protocol on its
//! stdin and stdout. [`run`] reads the application's messages until it
//! asks the backend to shut down or closes stdin: it answers `initialize`
//! and `ping` itself (through the [`Handler`]'s defaults) and hands every
//! other request to the handler, each on its own thread, so a long call
//! never holds up the others or a ping. The handler reaches the
//! application through [`Host`], whose calls wait for their answers, each
//! method of the host API with a typed wrapper (`host.list_tools()`). A
//! backend with a UI in the owner protocol (the hook `ui`) gives its
//! handler a [`Ui`] and pushes its state with [`Host::emit_state`].
//!
//! Stdout is the protocol's: a backend writes nothing else there. What it
//! writes to stderr goes to its log, which the Extensions page shows.

mod calls;
mod diagnostics;
mod host;
mod run;
#[cfg(any(test, feature = "test-support"))]
pub mod test_support;
mod ui;

pub use diagnostics::{Diagnostics, InstanceDiagnostics};
pub use hanafubuki_extension_protocol as protocol;
pub use host::Host;
pub use run::{run, run_on, Handler};
pub use ui::Ui;
