//! A typed wrapper for each method of the host API (the protocol's
//! registry, `METHODS`, a backend's calls on the host): each sends its
//! method with its params type and reads its result type, as
//! `docs/extension-protocol.md` describes it. `log.write`, `ui.frame.emit`
//! and `ui.emit` are [`Host::log`], [`Host::emit_frame`] and
//! [`Host::emit_state`]. A test keeps one wrapper per method of the
//! registry.

use hanafubuki_extension_protocol::{
    method, DownloadFetchParams, DownloadFetchResult, EventsSubscribeParams, EventsSubscribeResult,
    GitCloneParams, GitPullParams, HostInfoResult, HostPreferences, HttpRequestParams,
    HttpRequestResult, InstanceConfigurationResult, InstanceView, InstancesGetParams,
    InstancesImportParams, InstancesImportResult, InstancesOfTypeParams, InstancesResult,
    InstancesScanParams, InstancesScanResult, ProcessCancelParams, ProcessRunParams,
    ProcessRunResult, PythonEnsureParams, PythonEnsureResult, RpcError, ServersResult,
    ServersStatusParams, ServicesCallParams, SettingsPatchParams, SettingsResult,
    StoragePathResult, ToolsCallParams, ToolsListResult, UiNotifyParams, UiProgressParams,
    WebviewNavigateParams, WebviewPageParams, WebviewPagesParams, WebviewPagesResult,
};
use hanafubuki_extension_protocol::{
    RuntimeResolveParams, RuntimeResolveResult, RuntimeStatusParams, RuntimeStatusResult,
};
use serde_json::{json, Value};

use crate::Host;

impl Host {
    /// `host.info`: the application's version, locale, platform, instance
    /// directory, what it serves (`capabilities`) and the user's download
    /// mirrors (`mirrors`); `download_fetch` applies them for explicit sources.
    pub fn host_info(&self) -> Result<HostInfoResult, RpcError> {
        self.call_as(method::HOST_INFO, &json!({}))
    }

    /// `host.preferences`: current non-sensitive preferences, also sent by the
    /// `preferences` topic. Includes no proxy addresses or credentials.
    pub fn host_preferences(&self) -> Result<HostPreferences, RpcError> {
        self.call_as(method::HOST_PREFERENCES, &json!({}))
    }

    /// `runtime.status`: read current tool readiness without preparing anything.
    pub fn runtime_status(
        &self,
        params: &RuntimeStatusParams,
    ) -> Result<RuntimeStatusResult, RpcError> {
        self.call_as(method::RUNTIME_STATUS, params)
    }

    /// `runtime.resolve`: wait for the host's tool preparation and return its
    /// native executable path; requires the processes permission.
    pub fn runtime_resolve(
        &self,
        params: &RuntimeResolveParams,
    ) -> Result<RuntimeResolveResult, RpcError> {
        self.call_as(method::RUNTIME_RESOLVE, params)
    }

    /// `settings.get`: its own settings' values.
    pub fn settings(&self) -> Result<SettingsResult, RpcError> {
        self.call_as(method::SETTINGS_GET, &json!({}))
    }

    /// `settings.patch`: persist declared settings; null removes a saved override.
    /// Returns canonical values after the host's successful write and notification.
    pub fn settings_patch(&self, params: &SettingsPatchParams) -> Result<SettingsResult, RpcError> {
        self.call_as(method::SETTINGS_PATCH, params)
    }

    /// `storage.path`: its data directory.
    pub fn storage_path(&self) -> Result<StoragePathResult, RpcError> {
        self.call_as(method::STORAGE_PATH, &json!({}))
    }

    /// `instances.list`: every instance, read only.
    pub fn instances_list(&self) -> Result<InstancesResult, RpcError> {
        self.call_as(method::INSTANCES_LIST, &json!({}))
    }

    /// `instances.configuration`: non-secret fields of an instance of its own types.
    pub fn instance_configuration(
        &self,
        params: &InstancesGetParams,
    ) -> Result<InstanceConfigurationResult, RpcError> {
        self.call_as(method::INSTANCES_CONFIGURATION, params)
    }

    /// `instances.get`: one instance.
    pub fn instances_get(&self, params: &InstancesGetParams) -> Result<InstanceView, RpcError> {
        self.call_as(method::INSTANCES_GET, params)
    }

    /// `instances.ofType`: the instances of its own types.
    pub fn instances_of_type(
        &self,
        params: &InstancesOfTypeParams,
    ) -> Result<InstancesResult, RpcError> {
        self.call_as(method::INSTANCES_OF_TYPE, params)
    }

    /// `instances.scan`: the application's discovery on one directory;
    /// waits until it is done.
    pub fn instances_scan(
        &self,
        params: &InstancesScanParams,
    ) -> Result<InstancesScanResult, RpcError> {
        self.call_as(method::INSTANCES_SCAN, params)
    }

    /// `instances.import`: one directory imported as a ready instance.
    pub fn instances_import(
        &self,
        params: &InstancesImportParams,
    ) -> Result<InstancesImportResult, RpcError> {
        self.call_as(method::INSTANCES_IMPORT, params)
    }

    /// `servers.status`: the server roles of its own types' instances.
    pub fn servers_status(&self, params: &ServersStatusParams) -> Result<ServersResult, RpcError> {
        self.call_as(method::SERVERS_STATUS, params)
    }

    /// `webview.pages`: the embedded WebUI pages of its own types' instances
    /// that are open.
    pub fn webview_pages(
        &self,
        params: &WebviewPagesParams,
    ) -> Result<WebviewPagesResult, RpcError> {
        self.call_as(method::WEBVIEW_PAGES, params)
    }

    /// `webview.show`: asks the application window to show one page of one
    /// launch of one of its instances.
    pub fn webview_show(&self, params: &WebviewPageParams) -> Result<(), RpcError> {
        self.call_as::<_, Value>(method::WEBVIEW_SHOW, params)
            .map(drop)
    }

    /// `webview.close`: closes one page that waits off screen; the page on
    /// screen is closed with its workspace.
    pub fn webview_close(&self, params: &WebviewPageParams) -> Result<(), RpcError> {
        self.call_as::<_, Value>(method::WEBVIEW_CLOSE, params)
            .map(drop)
    }

    /// `webview.reload`: reloads one open page's document.
    pub fn webview_reload(&self, params: &WebviewPageParams) -> Result<(), RpcError> {
        self.call_as::<_, Value>(method::WEBVIEW_RELOAD, params)
            .map(drop)
    }

    /// `webview.navigate`: takes one open page to an HTTP(S) address on its
    /// authorized origin.
    pub fn webview_navigate(&self, params: &WebviewNavigateParams) -> Result<(), RpcError> {
        self.call_as::<_, Value>(method::WEBVIEW_NAVIGATE, params)
            .map(drop)
    }

    /// `process.run`: a program run as one of its tasks.
    pub fn process_run(&self, params: &ProcessRunParams) -> Result<ProcessRunResult, RpcError> {
        self.call_as(method::PROCESS_RUN, params)
    }

    /// `process.cancel`: one of its tasks cancelled.
    pub fn process_cancel(&self, params: &ProcessCancelParams) -> Result<(), RpcError> {
        self.call_as::<_, Value>(method::PROCESS_CANCEL, params)
            .map(drop)
    }

    /// `http.request`: bounded UTF-8 HTTP through the host's network policy.
    /// HTTP error statuses are returned normally in `status`.
    pub fn http_request(&self, params: &HttpRequestParams) -> Result<HttpRequestResult, RpcError> {
        self.call_as(method::HTTP_REQUEST, params)
    }

    /// `download.fetch`: a file downloaded into its data directory.
    pub fn download_fetch(
        &self,
        params: &DownloadFetchParams,
    ) -> Result<DownloadFetchResult, RpcError> {
        self.call_as(method::DOWNLOAD_FETCH, params)
    }

    /// `events.subscribe`: its subscription replaced.
    pub fn events_subscribe(
        &self,
        params: &EventsSubscribeParams,
    ) -> Result<EventsSubscribeResult, RpcError> {
        self.call_as(method::EVENTS_SUBSCRIBE, params)
    }

    /// Queue a question. Its answer is a later `ui.prompt.result` notification.
    pub fn ui_prompt(
        &self,
        params: &hanafubuki_extension_protocol::UiPromptParams,
    ) -> Result<(), RpcError> {
        self.call_as::<_, Value>(method::UI_PROMPT, params)
            .map(|_| ())
    }

    /// `ui.notify`: a notice in the Task Center.
    pub fn ui_notify(&self, params: &UiNotifyParams) -> Result<(), RpcError> {
        self.call_as::<_, Value>(method::UI_NOTIFY, params)
            .map(drop)
    }

    /// `ui.progress`: a progress activity shown or updated.
    pub fn ui_progress(&self, params: &UiProgressParams) -> Result<(), RpcError> {
        self.call_as::<_, Value>(method::UI_PROGRESS, params)
            .map(drop)
    }

    /// `ui.taskCenter.open`: the Task Center is asked to show the tab one of
    /// its panels or frames is.
    pub fn ui_task_center_open(
        &self,
        params: &hanafubuki_extension_protocol::UiTaskCenterOpenParams,
    ) -> Result<(), RpcError> {
        self.call_as::<_, Value>(method::UI_TASK_CENTER_OPEN, params)
            .map(drop)
    }

    /// `python.ensure`: a standalone Python installed as one of its tasks.
    pub fn python_ensure(
        &self,
        params: &PythonEnsureParams,
    ) -> Result<PythonEnsureResult, RpcError> {
        self.call_as(method::PYTHON_ENSURE, params)
    }

    /// `git.clone`: a repository cloned as one of its tasks.
    pub fn git_clone(&self, params: &GitCloneParams) -> Result<ProcessRunResult, RpcError> {
        self.call_as(method::GIT_CLONE, params)
    }

    /// `git.pull`: a repository fast-forwarded as one of its tasks.
    pub fn git_pull(&self, params: &GitPullParams) -> Result<ProcessRunResult, RpcError> {
        self.call_as(method::GIT_PULL, params)
    }

    /// `services.call`: a method another extension's backend exports.
    pub fn services_call(&self, params: &ServicesCallParams) -> Result<Value, RpcError> {
        self.call_as(method::SERVICES_CALL, params)
    }

    /// `tools.list`: the management catalog's tools (`management = read`
    /// or `confirm`).
    pub fn list_tools(&self) -> Result<ToolsListResult, RpcError> {
        self.call_as(method::TOOLS_LIST, &json!({}))
    }

    /// `tools.call`: the catalog's tool `name` run with `arguments`; a
    /// mutation waits for the user's answer (`management = confirm`).
    /// Answers the tool's own result.
    pub fn call_tool(&self, name: &str, arguments: Value) -> Result<Value, RpcError> {
        let params = ToolsCallParams {
            name: name.to_string(),
            arguments,
        };
        self.call_as(method::TOOLS_CALL, &params)
    }
}

#[cfg(test)]
mod tests;
