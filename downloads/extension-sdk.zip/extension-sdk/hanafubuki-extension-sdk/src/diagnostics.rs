//! An optional backend contribution to the application's diagnostic bundle.

use hanafubuki_extension_protocol::{DiagnosticsCollectResult, RpcError};

use crate::Host;

/// Returning this from [`crate::Handler::diagnostics`] announces the
/// `diagnostics` hook and routes `diagnostics.collect` to this provider.
pub trait Diagnostics: Send + Sync {
    /// Text documents for this extension's diagnostic directory. Names are
    /// filenames, not paths. Do not include credentials or secret settings.
    fn collect(&self, host: &Host) -> Result<DiagnosticsCollectResult, RpcError>;
}

/// Optional documents for an instance of this extension's type.
pub trait InstanceDiagnostics: Send + Sync {
    fn collect_instance(
        &self,
        host: &Host,
        instance_id: &str,
    ) -> Result<DiagnosticsCollectResult, RpcError>;
}
