//! The fault-injection backend: a backend on this SDK that misbehaves on
//! request, for the tests of the application's supervision.
//!
//! How it starts is read from `test-backend.mode` in its working directory
//! (the extension's version directory), one word and an optional number:
//! `healthy` (the default), `crash-at-start`, `version-mismatch`, `no-ping`,
//! `ignore-shutdown`, `crash-after-activate`, `slow-start <ms>`, `no-ui`. What it does
//! later is asked through its methods (`test.*`). Each start appends its
//! pid to `starts` and each hook its name to `hooks` in the extension's data
//! directory, so a test can count them.
//! `diagnostics` contributes text and JSON; `diagnostics-invalid`,
//! `diagnostics-timeout`, `diagnostics-count`, `diagnostics-bytes` and
//! `diagnostics-duplicate` exercise its collector's admission and timeout.
//!
//! As the provider of instance types it refuses a `name` of `bad`, plans an
//! install by its `plan` value (`good`: a written file and a run of itself;
//! `slow`: the same with a run of itself that first sleeps
//! `test-backend.slow` milliseconds; `escape`: a file outside its
//! component; `crash`: it exits), plans a role's command as itself serving
//! HTTP on the port, answers an update check with `1.0` → `2.0` (none for a
//! `name` of `pinned`, a failure for `offline`), and answers the operation
//! `greet` at once and `wait` after sleeping `test-backend.slow`
//! milliseconds. Its frames' calls (`ui.frame.call`) answer by their
//! `method`: `echo` with what it was given, `fail` with an error, `hang`
//! never, `emit` by sending its params' `event` to the frame as a
//! `ui.frame.emit`. It announces the hook `ui` (unless started in mode
//! `no-ui`): its `ui.state` is its context, how many states it emitted and
//! the last one (`last`), and its `ui.call` answers by `action`: `echo` with what it was given,
//! `forbid` and `invalid` with those errors, `emit` by sending `args` as
//! its state (`ui.emit`), anything else with a failure. Run with
//! `--write <file> <text>` it writes the file, and with `--serve <port>` it
//! answers every HTTP request with 200; with `--sleep <ms>` it sleeps.

use std::fs::OpenOptions;
use std::io::Write;
use std::path::PathBuf;
use std::time::Duration;

use hanafubuki_extension_sdk::protocol::{
    hooks, method, DiagnosticDocument, DiagnosticsCollectResult, InitializeParams,
    InitializeResult, PanelContext, RpcError, ToolDeclaration, MAX_FRAME_BYTES,
};
use hanafubuki_extension_sdk::{run, Diagnostics, Handler, Host, InstanceDiagnostics, Ui};
use parking_lot::Mutex;
use serde_json::{json, Value};

struct Mode {
    word: String,
    number: u64,
}

fn mode() -> Mode {
    let text = std::fs::read_to_string("test-backend.mode").unwrap_or_default();
    let mut words = text.split_whitespace();
    Mode {
        word: words.next().unwrap_or("healthy").to_string(),
        number: words.next().and_then(|n| n.parse().ok()).unwrap_or(0),
    }
}

fn data_dir() -> PathBuf {
    PathBuf::from(std::env::var_os("HANAFUBUKI_EXTENSION_DATA").unwrap_or_default())
}

fn append(file: &str, line: &str) {
    let path = data_dir().join(file);
    let _ = std::fs::create_dir_all(data_dir());
    if let Ok(mut file) = OpenOptions::new().create(true).append(true).open(path) {
        let _ = writeln!(file, "{line}");
    }
}

fn forever() -> ! {
    loop {
        std::thread::sleep(Duration::from_secs(3600));
    }
}

struct Backend {
    mode: Mode,
    /// The notifications it received, as `method` and params.
    received: Mutex<Vec<Value>>,
    /// How many UI states it emitted, and the last.
    emitted: Mutex<(u64, Value)>,
}

impl Handler for Backend {
    fn hooks(&self) -> Vec<String> {
        [
            hooks::ACTIVATE,
            hooks::DEACTIVATE,
            hooks::MIGRATE,
            hooks::UNINSTALL,
        ]
        .map(String::from)
        .to_vec()
    }

    fn ui(&self) -> Option<&dyn Ui> {
        (self.mode.word != "no-ui").then_some(self as &dyn Ui)
    }

    fn instance_diagnostics(&self) -> Option<&dyn InstanceDiagnostics> {
        (self.mode.word == "diagnostics-instance").then_some(self)
    }

    fn diagnostics(&self) -> Option<&dyn Diagnostics> {
        self.mode
            .word
            .starts_with("diagnostics")
            .then_some(self as &dyn Diagnostics)
    }

    fn initialize(
        &self,
        _host: &Host,
        _params: &InitializeParams,
    ) -> Result<InitializeResult, RpcError> {
        if self.mode.word == "slow-start" {
            std::thread::sleep(Duration::from_millis(self.mode.number));
        }
        let protocol_version = match self.mode.word.as_str() {
            "version-mismatch" => 99,
            _ => 1,
        };
        Ok(InitializeResult {
            protocol_version,
            hooks: self.hooks(),
            tools: self.tools(),
        })
    }

    /// In the `tools` mode: a tool of its own, and one over the manifest's
    /// `inline` by name, so a row lists the backend's in its place.
    fn tools(&self) -> Vec<ToolDeclaration> {
        if self.mode.word != "tools" {
            return Vec::new();
        }
        [
            ("runtime", "From the backend at run time"),
            ("inline", "The backend's, over the manifest's"),
        ]
        .into_iter()
        .map(|(name, description)| ToolDeclaration {
            name: name.to_string(),
            description: description.to_string(),
            input_schema: serde_json::from_value(serde_json::json!({
                "type": "object",
                "properties": { "who": { "type": "string" } }
            }))
            .unwrap(),
        })
        .collect()
    }

    fn ping(&self, _host: &Host) -> Result<(), RpcError> {
        if self.mode.word == "no-ping" {
            forever();
        }
        Ok(())
    }

    fn request(&self, host: &Host, method: &str, params: Value) -> Result<Value, RpcError> {
        match method {
            hooks::ACTIVATE | hooks::DEACTIVATE | hooks::UNINSTALL => {
                append("hooks", method);
                if method == hooks::ACTIVATE && self.mode.word == "crash-after-activate" {
                    std::thread::spawn(|| {
                        std::thread::sleep(Duration::from_millis(200));
                        std::process::exit(5);
                    });
                }
                Ok(json!({}))
            }
            hooks::MIGRATE => {
                append("hooks", &format!("migrate {}", params["fromVersion"]));
                Ok(json!({}))
            }
            "test.echo" => Ok(params),
            "test.register-tools" => {
                host.register_tools(vec![ToolDeclaration {
                    name: "late".to_string(),
                    description: "Registered while running".to_string(),
                    input_schema: serde_json::from_value(json!({ "type": "object" })).unwrap(),
                }]);
                Ok(json!({}))
            }
            "test.unregister-tools" => {
                host.unregister_tools(&["late", "runtime"]);
                Ok(json!({}))
            }
            "test.crash" => std::process::exit(6),
            "test.hang" => forever(),
            "test.slow" => {
                let millis = params["ms"].as_u64().unwrap_or(0);
                std::thread::sleep(Duration::from_millis(millis));
                Ok(json!({ "slept": millis }))
            }
            "test.malformed" => {
                write_raw(b"Content-Length: 5\r\n\r\nnope!");
                Ok(json!({}))
            }
            "test.oversized" => {
                write_raw(format!("Content-Length: {}\r\n\r\n{{", MAX_FRAME_BYTES + 1).as_bytes());
                Ok(json!({}))
            }
            "test.call" => {
                let method = params["method"].as_str().unwrap_or_default();
                host.call(method, params["params"].clone())
            }
            "test.received" => Ok(Value::Array(self.received.lock().clone())),
            "test.stderr" => {
                eprintln!("{}", params["line"].as_str().unwrap_or_default());
                Ok(json!({}))
            }
            method::PROVIDER_VALIDATE_SPEC => Ok(match params["values"]["name"].as_str() {
                Some("bad") => json!({ "issues": { "name": "the backend refuses `bad`" } }),
                _ => json!({ "issues": {} }),
            }),
            method::PROVIDER_INSTALL_PLAN => install_plan(&params),
            method::PROVIDER_CHECK_UPDATE => check_update(&params),
            method::PROVIDER_LAUNCH_PLAN => Ok(json!({
                "argv": [own_path(), "--serve", "{port}"],
                "env": { "SERVED_FOR": "{instance.id}" },
            })),
            method::UI_PANEL_QUERY => panel_query(&params),
            method::UI_PANEL_ACTION => match params["action"].as_str() {
                Some("say") => Ok(json!({ "notice": format!(
                    "said {} for {}",
                    params["values"]["word"].as_str().unwrap_or("nothing"),
                    params["context"]["instanceId"].as_str().unwrap_or("settings"),
                ) })),
                Some("remove") => Ok(json!({ "notice": format!(
                    "removed {} for {}",
                    params["row"].as_str().unwrap_or("no row"),
                    params["context"]["instanceId"].as_str().unwrap_or("settings"),
                ) })),
                _ => Err(RpcError::failed("the action failed")),
            },
            method::UI_FRAME_CALL => frame_call(host, &params),
            "service.echo" => Ok(json!({ "caller": params["caller"], "params": params["params"] })),
            "service.crash" => std::process::exit(8),
            "provider.manage.greet" => {
                let instance = params["instance"]["id"].as_str().unwrap_or_default();
                append("manage", &format!("greet {instance}"));
                let word = params["values"]["word"].as_str().unwrap_or("hello");
                Ok(json!({ "notice": format!("{word} {instance}") }))
            }
            "provider.manage.index" => {
                let millis = params["values"]["millis"].as_u64().unwrap_or(0);
                Ok(json!({ "steps": [
                    { "kind": "run", "command": [own_path(), "--sleep", millis.to_string()] },
                    { "kind": "write-file", "path": "{component.core}/index", "content": "indexed" },
                ] }))
            }
            "provider.manage.wait" => {
                let instance = params["instance"]["id"].as_str().unwrap_or_default();
                append("manage", &format!("wait {instance}"));
                std::thread::sleep(Duration::from_millis(slow_millis()));
                Ok(json!({ "notice": format!("waited for {instance}") }))
            }
            _ => Err(RpcError::method_not_found(method)),
        }
    }

    fn notification(&self, _host: &Host, method: &str, params: Value) {
        self.received
            .lock()
            .push(json!({ "method": method, "params": params }));
    }
}

impl Ui for Backend {
    fn state(&self, _host: &Host, context: &PanelContext) -> Result<Value, RpcError> {
        let (count, last) = self.emitted.lock().clone();
        Ok(json!({ "context": context, "emitted": count, "last": last }))
    }

    /// An action of its UI, by its `action`.
    fn call(
        &self,
        host: &Host,
        action: &str,
        args: Value,
        context: &PanelContext,
    ) -> Result<Value, RpcError> {
        match action {
            "echo" => Ok(json!({ "args": args, "context": context })),
            "forbid" => Err(RpcError::permission_denied("the UI may not do that")),
            "invalid" => Err(RpcError::invalid_params("the UI sent nothing usable")),
            "emit" => {
                {
                    let mut emitted = self.emitted.lock();
                    emitted.0 += 1;
                    emitted.1 = args.clone();
                }
                host.emit_state(args)
                    .map_err(|error| RpcError::failed(error.to_string()))?;
                Ok(json!({}))
            }
            _ => Err(RpcError::failed("the UI's action failed")),
        }
    }
}

/// How long `slow` work takes: `test-backend.slow`, in milliseconds.
fn slow_millis() -> u64 {
    std::fs::read_to_string("test-backend.slow")
        .ok()
        .and_then(|text| text.trim().parse().ok())
        .unwrap_or(0)
}

/// A panel's blocks: `summary` and `models` rows, `log` lines, `broken`
/// an error and `slow` an answer after `test-backend.slow` milliseconds.
fn panel_query(params: &Value) -> Result<Value, RpcError> {
    let instance = params["context"]["instanceId"].as_str().unwrap_or("none");
    match params["block"].as_str() {
        Some("summary") => Ok(json!({ "rows": [
            { "label": "Instance", "value": instance },
            { "label": "Count", "value": 3 },
        ] })),
        Some("models") => Ok(json!({ "rows": [{ "name": "a.gguf", "size": 7 }] })),
        Some("log") => Ok(json!({ "lines": ["one", "two"] })),
        Some("slow") => {
            std::thread::sleep(Duration::from_millis(slow_millis()));
            Ok(json!({ "lines": ["late"] }))
        }
        _ => Err(RpcError::failed("the panel broke")),
    }
}

/// A frame's call, by its `method`.
fn frame_call(host: &Host, params: &Value) -> Result<Value, RpcError> {
    match params["method"].as_str() {
        Some("echo") => Ok(json!({
            "frame": params["frame"],
            "params": params["params"],
            "context": params["context"],
        })),
        Some("hang") => forever(),
        Some("emit") => {
            let event = json!({
                "frame": params["frame"],
                "event": params["params"]["event"],
                "payload": params["params"]["payload"],
            });
            host.notify(method::UI_FRAME_EMIT, event)
                .map_err(|error| RpcError::failed(error.to_string()))?;
            Ok(json!({}))
        }
        _ => Err(RpcError::failed("the frame's call failed")),
    }
}

fn own_path() -> String {
    std::env::current_exe()
        .map(|path| path.to_string_lossy().into_owned())
        .unwrap_or_default()
}

/// An update check, recorded in `checks`: an instance whose `name` is
/// `pinned` has none, one named `offline` fails.
fn check_update(params: &Value) -> Result<Value, RpcError> {
    let instance = params["instance"]["id"].as_str().unwrap_or_default();
    let name = params["values"]["name"].as_str().unwrap_or_default();
    append("checks", &format!("{instance} {name}"));
    if name == "offline" {
        return Err(RpcError::failed("the releases are offline"));
    }
    Ok(json!({
        "current": "1.0",
        "latest": "2.0",
        "hasUpdate": name != "pinned",
        "notes": format!("for {instance}"),
    }))
}

fn install_plan(params: &Value) -> Result<Value, RpcError> {
    let kind = params["kind"].as_str().unwrap_or_default();
    match params["values"]["plan"].as_str() {
        Some("crash") => std::process::exit(7),
        Some("slow") => Ok(json!({ "steps": [
            { "kind": "write-file", "path": "{component.core}/notes.txt", "content": "{param.name}" },
            { "kind": "run", "command": [own_path(), "--sleep", slow_millis().to_string()] },
            { "kind": "run", "command": [own_path(), "--write", "ran.txt", kind] },
        ] })),
        Some("escape") => Ok(json!({ "steps": [
            { "kind": "write-file", "path": "{component.core}/../outside.txt", "content": "out" },
        ] })),
        _ => Ok(json!({ "steps": [
            { "kind": "write-file", "path": "{component.core}/notes.txt", "content": "{param.name}" },
            { "kind": "run", "command": [own_path(), "--write", "ran.txt", kind] },
        ] })),
    }
}

/// What it does when started as a step's or a role's program.
fn run_as_program(args: &[String]) -> Option<i32> {
    match args {
        [flag, file, text] if flag == "--write" => Some(if std::fs::write(file, text).is_ok() {
            0
        } else {
            1
        }),
        [flag, millis] if flag == "--sleep" => {
            std::thread::sleep(Duration::from_millis(millis.parse().ok()?));
            Some(0)
        }
        [flag, port] if flag == "--serve" => {
            let listener = std::net::TcpListener::bind(("127.0.0.1", port.parse().ok()?)).ok()?;
            for mut stream in listener.incoming().flatten() {
                let mut request = [0u8; 4096];
                let _ = std::io::Read::read(&mut stream, &mut request);
                let _ = stream.write_all(
                    b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok",
                );
            }
            Some(0)
        }
        _ => None,
    }
}

/// Bytes on stdout that are not what the SDK would write.
fn write_raw(bytes: &[u8]) {
    let mut stdout = std::io::stdout().lock();
    let _ = stdout.write_all(bytes);
    let _ = stdout.flush();
}

impl InstanceDiagnostics for Backend {
    fn collect_instance(
        &self,
        _host: &Host,
        id: &str,
    ) -> Result<DiagnosticsCollectResult, RpcError> {
        Ok(DiagnosticsCollectResult {
            documents: vec![DiagnosticDocument {
                name: "instance.txt".into(),
                text: id.into(),
            }],
        })
    }
}

impl Diagnostics for Backend {
    fn collect(&self, _host: &Host) -> Result<DiagnosticsCollectResult, RpcError> {
        if self.mode.word == "diagnostics-timeout" {
            forever();
        }
        if self.mode.word == "diagnostics-count" {
            return Ok(DiagnosticsCollectResult {
                documents: (0..=hanafubuki_extension_sdk::protocol::DIAGNOSTIC_MAX_DOCUMENTS)
                    .map(|index| DiagnosticDocument {
                        name: format!("{index}.txt"),
                        text: String::new(),
                    })
                    .collect(),
            });
        }
        if self.mode.word == "diagnostics-bytes" {
            return Ok(DiagnosticsCollectResult {
                documents: vec![DiagnosticDocument {
                    name: "large.txt".into(),
                    text: "x".repeat(hanafubuki_extension_sdk::protocol::DIAGNOSTIC_MAX_BYTES),
                }],
            });
        }
        let name = if self.mode.word == "diagnostics-invalid" {
            "../bad"
        } else {
            "status.txt"
        };
        Ok(DiagnosticsCollectResult {
            documents: vec![
                DiagnosticDocument {
                    name: name.to_string(),
                    text: "extension ready".to_string(),
                },
                DiagnosticDocument {
                    name: if self.mode.word == "diagnostics-duplicate" {
                        name
                    } else {
                        "state.json"
                    }
                    .to_string(),
                    text: "{\"ready\":true}".to_string(),
                },
            ],
        })
    }
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    if let Some(code) = run_as_program(&args) {
        std::process::exit(code);
    }
    let mode = mode();
    append("starts", &std::process::id().to_string());
    eprintln!("test backend started in mode {}", mode.word);
    if mode.word == "crash-at-start" {
        std::process::exit(3);
    }
    let ignore_shutdown = mode.word == "ignore-shutdown";
    let backend = Backend {
        mode,
        received: Mutex::new(Vec::new()),
        emitted: Mutex::new((0, Value::Null)),
    };
    if let Err(error) = run(backend) {
        eprintln!("test backend: {error}");
        std::process::exit(2);
    }
    if ignore_shutdown {
        forever();
    }
}
