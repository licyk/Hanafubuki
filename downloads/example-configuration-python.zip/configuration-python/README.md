# Python backend configuration / Python 后端配置

This is a complete minimal backend package, installable as a development link.
`backend.py` runs the application's Python SDK `Handler` with its real framed
initialize, ping and shutdown behavior. It contributes no custom methods or
hooks and starts no server. No third-party requirements are needed; Hanafubuki
supplies its SDK on `PYTHONPATH` and prepares its managed Python when enabling
the extension.

The configuration export validates the manifest and real package files without
starting the backend or preparing Python. A separate local protocol smoke can
start the script with the repository's `sdk/python` on `PYTHONPATH`; this is not
proof that the managed Python environment or Tauri desktop was exercised.
Do not launch the script in a terminal expecting a prompt: its stdin/stdout carry
Content-Length-framed JSON-RPC, as described in the extension protocol.

这是可以作为开发链接安装的完整最小后端包。脚本直接运行应用 SDK 的 `Handler`，
支持真实 initialize、ping 与 shutdown 帧，不启动服务器、不定义自有方法。
宿主负责准备托管 Python 并通过 `PYTHONPATH` 提供 SDK，不需要额外依赖。
配置导出仅检查清单与实际文件，不启动后端；本地协议 smoke 与托管 Python／
Tauri 桌面验证是不同范围。标准输入输出承载协议帧，不是交互终端。

`schemas/settings.json` declares the extension's own `note` text setting. The
host shows and persists it through the normal extension settings form; the
minimal protocol handler does not add business behavior or read global settings.

`schemas/settings.json` 声明扩展自身的 `note` 文本设置，由宿主常规设置表单显示
和持久化。最小协议 handler 不添加业务行为，也不读取全局设置。
