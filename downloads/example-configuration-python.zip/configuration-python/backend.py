"""A minimal backend with the SDK's initialize, ping and shutdown behavior."""

from hanafubuki_extension import Handler, run

if __name__ == "__main__":
    run(Handler())
