# Configuration guide / 配置指南

A complete data-only extension, installable as a development link. It needs no
compiled backend, placeholder executable or external package file.

- `types/notes.toml` creates a local note using a real install parameter.
- `presets/welcome.toml` targets that type and fills its declared form.
- `types/archive.toml` demonstrates download, unpack, write-file and probe in
  a complete descriptor. Supply a real ZIP URL, its publisher's SHA-256 and an
  existing health endpoint before installing that instance. It starts no service.

The interface exporter reads these exact files. Its checks parse and validate
the manifest, package contents, descriptors and preset catalog; they do not
execute installation steps, download an archive, probe a network endpoint or
claim that an external service runs. The existing `adopted-webui` example supplies
complete descriptors for the remaining Git, Python-environment and run steps.

这是可作为开发链接安装的完整纯数据扩展，没有编译后端或占位可执行文件。
笔记类型及其预设可用于本地内容；归档类型要求用户提供真实 ZIP 地址、发布方摘要
和已存在的健康端点，不会自行启动服务。导出验证覆盖解析、包内容、类型和预设
catalog，不执行安装流程或网络请求。网站直接展示这些同源完整文件。
