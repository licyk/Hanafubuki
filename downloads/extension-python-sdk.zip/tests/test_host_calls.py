"""Typed host wrappers through the real framed Host connection."""

import io
import socket
import threading
import unittest
from typing import BinaryIO, cast

from hanafubuki_extension import Host, RpcError
from hanafubuki_extension.protocol import (
    REQUEST_FAILED,
    WebviewNavigateParams,
    WebviewPageParams,
    read_frame,
    write_frame,
)


class HostCalls(unittest.TestCase):
    """Exercise serialization, responses, errors and host-owned defaults."""

    def test_network_calls_keep_wire_fields_and_results(self):
        """Use real frames so repeated headers and optional fields reach the host."""
        calls = [
            (
                "http_request",
                "http.request",
                {
                    "url": "https://example.org/info",
                    "method": "POST",
                    "headers": [
                        {"name": "X-Test", "value": "a"},
                        {"name": "X-Test", "value": "b"},
                    ],
                    "body": "你好",
                    "maxBytes": 128,
                    "timeoutMs": 100,
                },
                {"status": 404, "headers": [], "body": "missing"},
            ),
            (
                "http_request",
                "http.request",
                {"url": "https://example.org"},
                {"status": 200, "headers": [], "body": "ok"},
            ),
            (
                "download_fetch",
                "download.fetch",
                {
                    "url": "https://github.com/a/b/releases/download/v1/a",
                    "destination": "a",
                    "source": "github",
                    "cache": True,
                    "sha256": "a" * 64,
                },
                {"path": "/data/a", "sha256": "a" * 64},
            ),
            (
                "process_run",
                "process.run",
                {
                    "argv": ["tool"],
                    "useHostProxy": True,
                    "env": {"HTTPS_PROXY": "caller-value"},
                },
                {"taskId": "task"},
            ),
        ]
        for wrapper, method, params, result in calls:
            with self.subTest(method=method, params=params):
                self.exchange(wrapper, method, params, {"result": result}, result)

    def test_state_and_frame_notifications_carry_the_optional_instance(self):
        """Both notifications broadcast when the instance is omitted."""
        stream = io.BytesIO()
        host = Host(stream)
        host.emit_state(1)
        host.emit_frame("view", "tick", 1)
        host.emit_state(2, instance_id="b")
        host.emit_frame("view", "tick", 2, instance_id="b")
        stream.seek(0)
        self.assertEqual(
            [read_frame(stream)["params"] for _ in range(4)],
            [
                {"state": 1},
                {"frame": "view", "event": "tick", "payload": 1},
                {"instanceId": "b", "state": 2},
                {"instanceId": "b", "frame": "view", "event": "tick", "payload": 2},
            ],
        )

    def test_prompt_returns_before_the_user_answers(self):
        """Acceptance has an empty result; the answer is a later notification."""
        self.exchange(
            "ui_prompt",
            "ui.prompt",
            {"id": "question", "kind": "text", "message": "Model name?"},
            {"result": {}},
            None,
        )

    def test_progress_accepts_an_instance(self):
        """The same local progress id can be used in each instance."""
        self.exchange(
            "ui_progress",
            "ui.progress",
            {"instanceId": "one", "id": "download", "title": "Downloading", "total": 4},
            {"result": {}},
            None,
        )

    def test_settings_patch_preserves_null_and_returns_canonical_values(self):
        """The SDK sends the patch unchanged and uses the host's canonical result."""
        self.exchange(
            "settings_patch",
            "settings.patch",
            {"patch": {"name": None}},
            {"result": {"values": {"name": "default"}}},
            {"values": {"name": "default"}},
        )
        self.exchange(
            "settings_get",
            "settings.get",
            None,
            {"result": {"values": {"name": "default"}}},
            {"values": {"name": "default"}},
        )

    def test_rpc_errors_propagate(self):
        """A failed transport remains RpcError with the host's code and message."""
        with self.assertRaises(RpcError) as caught:
            self.exchange(
                "http_request",
                "http.request",
                {"url": "https://example.org"},
                {"error": {"code": REQUEST_FAILED, "message": "non UTF-8"}},
                None,
            )
        self.assertEqual(caught.exception.code, REQUEST_FAILED)
        self.assertEqual(str(caught.exception), "non UTF-8")

    def test_preferences_returns_snapshot_with_optional_mirror_and_path(self):
        """The SDK preserves a complete snapshot without fabricating unset values."""
        snapshot = {
            "locale": "zh",
            "instancesDir": None,
            "mirrors": None,
            "network": {"proxyMode": "system", "proxyConfigured": False},
        }
        self.exchange(
            "host_preferences", "host.preferences", None, {"result": snapshot}, snapshot
        )

    def test_runtime_wrappers_preserve_status_and_native_paths(self):
        """Resolve returns the host path and arbitrary verified version output."""
        status = {
            "tools": [
                {
                    "tool": "python",
                    "status": "preparing",
                }
            ]
        }
        self.exchange(
            "runtime_status", "runtime.status", None, {"result": status}, status
        )
        ready = {
            "tool": "python",
            "path": "/managed/python",
            "version": "Python 3.11.9",
        }
        self.exchange(
            "runtime_resolve",
            "runtime.resolve",
            {"tool": "python"},
            {"result": ready},
            ready,
        )

    def test_webview_wrappers_keep_wire_fields(self):
        """The webview wrappers send their camelCase params and read `{}`."""
        pages = {
            "pages": [
                {
                    "instanceId": "mine",
                    "operationId": "op-1",
                    "pageId": "page-1",
                    "role": "ui",
                    "state": "presented",
                    "url": "http://127.0.0.1:7860/",
                }
            ]
        }
        self.exchange("webview_pages", "webview.pages", None, {"result": pages}, pages)
        self.exchange(
            "webview_pages",
            "webview.pages",
            {"instanceId": "mine"},
            {"result": pages},
            pages,
        )
        page: WebviewPageParams = {"instanceId": "mine", "operationId": "op-1"}
        for wrapper, method in [
            ("webview_show", "webview.show"),
            ("webview_close", "webview.close"),
            ("webview_reload", "webview.reload"),
        ]:
            with self.subTest(method=method):
                self.void(wrapper, method, page)
        navigate: WebviewNavigateParams = {
            "instanceId": "mine",
            "operationId": "op-1",
            "pageId": "page-1",
            "url": "http://127.0.0.1:7860/txt2img",
        }
        self.void("webview_navigate", "webview.navigate", navigate)

    def void(self, wrapper, method, params):
        """Exchange one request whose wrapper returns nothing, as `exchange` does."""
        left, right = socket.socketpair()
        with (
            left,
            right,
            left.makefile("rwb", buffering=0) as client,
            right.makefile("rwb", buffering=0) as server,
        ):
            client_stream = cast(BinaryIO, client)
            server_stream = cast(BinaryIO, server)
            host = Host(client_stream)
            requests = []

            def respond():
                request = read_frame(server_stream)
                assert request is not None
                requests.append(request)
                write_frame(server_stream, {"jsonrpc": "2.0", "id": request["id"], "result": {}})
                response = read_frame(client_stream)
                assert response is not None
                host._resolve(response)

            thread = threading.Thread(target=respond)
            thread.start()
            try:
                self.assertIsNone(getattr(host, wrapper)(params))
            finally:
                thread.join(timeout=2)
                self.assertFalse(thread.is_alive())
                self.assertEqual(requests[0]["method"], method)
                self.assertEqual(requests[0]["params"], params)

    def exchange(self, wrapper, method, params, answer, expected):
        """Exchange one request over a socket using production framing and Host."""
        left, right = socket.socketpair()
        with (
            left,
            right,
            left.makefile("rwb", buffering=0) as client,
            right.makefile("rwb", buffering=0) as server,
        ):
            client_stream = cast(BinaryIO, client)
            server_stream = cast(BinaryIO, server)
            host = Host(client_stream)
            requests = []

            def respond():
                request = read_frame(server_stream)
                assert request is not None
                requests.append(request)
                write_frame(
                    server_stream, {"jsonrpc": "2.0", "id": request["id"], **answer}
                )
                response = read_frame(client_stream)
                assert response is not None
                host._resolve(response)

            thread = threading.Thread(target=respond)
            thread.start()
            try:
                result = (
                    getattr(host, wrapper)()
                    if params is None
                    else getattr(host, wrapper)(params)
                )
                self.assertEqual(result, expected)
            finally:
                thread.join(timeout=2)
                self.assertFalse(thread.is_alive())
                self.assertEqual(requests[0]["method"], method)
                self.assertEqual(requests[0]["params"], params or {})


if __name__ == "__main__":
    unittest.main()
