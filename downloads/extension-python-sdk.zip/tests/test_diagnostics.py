"""Diagnostic hook registration and dispatch over the SDK's actual framed loop."""

import socket
import threading
import unittest
from typing import BinaryIO, cast

from hanafubuki_extension import Handler, Host, run
from hanafubuki_extension.protocol import (
    DiagnosticsCollectResult,
    read_frame,
    write_frame,
)


class DiagnosticBackend(Handler):
    """A backend contributing one JSON text document."""

    def diagnostics_collect_instance(
        self, host: Host, instance_id: str
    ) -> DiagnosticsCollectResult:
        """Return the requested instance ID over the wire."""
        return {"documents": [{"name": "instance.txt", "text": instance_id}]}

    def diagnostics_collect(self, host: Host) -> DiagnosticsCollectResult:
        """Return a document for the host to write."""
        return {"documents": [{"name": "state.json", "text": '{"ready":true}'}]}


class DiagnosticsTests(unittest.TestCase):
    """Use actual initialize/diagnostics/shutdown requests, without dispatch mocks."""

    def test_hook_announces_only_for_an_override_and_returns_documents(self):
        """The handler override registers the hook and serves its typed result."""
        self.assertNotIn("diagnostics", Handler().hooks())
        left, right = socket.socketpair()
        with (
            left,
            right,
            left.makefile("rwb", buffering=0) as client,
            right.makefile("rwb", buffering=0) as server,
        ):
            client_stream, server_stream = (
                cast(BinaryIO, client),
                cast(BinaryIO, server),
            )
            thread = threading.Thread(
                target=run, args=(DiagnosticBackend(), server_stream, server_stream)
            )
            thread.start()
            try:
                write_frame(
                    client_stream,
                    {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}},
                )
                initialized = read_frame(client_stream)
                assert initialized is not None
                self.assertCountEqual(
                    initialized["result"]["hooks"],
                    ["diagnostics", "diagnostics.collectInstance"],
                )
                write_frame(
                    client_stream,
                    {
                        "jsonrpc": "2.0",
                        "id": 2,
                        "method": "diagnostics.collect",
                        "params": {"future": True},
                    },
                )
                collected = read_frame(client_stream)
                assert collected is not None
                self.assertEqual(
                    collected["result"],
                    {"documents": [{"name": "state.json", "text": '{"ready":true}'}]},
                )
                write_frame(
                    client_stream,
                    {
                        "jsonrpc": "2.0",
                        "id": 4,
                        "method": "diagnostics.collectInstance",
                        "params": {"id": "one"},
                    },
                )
                scoped = read_frame(client_stream)
                assert scoped is not None
                self.assertEqual(
                    scoped["result"]["documents"],
                    [{"name": "instance.txt", "text": "one"}],
                )
            finally:
                write_frame(
                    client_stream,
                    {"jsonrpc": "2.0", "id": 3, "method": "shutdown", "params": {}},
                )
                read_frame(client_stream)
                thread.join(timeout=2)
                self.assertFalse(thread.is_alive())
