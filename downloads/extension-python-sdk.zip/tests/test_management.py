"""Extension management callback responses through the provider dispatcher."""

import io
import unittest
from typing import Any

from hanafubuki_extension import Handler, Host
from hanafubuki_extension.backend import _dispatch


class Maintenance(Handler):
    """A backend providing immediate and host-run maintenance operations."""

    def launch_preflight(
        self,
        host: Host,
        type_id: str,
        values: dict[str, Any],
        launch_values: dict[str, Any],
        instance: dict[str, Any],
    ) -> None:
        """Reject a launch with a different engine from its installation."""
        if values["engine"] != launch_values["engine"]:
            raise ValueError(f"Engine changed for {instance['id']}")

    def launch_options(
        self, host: Host, type_id: str, instance: dict[str, Any]
    ) -> dict[str, list[str]]:
        """Offer the instance's model file for its launch selector."""
        return {"models": [instance["id"] + ".gguf"]}

    def manage(
        self, host: Host, type_id: str, operation: str, instance: dict[str, Any]
    ) -> str | dict[str, Any] | None:
        """Return the selected operation's immediate notice or plan."""
        if operation == "reload":
            return "Reloaded"
        return {"steps": [{"kind": "run", "command": ["tool", instance["id"]]}]}


class ManagementTests(unittest.TestCase):
    """Exercise both supported callback return forms."""

    def test_dispatches_launch_preflight(self):
        """Pass both configurations and the instance through to the preflight check."""
        params = {
            "type": "example",
            "instance": {"id": "one"},
            "values": {"engine": "a"},
            "launchValues": {"engine": "a"},
        }
        self.assertEqual(
            _dispatch(Maintenance(), Host(io.BytesIO()), "provider.launchPreflight", params),
            {},
        )
        params["launchValues"] = {"engine": "b"}
        with self.assertRaisesRegex(ValueError, "Engine changed for one"):
            _dispatch(Maintenance(), Host(io.BytesIO()), "provider.launchPreflight", params)

    def test_dispatches_instance_launch_options(self):
        """Wrap the options by source and pass the requested instance to the callback."""
        self.assertEqual(
            _dispatch(
                Maintenance(),
                Host(io.BytesIO()),
                "provider.launchOptions",
                {"type": "example", "instance": {"id": "one"}},
            ),
            {"options": {"models": ["one.gguf"]}},
        )

    def test_dispatches_notice_and_plan(self):
        """Preserve the plan as a structured result on the wire."""
        host = Host(io.BytesIO())
        params = {"type": "example", "instance": {"id": "one"}}
        self.assertEqual(
            _dispatch(Maintenance(), host, "provider.manage.reload", params),
            {"notice": "Reloaded"},
        )
        self.assertEqual(
            _dispatch(Maintenance(), host, "provider.manage.rebuild", params),
            {"steps": [{"kind": "run", "command": ["tool", "one"]}]},
        )
