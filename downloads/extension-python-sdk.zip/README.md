# Hanafubuki extension SDK for Python

`hanafubuki_extension`, standard library only, Python 3.10 or later.

An extension backend does not carry this package and does not list it in
`requirements`: the application ships it and puts it on the backend's
`PYTHONPATH`. This copy is for reading the SDK, and for running a backend
outside the application with it on `PYTHONPATH`, as `tests/` does.
