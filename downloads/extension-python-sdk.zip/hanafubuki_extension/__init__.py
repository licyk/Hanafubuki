"""Hanafubuki's extension SDK for Python backends (``docs/extension-protocol.md``).

A backend subclasses ``Handler``, overriding what it implements, and calls
``run(handler)``; ``Host`` calls the application back. Pure standard
library, Python 3.10 or later.
"""

from .backend import HOOKS, Handler, Host, run
from .protocol import (
    BUSY,
    INTERNAL_ERROR,
    INVALID_PARAMS,
    INVALID_REQUEST,
    METHOD_NOT_FOUND,
    PARSE_ERROR,
    PERMISSION_DENIED,
    PROTOCOL_VERSION,
    REQUEST_FAILED,
    TIMED_OUT,
    UNAVAILABLE,
    FrameError,
    RpcError,
)

__all__ = [
    "BUSY",
    "HOOKS",
    "INTERNAL_ERROR",
    "INVALID_PARAMS",
    "INVALID_REQUEST",
    "METHOD_NOT_FOUND",
    "PARSE_ERROR",
    "PERMISSION_DENIED",
    "PROTOCOL_VERSION",
    "REQUEST_FAILED",
    "TIMED_OUT",
    "UNAVAILABLE",
    "FrameError",
    "Handler",
    "Host",
    "RpcError",
    "run",
]
