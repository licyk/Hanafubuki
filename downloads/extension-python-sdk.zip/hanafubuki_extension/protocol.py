"""The protocol between Hanafubuki and an extension's backend, version 1.

JSON-RPC 2.0 messages framed as Language Server Protocol frames
(``Content-Length`` headers) over the backend's stdin and stdout
(``docs/extension-protocol.md``).
"""

from __future__ import annotations

import json
from typing import Any, BinaryIO, Literal, TypedDict

PROTOCOL_VERSION = 1
MAX_HEADER_BYTES = 1024
MAX_FRAME_BYTES = 4 * 1024 * 1024

# The host API: the methods a backend calls on the application, one
# constant each, as the protocol's registry lists them (the interface
# export's ``host-api.openrpc.json``; a test keeps the two equal).
HOST_INFO = "host.info"
HOST_PREFERENCES = "host.preferences"
RUNTIME_STATUS = "runtime.status"
RUNTIME_RESOLVE = "runtime.resolve"
LOG_WRITE = "log.write"
SETTINGS_GET = "settings.get"
SETTINGS_PATCH = "settings.patch"
STORAGE_PATH = "storage.path"
INSTANCES_LIST = "instances.list"
INSTANCES_CONFIGURATION = "instances.configuration"
INSTANCES_GET = "instances.get"
INSTANCES_OF_TYPE = "instances.ofType"
INSTANCES_SCAN = "instances.scan"
INSTANCES_IMPORT = "instances.import"
SERVERS_STATUS = "servers.status"
WEBVIEW_PAGES = "webview.pages"
WEBVIEW_SHOW = "webview.show"
WEBVIEW_CLOSE = "webview.close"
WEBVIEW_RELOAD = "webview.reload"
WEBVIEW_NAVIGATE = "webview.navigate"
PROCESS_RUN = "process.run"
PROCESS_CANCEL = "process.cancel"
DOWNLOAD_FETCH = "download.fetch"
HTTP_REQUEST = "http.request"
EVENTS_SUBSCRIBE = "events.subscribe"
UI_PROMPT = "ui.prompt"
UI_NOTIFY = "ui.notify"
UI_PROGRESS = "ui.progress"
UI_TASK_CENTER_OPEN = "ui.taskCenter.open"
PYTHON_ENSURE = "python.ensure"
GIT_CLONE = "git.clone"
GIT_PULL = "git.pull"
SERVICES_CALL = "services.call"
TOOLS_LIST = "tools.list"
TOOLS_CALL = "tools.call"
UI_FRAME_EMIT = "ui.frame.emit"
UI_EMIT = "ui.emit"
TOOLS_REGISTER = "tools.register"
TOOLS_UNREGISTER = "tools.unregister"

PARSE_ERROR = -32700
INVALID_REQUEST = -32600
METHOD_NOT_FOUND = -32601
INVALID_PARAMS = -32602
INTERNAL_ERROR = -32603
PERMISSION_DENIED = -32001
TIMED_OUT = -32002
REQUEST_FAILED = -32003
UNAVAILABLE = -32004
BUSY = -32005

HttpMethod = Literal["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"]
DownloadSource = Literal["direct", "github", "huggingface"]
RuntimeTool = Literal["python", "git", "micromamba"]
RuntimeStatus = Literal["notReady", "preparing", "ready", "failed", "unavailable"]


class RuntimeStatusParams(TypedDict, total=False):
    """Omit tool to read all three tools without starting preparation."""

    tool: RuntimeTool | None


class _RuntimeToolStatusRequired(TypedDict):
    tool: RuntimeTool
    status: RuntimeStatus


class RuntimeToolStatus(_RuntimeToolStatusRequired, total=False):
    """Current readiness, native path and optional verified version/output."""

    path: str | None
    version: str | None
    error: str | None


class RuntimeStatusResult(TypedDict):
    """Readiness of the requested host tools."""

    tools: list[RuntimeToolStatus]


class RuntimeResolveParams(TypedDict):
    """The managed tool to wait for."""

    tool: RuntimeTool


class _RuntimeResolveRequired(TypedDict):
    tool: RuntimeTool
    path: str


class RuntimeResolveResult(_RuntimeResolveRequired, total=False):
    """The ready executable and optional verified version/output."""

    version: str | None


class DiagnosticDocument(TypedDict):
    """A filename and text for diagnostics; never include credentials."""

    name: str
    text: str


class DiagnosticsCollectResult(TypedDict):
    """Bounded diagnostic documents; the host owns destination paths."""

    documents: list[DiagnosticDocument]


class UiPromptParams(TypedDict):
    """A question identified by the backend until ui.prompt.result arrives."""

    id: str
    kind: Literal["confirm", "text"]
    message: str


class _UiProgressRequired(TypedDict):
    id: str
    title: str


class UiProgressParams(_UiProgressRequired, total=False):
    """One progress entry, updated by id in application or instance scope."""

    instanceId: str
    showOnHome: bool
    showOnManage: bool
    completed: int
    total: int
    done: bool
    error: str


class UiTaskCenterOpenParams(TypedDict):
    """One of the extension's Task Center tabs, asked to be shown."""

    tab: str

class HostMirror(TypedDict):
    """One host mirror setting; null selects the default mirror."""

    enabled: bool
    custom: str | None


class HostMirrors(TypedDict):
    """Current host mirror choices; automatic selection is resolved by the host."""

    automatic: bool
    pypi: HostMirror
    github: HostMirror
    huggingface: HostMirror


class HostNetworkPreferences(TypedDict):
    """Non-sensitive proxy state, without addresses or credentials."""

    proxyMode: Literal["system", "manual", "disabled"]
    proxyConfigured: bool


class HostPreferences(TypedDict):
    """The host.preferences result and preferences event payload."""

    locale: str
    instancesDir: str | None
    mirrors: HostMirrors | None
    network: HostNetworkPreferences


class PreferencesEvent(TypedDict):
    """Params of an event notification for the preferences subscription."""

    topic: Literal["preferences"]
    data: HostPreferences


class SettingsPatchParams(TypedDict):
    """Patch declared settings; null removes the extension's saved override."""

    patch: dict[str, Any]


class InstanceConfigurationResult(TypedDict):
    """Declared public configuration of one instance of the extension’s own types."""

    values: dict[str, Any]
    launchValues: dict[str, Any]
    valuesTruncated: bool
    launchValuesTruncated: bool


class SettingsResult(TypedDict):
    """Canonical values of this extension's declared settings."""

    values: dict[str, Any]


class HttpHeader(TypedDict):
    """One header; a list preserves repeated names."""

    name: str
    value: str


class _HttpRequestRequired(TypedDict):
    url: str


class HttpRequestParams(_HttpRequestRequired, total=False):
    """HTTP input; omitted bounds and method use the host's defaults."""

    method: HttpMethod
    headers: list[HttpHeader]
    body: str | None
    maxBytes: int
    timeoutMs: int


class HttpRequestResult(TypedDict):
    """Actual HTTP status, repeated headers and UTF-8 text, including non-2xx."""

    status: int
    headers: list[HttpHeader]
    body: str


class _DownloadFetchRequired(TypedDict):
    url: str
    destination: str


class DownloadFetchParams(_DownloadFetchRequired, total=False):
    """Download into extension data; defaults to direct and no cache."""

    sha256: str | None
    source: DownloadSource
    cache: bool


class DownloadFetchResult(TypedDict):
    """The extension's destination path and the downloaded content digest."""

    path: str
    sha256: str


class _ProcessRunRequired(TypedDict):
    argv: list[str]


class ProcessRunParams(_ProcessRunRequired, total=False):
    """Run without a shell; host proxy injection is opt-in for this process."""

    cwd: str | None
    env: dict[str, str]
    useHostProxy: bool
    instanceId: str


class ProcessRunResult(TypedDict):
    """The process's task, tracked by the host."""

    taskId: str


class WebviewPageView(TypedDict):
    """One embedded WebUI page the application holds open for an instance."""

    instanceId: str
    operationId: str
    pageId: str
    role: str
    state: str
    url: str


class WebviewPagesParams(TypedDict, total=False):
    """Lists one instance's open pages; every one of them when absent."""

    instanceId: str | None


class WebviewPagesResult(TypedDict):
    pages: list[WebviewPageView]


class _WebviewPageRequired(TypedDict):
    instanceId: str
    operationId: str


class WebviewPageParams(_WebviewPageRequired, total=False):
    """Names one page of one launch; with no page, the one shown last."""

    pageId: str | None


class WebviewNavigateParams(_WebviewPageRequired):
    """Navigates one open page to an address on its authorized origin."""

    pageId: str
    url: str


class RpcError(Exception):
    """A JSON-RPC error, raised by a failed call and answered for a failed request."""

    def __init__(self, code: int, message: str, data: Any = None) -> None:
        """Builds the error.

        Args:
            code: One of this module's codes.
            message: What went wrong.
            data: Anything more, as JSON.
        """
        super().__init__(message)
        self.code = code
        self.message = message
        self.data = data

    def to_json(self) -> dict[str, Any]:
        """The error as a response's ``error`` member.

        Returns:
            The error object.
        """
        error: dict[str, Any] = {"code": self.code, "message": self.message}
        if self.data is not None:
            error["data"] = self.data
        return error


class FrameError(Exception):
    """A frame that does not read: the channel ends."""


def write_frame(stream: BinaryIO, message: dict[str, Any]) -> None:
    """Writes one message as a frame and flushes it.

    Args:
        stream: The binary stream (stdout).
        message: The JSON-RPC message.
    """
    body = json.dumps(message, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    stream.write(b"Content-Length: %d\r\n\r\n" % len(body))
    stream.write(body)
    stream.flush()


def read_frame(stream: BinaryIO) -> dict[str, Any] | None:
    """Reads one frame's message.

    Args:
        stream: The binary stream (stdin).

    Returns:
        The message, or ``None`` at the end of the stream.

    Raises:
        FrameError: The frame or its body does not read.
    """
    length = None
    header_bytes = 0
    while True:
        line = stream.readline(MAX_HEADER_BYTES + 1)
        if not line:
            if header_bytes == 0:
                return None
            raise FrameError("the stream ended inside a frame's headers")
        header_bytes += len(line)
        if header_bytes > MAX_HEADER_BYTES:
            raise FrameError("a frame's headers are longer than 1 KiB")
        if line in (b"\r\n", b"\n"):
            break
        name, _, value = line.decode("ascii", "replace").partition(":")
        if name.strip().lower() == "content-length":
            try:
                length = int(value.strip())
            except ValueError as error:
                raise FrameError(f"Content-Length is not a number: {value.strip()}") from error
    if length is None:
        raise FrameError("a frame without Content-Length")
    if length < 0 or length > MAX_FRAME_BYTES:
        raise FrameError(f"a frame of {length} bytes is over the bound")
    body = b""
    while len(body) < length:
        chunk = stream.read(length - len(body))
        if not chunk:
            raise FrameError("the stream ended inside a frame's body")
        body += chunk
    try:
        message = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise FrameError(f"a body that is not JSON: {error}") from error
    if not isinstance(message, dict):
        raise FrameError("a body that is not a JSON-RPC message")
    return message
