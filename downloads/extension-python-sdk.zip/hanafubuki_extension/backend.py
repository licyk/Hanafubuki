"""Writing an extension's backend in Python: the loop, the host and the handler.

``run(handler)`` reads the application's messages until it asks the backend
to shut down or closes stdin. It answers ``initialize`` and ``ping`` itself
and hands every other request to the handler, each on a thread of its own,
so a long request never holds up the others or a ping. The handler reaches
the application through ``Host``, whose calls wait for their answers.

Stdout is the protocol's: ``run`` moves ``sys.stdout`` to stderr, so a
``print`` goes to the extension's log instead of breaking a frame.
"""

from __future__ import annotations

import inspect
import sys
import threading
from typing import Any, BinaryIO, cast

from .protocol import (
    DOWNLOAD_FETCH,
    HOST_PREFERENCES,
    HTTP_REQUEST,
    INSTANCES_CONFIGURATION,
    INTERNAL_ERROR,
    INVALID_PARAMS,
    LOG_WRITE,
    METHOD_NOT_FOUND,
    PROCESS_RUN,
    PROTOCOL_VERSION,
    RUNTIME_RESOLVE,
    RUNTIME_STATUS,
    SETTINGS_GET,
    SETTINGS_PATCH,
    WEBVIEW_CLOSE,
    WEBVIEW_NAVIGATE,
    WEBVIEW_PAGES,
    WEBVIEW_RELOAD,
    WEBVIEW_SHOW,
    TOOLS_CALL,
    TOOLS_LIST,
    TOOLS_REGISTER,
    TOOLS_UNREGISTER,
    UI_EMIT,
    UI_FRAME_EMIT,
    UI_PROGRESS,
    UI_PROMPT,
    UI_TASK_CENTER_OPEN,
    UNAVAILABLE,
    DiagnosticsCollectResult,
    DownloadFetchParams,
    DownloadFetchResult,
    HostPreferences,
    HttpRequestParams,
    HttpRequestResult,
    InstanceConfigurationResult,
    ProcessRunParams,
    ProcessRunResult,
    RpcError,
    RuntimeResolveParams,
    RuntimeResolveResult,
    RuntimeStatusParams,
    RuntimeStatusResult,
    SettingsPatchParams,
    SettingsResult,
    UiProgressParams,
    UiPromptParams,
    WebviewNavigateParams,
    WebviewPageParams,
    WebviewPagesParams,
    WebviewPagesResult,
    read_frame,
    write_frame,
)

HOOKS = ("activate", "deactivate", "migrate", "uninstall")
# Announced when a handler overrides either: its UI in the owner protocol.
_UI = "ui"
_UI_METHODS = ("ui_state", "ui_call")
_MANAGE = "provider.manage."
_SERVICE = "service."


class Host:
    """The application at the other end of stdin and stdout; any thread may call it."""

    def __init__(self, writer: BinaryIO) -> None:
        """Builds the host.

        Args:
            writer: The binary stream the backend writes its messages to.
        """
        self._writer = writer
        self._lock = threading.Lock()
        self._pending: dict[int, list[Any]] = {}
        self._next_id = 1
        self._closed = False
        self.initialize_params: dict[str, Any] = {}

    def call(self, method: str, params: Any = None) -> Any:
        """Calls ``method`` and waits for its answer.

        Args:
            method: The host method (``host.info``, ``process.run``, ...).
            params: Its params, as JSON.

        Returns:
            Its result.

        Raises:
            RpcError: The call failed, or the application closed the connection.
        """
        done = threading.Event()
        slot: list[Any] = [done, None, None]
        with self._lock:
            if self._closed:
                raise RpcError(UNAVAILABLE, "the application closed the connection")
            call_id = self._next_id
            self._next_id += 1
            self._pending[call_id] = slot
        message = {"jsonrpc": "2.0", "id": call_id, "method": method, "params": params or {}}
        try:
            self._send(message)
        except OSError as error:
            with self._lock:
                self._pending.pop(call_id, None)
            raise RpcError(UNAVAILABLE, str(error)) from error
        done.wait()
        if slot[2] is not None:
            raise slot[2]
        return slot[1]

    def notify(self, method: str, params: Any = None) -> None:
        """Sends a notification, which has no answer.

        Args:
            method: The method.
            params: Its params, as JSON.
        """
        self._send({"jsonrpc": "2.0", "method": method, "params": params or {}})

    def ui_prompt(self, params: UiPromptParams) -> None:
        """Queue a question and receive its answer in a ui.prompt.result notification.

        Args:
            params: The question id, kind and message shown by the main window.
        """
        self.call(UI_PROMPT, params)

    def ui_progress(self, params: UiProgressParams) -> None:
        """Report work in the Task Center and optionally its instance's management view.

        Args:
            params: Progress id, title, optional instanceId and progress or completion details.
        """
        self.call(UI_PROGRESS, params)

    def ui_task_center_open(self, tab: str) -> None:
        """Ask the Task Center to show one of this extension's tabs.

        Args:
            tab: The panel's or frame's own id, as ``contributes.ui`` names it.
        """
        self.call(UI_TASK_CENTER_OPEN, {"tab": tab})

    def instance_configuration(self, instance_id: str) -> InstanceConfigurationResult:
        """Reads the non-secret install and launch fields of an instance of its own types.

        Args:
            instance_id: The instance named by the management UI or callback.

        Returns:
            The current values and launchValues with their truncation flags.
        """
        return cast(
            InstanceConfigurationResult,
            self.call(INSTANCES_CONFIGURATION, {"id": instance_id}),
        )

    def webview_pages(self, params: WebviewPagesParams | None = None) -> WebviewPagesResult:
        """Lists the embedded WebUI pages of its own types' instances that are open.

        Args:
            params: Optionally one instance; every one of its instances when absent.

        Returns:
            Each open page with its launch, page id, role, state and authorized address.
        """
        return cast(WebviewPagesResult, self.call(WEBVIEW_PAGES, params or {}))

    def webview_show(self, params: WebviewPageParams) -> None:
        """Asks the application window to show one page of one launch of its own instance."""
        self.call(WEBVIEW_SHOW, params)

    def webview_close(self, params: WebviewPageParams) -> None:
        """Closes one page that waits off screen; the page on screen is closed with its workspace."""
        self.call(WEBVIEW_CLOSE, params)

    def webview_reload(self, params: WebviewPageParams) -> None:
        """Reloads the document of one open page."""
        self.call(WEBVIEW_RELOAD, params)

    def webview_navigate(self, params: WebviewNavigateParams) -> None:
        """Takes one open page to an address on its authorized origin.

        Raises:
            RpcError: ``PERMISSION_DENIED`` for another origin, ``REQUEST_FAILED`` for a page
                that is not open.
        """
        self.call(WEBVIEW_NAVIGATE, params)

    def emit_frame(
        self,
        frame: str,
        event: str,
        payload: Any = None,
        *,
        instance_id: str | None = None,
    ) -> None:
        """Sends ``event`` to its frame ``frame`` (``ui.frame.emit``).

        Each open frame of that id hands it to its page's listeners of the event.

        Args:
            frame: The frame's id.
            event: The event's name.
            payload: What it carries, as JSON.
            instance_id: Deliver only to frames shown for this instance.
        """
        params = {"frame": frame, "event": event, "payload": payload}
        if instance_id is not None:
            params["instanceId"] = instance_id
        self.notify(UI_FRAME_EMIT, params)

    def emit_state(self, state: Any, *, instance_id: str | None = None) -> None:
        """Pushes ``state`` as its UI's new state (``ui.emit``) to every window and frame showing it.

        Only a handler that overrides ``ui_state`` or ``ui_call`` is heard, once its
        UI is exposed: a state sent before (during ``activate``) is dropped, and a
        window reads ``ui_state`` when it starts showing it anyway.

        Args:
            state: The whole state, as JSON.
            instance_id: Deliver only to views shown for this instance.
        """
        params = {"state": state}
        if instance_id is not None:
            params["instanceId"] = instance_id
        self.notify(UI_EMIT, params)

    def register_tools(self, tools: list[dict[str, Any]]) -> None:
        """Adds MCP tools, or replaces this backend's (or the manifest's) by name
        (``tools.register``); the sessions that list tools hear it.

        Args:
            tools: Each ``name``, ``description`` and ``inputSchema`` (an object schema).

        Raises:
            Nothing here: a tool the host cannot list refuses the whole message on
            the host's side, and none is registered; the backend's log says why.
        """
        self.notify(TOOLS_REGISTER, {"tools": tools})

    def unregister_tools(self, names: list[str]) -> None:
        """Removes MCP tools by name (``tools.unregister``); a manifest's is listed
        again once the backend's over it is removed.

        Args:
            names: The local names.
        """
        self.notify(TOOLS_UNREGISTER, {"names": names})

    def list_tools(self) -> list[dict[str, Any]]:
        """Lists the management catalog's tools (``tools.list``; ``management = read`` or ``confirm``).

        Returns:
            Each tool's ``name``, ``title``, ``description``, ``scope`` (``read`` or
            ``confirm``), ``annotations``, ``inputSchema`` and ``builtInOnly``.

        Raises:
            RpcError: ``PERMISSION_DENIED`` without ``management``.
        """
        result = self.call(TOOLS_LIST)
        tools = result.get("tools", []) if isinstance(result, dict) else []
        return tools if isinstance(tools, list) else []

    def http_request(self, params: HttpRequestParams) -> HttpRequestResult:
        """Read bounded UTF-8 HTTP; non-2xx responses retain their actual status.

        Args:
            params: URL and optional method, repeated headers, body and smaller bounds.

        Returns:
            HTTP status, headers and body.

        Raises:
            RpcError: Invalid input, denied host, timeout, transport or response failure.
        """
        return cast(HttpRequestResult, self.call(HTTP_REQUEST, params))

    def settings_get(self) -> SettingsResult:
        """Read the extension's own canonical settings.

        Returns:
            The extension's settings values.

        Raises:
            RpcError: The host could not read the settings.
        """
        return cast(SettingsResult, self.call(SETTINGS_GET))

    def host_preferences(self) -> HostPreferences:
        """Read the host's non-sensitive preferences, without proxy credentials.

        Returns:
            The same full snapshot as a preferences event payload.

        Raises:
            RpcError: The host could not read its current preferences.
        """
        return cast(HostPreferences, self.call(HOST_PREFERENCES))

    def runtime_status(self, params: RuntimeStatusParams | None = None) -> RuntimeStatusResult:
        """Read tool readiness without starting preparation.

        Args:
            params: Optional tool filter; omit it to read all three tools.

        Returns:
            Tool readiness, native paths and optional verified version/output.

        Raises:
            RpcError: The host could not read runtime state.
        """
        return cast(RuntimeStatusResult, self.call(RUNTIME_STATUS, params))

    def runtime_resolve(self, params: RuntimeResolveParams) -> RuntimeResolveResult:
        """Wait for a host-managed tool; requires processes permission.

        Args:
            params: The tool to resolve through the host's existing preparation.

        Returns:
            The ready executable's native path and optional verified version/output.

        Raises:
            RpcError: Permission denied, unavailable runtime, preparation failure or stop.
        """
        return cast(RuntimeResolveResult, self.call(RUNTIME_RESOLVE, params))

    def settings_patch(self, params: SettingsPatchParams) -> SettingsResult:
        """Persist a patch to declared settings and return canonical values.

        Args:
            params: A patch whose null values remove saved overrides.

        Returns:
            Values after the successful write; the host also publishes settings.

        Raises:
            RpcError: A key or value is invalid, or persistence failed.
        """
        return cast(SettingsResult, self.call(SETTINGS_PATCH, params))

    def download_fetch(self, params: DownloadFetchParams) -> DownloadFetchResult:
        """Download to extension data with optional host mirrors and digest cache.

        Args:
            params: Source URL, destination and optional digest, source and cache choice.

        Returns:
            Destination path and SHA-256 digest.

        Raises:
            RpcError: Permission, download, digest or destination failure.
        """
        return cast(DownloadFetchResult, self.call(DOWNLOAD_FETCH, params))

    def process_run(self, params: ProcessRunParams) -> ProcessRunResult:
        """Start a task, optionally giving this child the host's proxy environment.

        Args:
            params: Program arguments, optional cwd/env and explicit useHostProxy choice.

        Returns:
            The host task id.

        Raises:
            RpcError: Permission, input or process startup failure.
        """
        return cast(ProcessRunResult, self.call(PROCESS_RUN, params))

    def call_tool(self, name: str, arguments: dict[str, Any] | None = None) -> Any:
        """Runs the management catalog's tool ``name`` (``tools.call``).

        A mutation needs ``management = confirm`` and waits for the user's answer in the
        application's window, at most a minute: call it from a thread of its own, never
        from a handler the application waits on.

        Args:
            name: The tool, as ``list_tools`` lists it.
            arguments: Its arguments, as its ``inputSchema`` describes them.

        Returns:
            The tool's own result.

        Raises:
            RpcError: ``PERMISSION_DENIED`` outside its permission, ``INVALID_PARAMS`` for an
                unknown tool or arguments it does not read, ``REQUEST_FAILED`` when it was
                refused or failed.
        """
        return self.call(TOOLS_CALL, {"name": name, "arguments": arguments or {}})

    def log(self, level: str, message: str) -> None:
        """Writes a line to the extension's log.

        Args:
            level: ``error``, ``warn``, ``info`` or ``debug``.
            message: The line.
        """
        try:
            self.notify(LOG_WRITE, {"level": level, "message": message})
        except OSError:
            pass

    def _send(self, message: dict[str, Any]) -> None:
        with self._lock:
            write_frame(self._writer, message)

    def _resolve(self, message: dict[str, Any]) -> None:
        with self._lock:
            slot = self._pending.pop(message.get("id"), None)  # type: ignore[arg-type]
        if slot is None:
            return
        error = message.get("error")
        if isinstance(error, dict):
            slot[2] = RpcError(
                int(error.get("code", INTERNAL_ERROR)),
                str(error.get("message", "")),
                error.get("data"),
            )
        else:
            slot[1] = message.get("result")
        slot[0].set()

    def _close(self) -> None:
        with self._lock:
            self._closed = True
            pending = list(self._pending.values())
            self._pending.clear()
        for slot in pending:
            slot[2] = RpcError(UNAVAILABLE, "the application closed the connection")
            slot[0].set()


class Handler:
    """What a backend does: override the methods it implements.

    The hooks it overrides (``activate``, ``deactivate``, ``migrate``,
    ``uninstall``, and ``ui`` for ``ui_state`` or ``ui_call``) are announced
    in ``initialize``'s answer, so the application calls only those. Every
    method but ``notification`` runs on a thread of its own and may call the
    application through ``host``.
    """

    def hooks(self) -> list[str]:
        """The hooks this handler overrides.

        Returns:
            Their names.
        """
        hooks = [name for name in HOOKS if self._overrides(name)]
        if any(self._overrides(name) for name in _UI_METHODS):
            hooks.append(_UI)
        if self._overrides("diagnostics_collect_instance"):
            hooks.append("diagnostics.collectInstance")
        if self._overrides("diagnostics_collect"):
            hooks.append("diagnostics")
        return hooks

    def _overrides(self, name: str) -> bool:
        return getattr(type(self), name) is not getattr(Handler, name)

    def tools(self) -> list[dict[str, Any]]:
        """The MCP tools it publishes beside the manifest's (and over one of those
        by name): each ``name``, ``description`` and ``inputSchema``, answered as
        ``service.<name>`` in :meth:`request`. Changed while it runs with
        :meth:`Host.register_tools` and :meth:`Host.unregister_tools`.

        Returns:
            The tools; none by default.
        """
        return []

    def initialize(self, host: Host, params: dict[str, Any]) -> dict[str, Any]:
        """Answers ``initialize``: this protocol's version, the hooks and the tools.

        Args:
            host: The application.
            params: The extension, its permissions, its data directory, the locale.

        Returns:
            The answer.
        """
        return {
            "protocolVersion": PROTOCOL_VERSION,
            "hooks": self.hooks(),
            "tools": self.tools(),
        }

    def ping(self, host: Host) -> None:
        """Answers ``ping``.

        Args:
            host: The application.
        """

    def activate(self, host: Host) -> None:
        """The ``activate`` hook.

        Args:
            host: The application.
        """

    def deactivate(self, host: Host) -> None:
        """The ``deactivate`` hook.

        Args:
            host: The application.
        """

    def migrate(self, host: Host, from_version: str) -> None:
        """The ``migrate`` hook, after an update.

        Args:
            host: The application.
            from_version: The version the update replaced.
        """

    def uninstall(self, host: Host) -> None:
        """The ``uninstall`` hook.

        Args:
            host: The application.
        """

    def validate_spec(
        self,
        host: Host,
        type_id: str,
        values: dict[str, Any],
        instance: dict[str, Any] | None = None,
    ) -> dict[str, str]:
        """``provider.validateSpec``: what is wrong with an instance's values.

        Args:
            host: The application.
            type_id: One of its types.
            values: The install parameters' values.
            instance: The instance whose values change, when it exists (a
                reinstall with new values): ``{"id": ..., "components":
                {name: {"path": ..., "external": ...}}}``. Passed by keyword,
                and only then; an override without the parameter is called
                without it.

        Returns:
            Problems by parameter; none when the values are good.
        """
        return {}

    def install_plan(
        self,
        host: Host,
        type_id: str,
        kind: str,
        values: dict[str, Any],
        instance: dict[str, Any],
        *,
        recreate_components: list[str] | None = None,
    ) -> list[dict[str, Any]]:
        """``provider.installPlan``: the steps the host runs.

        Args:
            host: The application.
            type_id: One of its types.
            kind: ``install``, ``reinstall`` or ``update``.
            recreate_components: Components the host removes before running these steps.
            values: The install parameters' values.
            instance: ``{"id": ..., "components": {name: {"path": ..., "external": ...}}}``:
                where each component is, and whether it is a folder of the
                user's that a plan must not empty or replace.

        Returns:
            Steps written as a declarative type's ``install.steps``.

        Raises:
            RpcError: Unless overridden.
        """
        raise RpcError(METHOD_NOT_FOUND, "no method provider.installPlan")

    def launch_preflight(
        self,
        host: Host,
        type_id: str,
        values: dict[str, Any],
        launch_values: dict[str, Any],
        instance: dict[str, Any],
    ) -> None:
        """Check an instance before its server group starts; raise RpcError to refuse."""
        raise RpcError(METHOD_NOT_FOUND, "no method provider.launchPreflight")

    def launch_options(
        self, host: Host, type_id: str, instance: dict[str, Any]
    ) -> dict[str, list[str]]:
        """Return launch select choices by source for this instance.

        Args:
            host: The application.
            type_id: One of the extension’s types.
            instance: The instance id and its resolved components.

        Returns:
            The available strings for each optionsSource in its launch fields.

        Raises:
            RpcError: Unless overridden.
        """
        raise RpcError(METHOD_NOT_FOUND, "no method provider.launchOptions")

    def launch_plan(
        self,
        host: Host,
        type_id: str,
        role: str,
        port: int,
        values: dict[str, Any],
        instance: dict[str, Any],
        *,
        launch_values: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """``provider.launchPlan``: the command a role runs.

        Args:
            host: The application.
            type_id: One of its types.
            role: The server role.
            port: The port it listens on.
            values: The install parameters' values.
            launch_values: Settings from this instance's launch form.
            instance: ``{"id": ..., "components": {name: {"path": ..., "external": ...}}}``:
                where each component is, and whether it is a folder of the
                user's that a plan must not empty or replace.

        Returns:
            The command as ``argv`` and ``env``, placeholders allowed.

        Raises:
            RpcError: Unless overridden.
        """
        raise RpcError(METHOD_NOT_FOUND, "no method provider.launchPlan")

    def check_update(
        self, host: Host, type_id: str, values: dict[str, Any], instance: dict[str, Any]
    ) -> dict[str, Any]:
        """``provider.checkUpdate``: whether an applicable update exists for the instance.

        Called for a type that declares ``update-check``, once per instance by the
        daily check, within the call's bound: cache or share what it fetches. The
        instance may be running; the check must not change it.

        Args:
            host: The application.
            type_id: One of its types.
            values: The instance's install parameters' values.
            instance: ``{"id": ..., "components": {name: {"path": ..., "external": ...}}}``:
                where each component is.

        Returns:
            ``{"current": ..., "latest": ..., "hasUpdate": ..., "notes": ...}``: the
            installed and the newest version as the user reads them, whether an
            update is available (``False`` for an instance its
            values pin), and anything more for the user. Optional ``components`` lists
            per-component results with ``name``, ``hasUpdate`` and optional
            ``current`` and ``latest``. A component update marks the instance updatable.

        Raises:
            RpcError: Unless overridden; a failed check, which is recorded on the
                instance.
        """
        raise RpcError(METHOD_NOT_FOUND, "no method provider.checkUpdate")

    def manage(
        self,
        host: Host,
        type_id: str,
        operation: str,
        instance: dict[str, Any],
        *,
        values: dict[str, Any] | None = None,
    ) -> str | dict[str, Any] | None:
        """``provider.manage.<operation>``: an operation of its type's own.

        Args:
            host: The application.
            type_id: One of its types.
            operation: The operation.
            values: The checked operation form values, including defaults.
            instance: ``{"id": ..., "components": {name: {"path": ..., "external": ...}}}``:
                where each component is, and whether it is a folder of the
                user's that a plan must not empty or replace.

        Returns:
            A notice, ``None``, or a plan with ``steps`` and an optional
            ``notice``. The host runs those steps under exclusive maintenance.

        Raises:
            RpcError: Unless overridden.
        """
        raise RpcError(METHOD_NOT_FOUND, f"no method {_MANAGE}{operation}")

    def panel_query(
        self, host: Host, panel: str, block: str, context: dict[str, Any]
    ) -> dict[str, Any]:
        """``ui.panel.query``: the data of one of its panels' blocks.

        Args:
            host: The application.
            panel: The panel's id.
            block: The block's id.
            context: ``{"instanceId": ...}`` in an instance's management.

        Returns:
            The block's data: ``rows`` for an info or table block, ``lines`` for a log.

        Raises:
            RpcError: Unless overridden.
        """
        raise RpcError(METHOD_NOT_FOUND, "no method ui.panel.query")

    def panel_action(
        self,
        host: Host,
        panel: str,
        action: str,
        values: dict[str, Any],
        context: dict[str, Any],
        row: str | None = None,
    ) -> str | None:
        """``ui.panel.action``: one of its panels' actions was pressed.

        Args:
            host: The application.
            panel: The panel's id.
            action: The action's id.
            values: Its form's values.
            context: ``{"instanceId": ...}`` in an instance's management.
            row: The ``id`` of the ``list`` row it was pressed on, for a list's
                action; an override that does not take it is called without it.

        Returns:
            A notice for the user, or ``None``.

        Raises:
            RpcError: Unless overridden.
        """
        raise RpcError(METHOD_NOT_FOUND, "no method ui.panel.action")

    def frame_call(
        self, host: Host, frame: str, method: str, params: Any, context: dict[str, Any]
    ) -> Any:
        """``ui.frame.call``: a page of one of its frames called it.

        Args:
            host: The application.
            frame: The frame's id.
            method: What the page called, as it named it.
            params: What the page sent.
            context: ``{"instanceId": ...}`` in an instance's management.

        Returns:
            What the page's call resolves with.

        Raises:
            RpcError: Unless overridden.
        """
        raise RpcError(METHOD_NOT_FOUND, "no method ui.frame.call")

    def ui_state(self, host: Host, context: dict[str, Any]) -> Any:
        """``ui.state``: its UI's state, which its panels' ``state`` blocks and its frames show.

        Read when a window starts showing it; push a new one with ``host.emit_state``.

        Args:
            host: The application.
            context: ``{"instanceId": ...}`` in an instance's management.

        Returns:
            The state, as JSON.

        Raises:
            RpcError: Unless overridden.
        """
        raise RpcError(METHOD_NOT_FOUND, "no method ui.state")

    def ui_call(self, host: Host, action: str, args: Any, context: dict[str, Any]) -> Any:
        """``ui.call``: one of its UI's actions, answered to its caller only.

        An ``RpcError`` keeps its kind: ``INVALID_PARAMS`` is ``invalid``,
        ``PERMISSION_DENIED`` ``forbidden``, any other ``failed``.

        Args:
            host: The application.
            action: The action's name.
            args: What the UI sent, as JSON.
            context: ``{"instanceId": ...}`` in an instance's management.

        Returns:
            Its answer, as JSON.

        Raises:
            RpcError: For an action it does not have, unless overridden.
        """
        raise RpcError(INVALID_PARAMS, f"no action `{action}`")

    def service(self, host: Host, method: str, caller: str, params: Any) -> Any:
        """``service.<method>``: handles an exported service or a published management MCP tool.

        Args:
            host: The application.
            method: The exported method.
            caller: The calling extension's id, or ``mcp:hanafubuki`` for a management MCP tool.
            params: Its params.

        Returns:
            The result.

        Raises:
            RpcError: Unless overridden.
        """
        raise RpcError(METHOD_NOT_FOUND, f"no method {_SERVICE}{method}")

    def request(self, host: Host, method: str, params: Any) -> Any:
        """Any other request.

        Args:
            host: The application.
            method: The method.
            params: Its params.

        Returns:
            The result.

        Raises:
            RpcError: Unless overridden.
        """
        raise RpcError(METHOD_NOT_FOUND, f"no method {method}")

    def diagnostics_collect_instance(
        self, host: Host, instance_id: str
    ) -> DiagnosticsCollectResult:
        """Contribute documents for one instance of this extension's types.

        Args:
            host: The application.
            instance_id: The instance being collected.

        Returns:
            Documents with single filenames and text, without credentials.

        Raises:
            RpcError: Collection failed or this handler does not implement it.
        """
        raise RpcError(METHOD_NOT_FOUND, "no method diagnostics.collectInstance")

    def diagnostics_collect(self, host: Host) -> DiagnosticsCollectResult:
        """Contribute text documents to the diagnostic bundle; override to announce it.

        Args:
            host: The application.

        Returns:
            Documents with single filenames and text. Never include credentials.

        Raises:
            RpcError: Collection failed or this handler does not implement it.
        """
        raise RpcError(METHOD_NOT_FOUND, "no method diagnostics.collect")

    def notification(self, host: Host, method: str, params: Any) -> None:
        """A notification (an event, a process's output); runs on the loop's thread.

        Args:
            host: The application.
            method: The method.
            params: Its params.
        """

    def shutdown(self, host: Host) -> None:
        """The application asked it to shut down; ``run`` returns after this.

        Args:
            host: The application.
        """


def run(handler: Handler, reader: BinaryIO | None = None, writer: BinaryIO | None = None) -> None:
    """Runs ``handler`` until the application asks it to shut down or closes stdin.

    Args:
        handler: What the backend does.
        reader: The stream the application writes to; stdin by default.
        writer: The stream the backend writes to; stdout by default.

    Raises:
        FrameError: The application sent what is not the protocol.
    """
    if reader is None:
        reader = sys.stdin.buffer
    if writer is None:
        writer = sys.stdout.buffer
        sys.stdout = sys.stderr
    host = Host(writer)
    try:
        while True:
            message = read_frame(reader)
            if message is None:
                return
            if "method" not in message:
                host._resolve(message)
                continue
            method = str(message["method"])
            params = message.get("params")
            if "id" not in message:
                handler.notification(host, method, params)
                continue
            if method == "shutdown":
                handler.shutdown(host)
                _answer(host, message["id"], {}, None)
                return
            threading.Thread(
                target=_respond, args=(handler, host, message["id"], method, params), daemon=True
            ).start()
    finally:
        host._close()


def _respond(handler: Handler, host: Host, call_id: Any, method: str, params: Any) -> None:
    try:
        result, error = _dispatch(handler, host, method, params), None
    except RpcError as failure:
        result, error = None, failure
    except Exception as failure:  # noqa: BLE001 - a handler's bug answers its call, not the loop
        result, error = None, RpcError(INTERNAL_ERROR, f"{type(failure).__name__}: {failure}")
    try:
        _answer(host, call_id, result, error)
    except OSError:
        pass


def _answer(host: Host, call_id: Any, result: Any, error: RpcError | None) -> None:
    message: dict[str, Any] = {"jsonrpc": "2.0", "id": call_id}
    if error is None:
        message["result"] = {} if result is None else result
    else:
        message["error"] = error.to_json()
    host._send(message)


def _takes(method: Any, name: str) -> bool:
    """Whether a handler's method takes ``name``: one written before it was passed is still called.

    Args:
        method: The handler's bound method, such as ``validate_spec``.
        name: The keyword, such as ``instance``.

    Returns:
        Whether it names ``name`` or takes any keyword.
    """
    try:
        parameters = inspect.signature(method).parameters
    except (TypeError, ValueError):
        return False
    return name in parameters or any(
        parameter.kind is inspect.Parameter.VAR_KEYWORD for parameter in parameters.values()
    )


def _dispatch(handler: Handler, host: Host, method: str, raw: Any) -> Any:
    params: dict[str, Any] = raw if isinstance(raw, dict) else {}
    if method == "initialize":
        host.initialize_params = params
        return handler.initialize(host, params)
    if method == "ping":
        handler.ping(host)
        return {}
    if method == "diagnostics.collectInstance":
        return handler.diagnostics_collect_instance(host, _text(params, "id"))
    if method == "diagnostics.collect":
        return handler.diagnostics_collect(host)
    if method == "migrate":
        handler.migrate(host, str(params.get("fromVersion", "")))
        return {}
    if method in HOOKS:
        getattr(handler, method)(host)
        return {}
    if method == "provider.validateSpec":
        instance = params.get("instance")
        if isinstance(instance, dict) and _takes(handler.validate_spec, "instance"):
            issues = handler.validate_spec(
                host, _text(params, "type"), _object(params, "values"), instance=instance
            )
        else:
            issues = handler.validate_spec(host, _text(params, "type"), _object(params, "values"))
        return {"issues": issues}
    if method == "provider.installPlan":
        selection = (
            {"recreate_components": params.get("recreateComponents", [])}
            if _takes(handler.install_plan, "recreate_components")
            else {}
        )
        steps = handler.install_plan(
            host,
            _text(params, "type"),
            _text(params, "kind"),
            _object(params, "values"),
            _object(params, "instance"),
            **selection,
        )
        return {"steps": steps}
    if method == "provider.launchPreflight":
        handler.launch_preflight(
            host,
            _text(params, "type"),
            _object(params, "values"),
            _object(params, "launchValues"),
            _object(params, "instance"),
        )
        return {}
    if method == "provider.launchOptions":
        return {
            "options": handler.launch_options(
                host, _text(params, "type"), _object(params, "instance")
            )
        }
    if method == "provider.launchPlan":
        port = params.get("port", 0)
        launch = (
            {"launch_values": _object(params, "launchValues")}
            if _takes(handler.launch_plan, "launch_values")
            else {}
        )
        return handler.launch_plan(
            host,
            _text(params, "type"),
            _text(params, "role"),
            port if isinstance(port, int) else 0,
            _object(params, "values"),
            _object(params, "instance"),
            **launch,
        )
    if method == "provider.checkUpdate":
        return handler.check_update(
            host, _text(params, "type"), _object(params, "values"), _object(params, "instance")
        )
    if method.startswith(_MANAGE):
        result = handler.manage(
            host,
            _text(params, "type"),
            method[len(_MANAGE) :],
            _object(params, "instance"),
            **({"values": _object(params, "values")} if _takes(handler.manage, "values") else {}),
        )
        return result if isinstance(result, dict) else {"notice": result}
    if method == "ui.panel.query":
        return handler.panel_query(
            host, _text(params, "panel"), _text(params, "block"), _object(params, "context")
        )
    if method == "ui.panel.action":
        row = params.get("row")
        pressed_on = (
            {"row": row} if isinstance(row, str) and _takes(handler.panel_action, "row") else {}
        )
        notice = handler.panel_action(
            host,
            _text(params, "panel"),
            _text(params, "action"),
            _object(params, "values"),
            _object(params, "context"),
            **pressed_on,
        )
        return {"notice": notice}
    if method == "ui.frame.call":
        return handler.frame_call(
            host,
            _text(params, "frame"),
            _text(params, "method"),
            params.get("params"),
            _object(params, "context"),
        )
    if method == "ui.state":
        return handler.ui_state(host, _object(params, "context"))
    if method == "ui.call":
        return handler.ui_call(
            host, _text(params, "action"), params.get("args"), _object(params, "context")
        )
    if method.startswith(_SERVICE):
        return handler.service(
            host, method[len(_SERVICE) :], _text(params, "caller"), params.get("params")
        )
    return handler.request(host, method, raw)


def _text(params: dict[str, Any], name: str) -> str:
    value = params.get(name, "")
    if not isinstance(value, str):
        raise RpcError(INVALID_PARAMS, f"invalid params: `{name}` is not text")
    return value


def _object(params: dict[str, Any], name: str) -> dict[str, Any]:
    value = params.get(name)
    if value is None:
        return {}
    if not isinstance(value, dict):
        raise RpcError(INVALID_PARAMS, f"invalid params: `{name}` is not an object")
    return value


__all__ = ["HOOKS", "Handler", "Host", "run"]
