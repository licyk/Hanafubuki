//! The program on its own, without the application: as a backend over its
//! stdio, and as the instance's server. The application's own suite installs
//! and runs the whole package (`src-tauri/src/api_server/declared/tests/greeter.rs`).

use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::process::{Child, Command, Stdio};
use std::time::{Duration, Instant};

use hanafubuki_extension_sdk::protocol::{
    encode_frame, method, FrameDecoder, Id, Message, PROTOCOL_VERSION,
};
use serde_json::{json, Value};

const PROGRAM: &str = env!("CARGO_BIN_EXE_greeter");

#[test]
fn the_backend_checks_values_and_plans_the_install() {
    let requests = [
        (
            method::INITIALIZE,
            json!({ "protocolVersion": PROTOCOL_VERSION }),
        ),
        (
            method::PROVIDER_VALIDATE_SPEC,
            json!({ "type": "com.example.greeter:greeter", "values": { "greeting": "x".repeat(201) } }),
        ),
        (
            method::PROVIDER_INSTALL_PLAN,
            json!({ "type": "com.example.greeter:greeter", "kind": "install", "values": {} }),
        ),
    ];
    let answers = exchange(&requests);
    assert_eq!(answers[0]["protocolVersion"], PROTOCOL_VERSION);
    assert_eq!(answers[1]["issues"]["greeting"], "at most 200 characters");
    assert_eq!(
        answers[2]["steps"][0],
        json!({
            "kind": "write-file",
            "title": { "en": "Write greeting file", "zh": "写入问候语文件" },
            "path": "{component.core}/greeting.txt",
            "content": "{param.greeting}"
        })
    );
}

#[test]
fn the_backend_has_a_ui_whose_panel_action_greets() {
    let requests = [
        (
            method::INITIALIZE,
            json!({ "protocolVersion": PROTOCOL_VERSION }),
        ),
        (method::UI_STATE, json!({ "context": {} })),
        (
            method::UI_PANEL_ACTION,
            json!({ "panel": "greetings", "action": "greet", "values": { "to": "test" }, "context": {} }),
        ),
    ];
    let answers = exchange(&requests);
    assert!(answers[0]["hooks"]
        .as_array()
        .unwrap()
        .contains(&json!("ui")));
    // Its requests are answered concurrently: the state read may come
    // before or after the greeting.
    assert!(answers[1]["greetings"]["rows"].is_array());
    assert_eq!(answers[2], json!({ "notice": "Hello, test!" }));
}

/// `package/tools/greet.json` is a management tool the backend answers as
/// `service.greet`, with the client's arguments.
#[test]
fn the_backend_answers_its_published_tool() {
    let requests = [
        (
            method::INITIALIZE,
            json!({ "protocolVersion": PROTOCOL_VERSION }),
        ),
        ("service.greet", json!({ "person": "tool" })),
    ];
    let answers = exchange(&requests);
    assert_eq!(answers[1], json!({ "text": "Hello, tool!" }));
}

#[test]
fn the_server_answers_its_readiness_and_its_page() {
    let core = tempfile::tempdir().unwrap();
    std::fs::write(core.path().join("greeting.txt"), "Hello <world>\n").unwrap();
    let port = TcpListener::bind("127.0.0.1:0")
        .unwrap()
        .local_addr()
        .unwrap()
        .port();
    let server = Server(
        Command::new(PROGRAM)
            .args([
                "serve",
                "--port",
                &port.to_string(),
                "--signature",
                "from {a} test",
            ])
            .current_dir(core.path())
            .stderr(Stdio::null())
            .spawn()
            .unwrap(),
    );
    let deadline = Instant::now() + Duration::from_secs(10);
    let health = loop {
        match get(port, "/health") {
            Some(answer) => break answer,
            None if Instant::now() < deadline => std::thread::sleep(Duration::from_millis(50)),
            None => panic!("the server never answered"),
        }
    };
    assert!(health.starts_with("HTTP/1.1 200"), "{health}");
    let page = get(port, "/").unwrap();
    assert!(page.contains("<h1>Hello &lt;world&gt;</h1>"), "{page}");
    assert!(page.contains("from {a} test"), "{page}");
    assert!(get(port, "/missing").unwrap().starts_with("HTTP/1.1 404"));
    drop(server);
}

/// Sends `requests` to a backend, waits for every answer, then shuts it
/// down; the answers' results, in order.
fn exchange(requests: &[(&str, Value)]) -> Vec<Value> {
    let data = tempfile::tempdir().unwrap();
    let mut backend = Command::new(PROGRAM)
        .env("HANAFUBUKI_EXTENSION_DATA", data.path())
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .unwrap();
    let mut input = backend.stdin.take().unwrap();
    let mut output = backend.stdout.take().unwrap();
    let send = |input: &mut std::process::ChildStdin, id: usize, name: &str, params: Value| {
        let request = Message::request(Id::Number(id as i64), name, params);
        input.write_all(&encode_frame(&request.encode())).unwrap();
    };
    for (id, (name, params)) in requests.iter().enumerate() {
        send(&mut input, id, name, params.clone());
    }
    let mut answers = vec![None; requests.len()];
    let mut decoder = FrameDecoder::default();
    let mut buffer = [0_u8; 4096];
    while answers.iter().any(Option::is_none) {
        let read = output.read(&mut buffer).unwrap();
        assert!(read > 0, "the backend ended before it answered");
        decoder.push(&buffer[..read]);
        while let Some(body) = decoder.next_frame().unwrap() {
            if let Message::Response {
                id: Some(Id::Number(id)),
                outcome,
            } = Message::decode(&body).unwrap()
            {
                answers[id as usize] = Some(outcome.unwrap());
            }
        }
    }
    send(&mut input, requests.len(), method::SHUTDOWN, json!({}));
    assert!(backend.wait().unwrap().success());
    answers.into_iter().flatten().collect()
}

fn get(port: u16, path: &str) -> Option<String> {
    let mut stream = TcpStream::connect(("127.0.0.1", port)).ok()?;
    write!(stream, "GET {path} HTTP/1.1\r\nHost: localhost\r\n\r\n").ok()?;
    let mut answer = String::new();
    stream.read_to_string(&mut answer).ok()?;
    Some(answer)
}

struct Server(Child);

impl Drop for Server {
    fn drop(&mut self) {
        let _ = self.0.kill();
        let _ = self.0.wait();
    }
}
