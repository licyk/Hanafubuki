# Greeter: a sample Hanafubuki extension

Greeter adds an instance type that needs no Python: each instance is a page
that shows a greeting, served by the extension's own program. It is small,
but it goes through the main paths an extension takes: a native backend on
the Rust SDK, a type its backend provides, an install parameter, a preset
that fills it, a server role the embedded browser opens, extension
settings, a frame, a schema panel that follows the state its backend
pushes, and strings in two languages.

It lives in the application's repository so that the application's tests
build, install and run it. It is meant to be copied into a repository of its
own: see [Copying it out](#copying-it-out).

## What is where

| Path | What |
| --- | --- |
| `package/hanafubuki-extension.toml` | The manifest: id `com.example.greeter`, the backend program per OS, the permission it needs, what it contributes. |
| `package/types/greeter.toml` | The `greeter` type: `provider = "backend"`, one `core` component, no runtime, the `greeting` parameter, one `ui` server role. |
| `package/presets/morning.toml` | A preset over the `greeter` type: the create wizard lists it under Greeter and, chosen, fills the greeting, which the user can still change. |
| `package/schemas/settings.json` | Its Settings section: the `signature` field. |
| `package/locales/{en,zh}.json` | Its strings, merged under `ext['com.example.greeter']`. |
| `package/tools/greet.json` | An MCP tool of its own, listed on the `hanafubuki` endpoint for the built-in Agent and external clients. |
| `package/skills/greet/SKILL.md` | The Agent Skill it contributes: static, read where the package is, discovered while the extension is on. |
| `package/ui/status.html`, `status.js` | A frame in the instance's management: the instance's servers, asked of the backend, and how many greetings were sent, from its UI's state. |
| `package/ui/greetings.json` | A schema panel in Settings: a `Greet` action and a table of the greetings sent, shown from the state the backend pushes (`"source": "state"`). |
| `src/main.rs` | One program, two modes: the backend without arguments, the server with `serve`. |
| `src/backend.rs` | The backend: `provider.validateSpec`, `provider.installPlan`, `provider.launchPlan`, the frame's `status` call, the panel's `greet` action, the tool's `service.greet`, and its UI (`Ui`: `ui.state`, `ui.call`, `Host::emit_state`). |
| `src/server.rs` | The instance's HTTP server: `/` the greeting, `/health` its readiness. |
| `tests/greeter.rs` | The program on its own: the backend over stdio, the server over HTTP. |

## Why the backend provides the type

Greeter's backend reads the saved signature at instance start and builds a
command that runs its own binary (`std::env::current_exe()`) with `serve`.
For a fixed command, a declarative type can also refer to a program or
script inside its package using `{extension.root}`.

What the type does:

1. **Create**: the host checks the values against the type's form, then asks
   `provider.validateSpec`, which refuses a greeting over 200 characters.
2. **Install**: `provider.installPlan` answers one `write-file` step,
   `{component.core}/greeting.txt` from `{param.greeting}`. The host
   resolves the placeholders and keeps the step inside `core`.
3. **Start**: `provider.launchPlan` answers
   `[<the program>, "serve", "--port", "{port}", "--signature", <setting>]`.
   The plan is a template, so the backend doubles every brace in text it did
   not write. The host starts it in `core` on the port it allocated and opens
   the role in the embedded browser once `/health` answers.
4. **The frame**: `ui/status.html` calls `status`, which the backend answers
   with `servers.status` for the instance (it needs
   `permissions.instances = "own-types"`).

## Its UI's state

The backend has a UI in the owner protocol (`Handler::ui` returns its `Ui`,
so it announces the hook `ui`). Its state is
`{ "greetings": { "rows": [{ "to": …, "text": … }] } }`, the last 20
greetings sent. **Settings > Greetings** (`ui/greetings.json`) has a table
whose block names `"source": "state"` and `"path": "greetings"`: the
application renders it from that state, read when the section opens and
followed as the backend pushes it, and never asks `ui.panel.query` for it.
Pressing **Greet** sends `ui.panel.action`; the backend keeps the greeting,
pushes the new state with `host.emit_state`, and the table changes. The
frame follows the same state with `state()` and `onState()`.

## Its tool and its Skill

`mcpToolsFiles = "tools/*.json"` gives the extension a management tool of
its own without writing it in the manifest; a file holds one tool or an
array of them, and a tool may keep its schema in a file it names with
`inputSchemaFile`. The endpoint lists `ext_com_example_greeter__greet`
while the extension is on. A client's call arrives at the backend as
`service.greet` with the arguments the schema describes, and the backend
answers it as its panel's action does. A backend may also publish tools
while it runs (`Host::register_tools`, `Host::unregister_tools`), and its
own replaces the manifest's of the same name.

`agent.skills` contributes a Skill to the built-in Agent: `skills/greet`
holds a `SKILL.md` whose frontmatter says when it applies, and the
generated Agent package carries it as it is. Skills are static — the host
writes what the package declares and Agent discovers it, and nothing
changes it at run time.

## Build and install

Build the program for this operating system:

```sh
cargo build --release
```

`target/release/greeter` (`greeter.exe` on Windows) is the backend and the
instance's server both. The package is `package/`: copy the program to
`package/bin/`, then pack the contents of `package/` so that
`hanafubuki-extension.toml` sits at the archive's root or inside its one
directory. In the repository this is `bun run example:extension`, which
writes a folder and an archive under `dist/` (ignored by Git).

In Hanafubuki, open **Settings > Extensions**, install the folder or the
archive, confirm what it asks for, and turn Greeter on. Then create an
instance of the **Greeter** type, install it and start it. The **Greeter
status** section of its management shows its server; **Settings > Greeter**
sets the signature, and **Settings > Greetings** greets and lists what was
sent.

Build a matching binary and put it at the path `[backend].command` names for
each other OS and architecture you support.

## Test

```sh
cargo test
```

runs `tests/greeter.rs`: the backend's answers over its stdio, and the server
on a free port. The application's suite installs and runs the whole package
(`src-tauri/src/api_server/declared/tests/greeter.rs`): installed through the
store from a folder, its backend started, an instance created, installed and
started, its page and its frame checked, its panel's action pushing its
state, then stopped and uninstalled; `src-tauri/src/extensions/tests/greeter.rs`
mounts it as the application does and reads its panel's table through the
row's `<id>.panels`, before and after that push.

## Copying it out

1. Copy this directory into a new repository, or use it as one.
2. Replace `com.example.greeter` everywhere (the manifest's `id`, the
   message keys in `types/` and `schemas/`) with an id of your own, and
   build the package with a script of your own in place of
   `bun run example:extension`: the program in `bin/`, beside the files of
   `package/`.

`Cargo.toml` depends on the SDK by path. In a repository of its own, keep
the `vendor/` directory that the documentation site's download unpacks —
`vendor/hanafubuki-extension-sdk` and `vendor/hanafubuki-extension-protocol`
— and drop the `workspace` line, which only applies here. The SDK is not
published on crates.io.
