---
name: greeter
description: Use when the user wants Hanafubuki's Greeter extension to greet someone, or asks what greetings it has sent.
---

# Greeter

Greeter is the sample extension of Hanafubuki: an instance type whose page
shows a greeting it serves itself.

## Greeting someone

Call the extension's own MCP tool, `greet`, with the person's name. The
tool is listed on the `hanafubuki` MCP endpoint as
`ext_com_example_greeter__greet` while the extension is on.

## Reading what it sent

The greetings sent are this extension's own UI state, which its Settings
section (**Greetings**) shows. Its page, in the instance, says who this
instance greets and with which signature; the instance's management frame
reads its servers.
