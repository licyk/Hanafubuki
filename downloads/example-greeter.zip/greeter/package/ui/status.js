// The frame asks the extension's backend for the instance's servers
// (`ui.frame.call` with method `status`, answered in src/backend.rs), and
// follows its UI's state (`state()` and `onState()`): how many greetings
// its Settings panel sent. It has no network of its own: everything goes
// through the frame client. Its "Change greeting" button opens the
// extension's `dialogs` frame (`openDialog`), which answers with the choice.
import { call, onState, openDialog, ready, state } from "../__hanafubuki/frame.js";

const list = document.getElementById("servers");
const message = document.getElementById("message");
const greetings = document.getElementById("greetings");
const picked = document.getElementById("picked");

async function pick() {
  picked.textContent = "";
  try {
    const choice = await openDialog("pick");
    picked.textContent = choice ? `Greeting: ${choice.greeting}` : "Kept as it was.";
  } catch (error) {
    picked.textContent = `${error.kind}: ${error.message}`;
  }
}

function showGreetings(ui) {
  greetings.textContent = `Greetings sent: ${ui.greetings.rows.length}`;
}

async function refresh() {
  message.textContent = "";
  try {
    const { servers } = await call("status");
    list.replaceChildren(...servers.map(row));
    if (servers.length === 0) message.textContent = "Not started yet.";
  } catch (error) {
    list.replaceChildren();
    message.textContent = `${error.kind}: ${error.message}`;
  }
}

function row(server) {
  const item = document.createElement("li");
  const role = document.createElement("span");
  role.className = "role";
  role.textContent = server.role;
  const detail = document.createElement("span");
  detail.className = "detail";
  detail.textContent = server.endpoint ? `${server.status} · ${server.endpoint}` : server.status;
  item.append(role, detail);
  return item;
}

document.getElementById("refresh").addEventListener("click", refresh);
document.getElementById("pick").addEventListener("click", pick);
onState(showGreetings);
ready();
refresh();
state().then(showGreetings, () => {});
