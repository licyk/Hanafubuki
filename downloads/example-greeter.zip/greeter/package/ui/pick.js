// A dialogs frame: it lists a few greetings and closes its dialog with the
// one the user chose, which the opener's `openDialog` resolves with.
import { closeDialog, ready } from "../__hanafubuki/frame.js";

const CHOICES = ["Hello", "Hi", "Hey"];

const list = document.getElementById("choices");
for (const choice of CHOICES) {
  const item = document.createElement("li");
  item.textContent = choice;
  item.addEventListener("click", () => closeDialog({ greeting: choice }));
  list.append(item);
}

ready();
