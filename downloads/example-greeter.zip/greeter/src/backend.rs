//! The extension's backend. It provides the `greeter` instance type
//! (`package/types/greeter.toml`, `provider = "backend"`): it checks an
//! instance's values, plans its install and plans its `ui` server as this
//! same program serving HTTP. It also answers the calls of its frame
//! (`package/ui/status.html`), and has a UI in the owner protocol: the
//! greetings sent from its Settings panel (`package/ui/greetings.json`),
//! whose table follows the state it pushes instead of being queried. Its MCP
//! tool (`package/tools/greet.json`) is reached as `service.greet`, the
//! method a management client's call of that tool becomes.

use std::sync::Mutex;

use hanafubuki_extension_sdk::protocol::{
    method, FrameCallParams, LaunchOptionsParams, LaunchPreflightParams, PanelActionParams,
    PanelContext, RpcError, ServersResult, ServersStatusParams, SettingsResult, ValidateSpecParams,
};
use hanafubuki_extension_sdk::{Handler, Host, Ui};
use serde_json::{json, Value};

/// The longest greeting the page shows, in characters.
const MAX_GREETING: usize = 200;
/// How many sent greetings its UI keeps, the last ones.
const KEPT_GREETINGS: usize = 20;

#[derive(Default)]
pub struct Greeter {
    /// The greetings sent, each `{to, text}`, the newest last.
    greetings: Mutex<Vec<Value>>,
}

impl Handler for Greeter {
    fn ui(&self) -> Option<&dyn Ui> {
        Some(self)
    }

    fn request(&self, host: &Host, method: &str, params: Value) -> Result<Value, RpcError> {
        match method {
            method::PROVIDER_VALIDATE_SPEC => validate_spec(params),
            method::PROVIDER_INSTALL_PLAN => Ok(install_plan()),
            method::PROVIDER_LAUNCH_PREFLIGHT => check_greeting(params),
            method::PROVIDER_LAUNCH_PLAN => launch_plan(host),
            method::PROVIDER_LAUNCH_OPTIONS => greeting_files(params),
            method::UI_FRAME_CALL => frame_call(host, params),
            method::UI_PANEL_ACTION => self.panel_action(host, params),
            "service.greet" => self.service_greet(host, params),
            _ => Err(RpcError::method_not_found(method)),
        }
    }
}

/// Its UI's state is `{greetings: {rows}}`: the `greetings` path of the
/// panel's table, written as a query of a table answers.
impl Ui for Greeter {
    fn state(&self, _host: &Host, _context: &PanelContext) -> Result<Value, RpcError> {
        Ok(self.ui_state())
    }

    /// `greet` with `{to}`, as the panel's action sends it.
    fn call(
        &self,
        host: &Host,
        action: &str,
        args: Value,
        _context: &PanelContext,
    ) -> Result<Value, RpcError> {
        match action {
            "greet" => Ok(json!({ "text": self.greet(host, &args)? })),
            other => Err(RpcError::invalid_params(format!("no action `{other}`"))),
        }
    }
}

impl Greeter {
    fn ui_state(&self) -> Value {
        let greetings = self
            .greetings
            .lock()
            .unwrap_or_else(|poisoned| poisoned.into_inner());
        json!({ "greetings": { "rows": *greetings } })
    }

    /// Its panel's `greet`: the greeting, kept and pushed to every window
    /// showing its UI.
    fn panel_action(&self, host: &Host, params: Value) -> Result<Value, RpcError> {
        let params: PanelActionParams =
            serde_json::from_value(params).map_err(RpcError::invalid_params)?;
        match params.action.as_str() {
            "greet" => Ok(json!({ "notice": self.greet(host, &Value::Object(params.values))? })),
            other => Err(RpcError::invalid_params(format!("no action `{other}`"))),
        }
    }

    /// The `greet` tool: its arguments are the schema's, which the host has
    /// already held the client to, so `person` is text here.
    fn service_greet(&self, host: &Host, params: Value) -> Result<Value, RpcError> {
        let person = params
            .get("person")
            .and_then(Value::as_str)
            .map(str::trim)
            .filter(|person| !person.is_empty())
            .ok_or_else(|| RpcError::invalid_params("`person` is required"))?;
        Ok(json!({ "text": self.greet(host, &json!({ "to": person }))? }))
    }

    fn greet(&self, host: &Host, values: &Value) -> Result<String, RpcError> {
        let to = match values.get("to").and_then(Value::as_str).map(str::trim) {
            Some(to) if !to.is_empty() => to.to_string(),
            _ => "world".to_string(),
        };
        let text = format!("Hello, {to}!");
        {
            let mut greetings = self
                .greetings
                .lock()
                .unwrap_or_else(|poisoned| poisoned.into_inner());
            greetings.push(json!({ "to": to, "text": text }));
            let over = greetings.len().saturating_sub(KEPT_GREETINGS);
            greetings.drain(..over);
        }
        host.emit_state(self.ui_state())
            .map_err(|error| RpcError::failed(format!("push its state: {error}")))?;
        Ok(text)
    }
}

/// The host has already read the values against the type's form, so the
/// greeting is text; what is left is the backend's own rule.
fn validate_spec(params: Value) -> Result<Value, RpcError> {
    let params: ValidateSpecParams =
        serde_json::from_value(params).map_err(RpcError::invalid_params)?;
    let greeting = params
        .values
        .get("greeting")
        .and_then(Value::as_str)
        .unwrap_or_default();
    let mut issues = serde_json::Map::new();
    if greeting.chars().count() > MAX_GREETING {
        issues.insert(
            "greeting".to_string(),
            format!("at most {MAX_GREETING} characters").into(),
        );
    }
    Ok(json!({ "issues": issues }))
}

/// The same plan for a first install and a reinstall: the host resolves the
/// placeholders and confines the step to the `core` component.
fn install_plan() -> Value {
    json!({ "steps": [{
        "kind": "write-file",
        "title": { "en": "Write greeting file", "zh": "写入问候语文件" },
        "path": "{component.core}/greeting.txt",
        "content": "{param.greeting}",
    }] })
}

/// The `ui` role runs this program from the installed package; the host
/// starts it in the instance's `core` component, where the greeting is.
fn launch_plan(host: &Host) -> Result<Value, RpcError> {
    let program = std::env::current_exe()
        .map_err(|error| RpcError::failed(format!("its own path: {error}")))?;
    let mut argv = vec![
        literal(&program.to_string_lossy()),
        "serve".to_string(),
        "--port".to_string(),
        "{port}".to_string(),
        "--greeting-file".to_string(),
        "{launch.greetingFile}".to_string(),
    ];
    let settings: SettingsResult = host.call_as(method::SETTINGS_GET, &json!({}))?;
    if let Some(signature) = settings.values.get("signature").and_then(Value::as_str) {
        argv.extend(["--signature".to_string(), literal(signature)]);
    }
    Ok(json!({ "argv": argv, "env": {} }))
}

fn check_greeting(params: Value) -> Result<Value, RpcError> {
    let params: LaunchPreflightParams =
        serde_json::from_value(params).map_err(RpcError::invalid_params)?;
    let core = params
        .instance
        .components
        .get("core")
        .ok_or_else(|| RpcError::invalid_params("missing core component"))?;
    let file = params
        .launch_values
        .get("greetingFile")
        .and_then(Value::as_str)
        .ok_or_else(|| RpcError::invalid_params("missing greeting file"))?;
    if !std::path::Path::new(&core.path).join(file).is_file() {
        return Err(RpcError::failed(format!("Greeting file {file} is missing")));
    }
    Ok(json!({}))
}

fn greeting_files(params: Value) -> Result<Value, RpcError> {
    let params: LaunchOptionsParams =
        serde_json::from_value(params).map_err(RpcError::invalid_params)?;
    let core = params
        .instance
        .components
        .get("core")
        .ok_or_else(|| RpcError::invalid_params("missing core component"))?;
    let io_error = |error: std::io::Error| RpcError::failed(error.to_string());
    let mut files = Vec::new();
    for entry in std::fs::read_dir(&core.path).map_err(io_error)? {
        let entry = entry.map_err(io_error)?;
        let name = entry.file_name();
        if let Some(file) = name.to_str().filter(|name| name.ends_with(".txt")) {
            if entry.file_type().map_err(io_error)?.is_file() {
                files.push(file.to_owned());
            }
        }
    }
    files.sort();
    Ok(json!({ "options": { "greetingFiles": files } }))
}

/// The frame's `status`: the server roles of the instance it is shown for.
fn frame_call(host: &Host, params: Value) -> Result<Value, RpcError> {
    let params: FrameCallParams =
        serde_json::from_value(params).map_err(RpcError::invalid_params)?;
    match params.method.as_str() {
        "status" => {
            let servers: ServersResult = host.call_as(
                method::SERVERS_STATUS,
                &ServersStatusParams {
                    instance_id: params.context.instance_id,
                },
            )?;
            Ok(json!({ "servers": servers.servers }))
        }
        other => Err(RpcError::method_not_found(other)),
    }
}

/// `text` as a plan's argument: a plan is a template, so its braces would
/// read as placeholders.
fn literal(text: &str) -> String {
    text.replace('{', "{{").replace('}', "}}")
}
