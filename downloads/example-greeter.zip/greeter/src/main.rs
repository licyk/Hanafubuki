//! The Greeter extension's one program. Started by the application without
//! arguments, it is the extension's backend and speaks the protocol on its
//! stdin and stdout; planned by that backend as an instance's `ui` server,
//! `greeter serve --port <port> --signature <text>` serves the instance's
//! page over HTTP.

mod backend;
mod server;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let outcome = match args.first().map(String::as_str) {
        None => hanafubuki_extension_sdk::run(backend::Greeter::default()),
        Some("serve") => server::serve(&args[1..]),
        Some(other) => Err(format!("unknown command `{other}`")),
    };
    if let Err(error) = outcome {
        // Stderr is the extension's log as a backend, and the server's
        // output as a role.
        eprintln!("greeter: {error}");
        std::process::exit(1);
    }
}
