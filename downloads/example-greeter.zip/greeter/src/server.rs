//! The instance's `ui` server: `/` is the greeting page, `/health` the
//! readiness the type declares. It runs in the instance's `core` component,
//! where the install wrote `greeting.txt`.

use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::sync::Arc;

struct Page {
    greeting: String,
    signature: Option<String>,
}

/// `--port <port> [--greeting-file <name>] [--signature <text>]`.
pub fn serve(args: &[String]) -> Result<(), String> {
    let flag = |name: &str| {
        args.iter()
            .position(|arg| arg == name)
            .and_then(|at| args.get(at + 1))
    };
    let port: u16 = flag("--port")
        .ok_or("serve needs --port")?
        .parse()
        .map_err(|error| format!("--port: {error}"))?;
    let file = flag("--greeting-file").map_or("greeting.txt", String::as_str);
    if std::path::Path::new(file).file_name() != Some(std::ffi::OsStr::new(file))
        || !file.ends_with(".txt")
    {
        return Err("--greeting-file expects the name of a .txt file".into());
    }
    let greeting =
        std::fs::read_to_string(file).map_err(|error| format!("read {file}: {error}"))?;
    let page = Arc::new(Page {
        greeting: greeting.trim().to_string(),
        signature: flag("--signature").cloned(),
    });
    let listener = TcpListener::bind(("127.0.0.1", port))
        .map_err(|error| format!("listen on port {port}: {error}"))?;
    eprintln!("greeter serving on http://127.0.0.1:{port}/");
    for stream in listener.incoming().flatten() {
        let page = page.clone();
        std::thread::spawn(move || answer(stream, &page));
    }
    Ok(())
}

fn answer(mut stream: TcpStream, page: &Page) {
    let (status, content_type, body) = match request_path(&mut stream).as_deref() {
        Some("/health") => ("200 OK", "text/plain", "ok".to_string()),
        Some("/") => ("200 OK", "text/html; charset=utf-8", page.html()),
        _ => ("404 Not Found", "text/plain", "not found".to_string()),
    };
    let head = format!(
        "HTTP/1.1 {status}\r\nContent-Type: {content_type}\r\nContent-Length: {}\r\n\
         Connection: close\r\n\r\n",
        body.len()
    );
    let _ = stream.write_all(head.as_bytes());
    let _ = stream.write_all(body.as_bytes());
}

/// The path of the request line, once the head has arrived.
fn request_path(stream: &mut TcpStream) -> Option<String> {
    let mut head = Vec::new();
    let mut buffer = [0_u8; 1024];
    while !head.windows(4).any(|end| end == b"\r\n\r\n") && head.len() < 16 * 1024 {
        match stream.read(&mut buffer) {
            Ok(0) | Err(_) => break,
            Ok(read) => head.extend_from_slice(&buffer[..read]),
        }
    }
    let line = String::from_utf8_lossy(&head);
    let target = line.split_whitespace().nth(1)?;
    Some(target.split('?').next().unwrap_or(target).to_string())
}

impl Page {
    fn html(&self) -> String {
        let signature = self
            .signature
            .as_deref()
            .map(|text| format!("<p class=\"signature\">{}</p>", escape(text)))
            .unwrap_or_default();
        format!(
            "<!doctype html>\n<html><head><meta charset=\"utf-8\"><title>Greeter</title>\
             <style>body{{font-family:system-ui,sans-serif;display:grid;place-content:center;\
             min-height:90vh;text-align:center}}.signature{{opacity:.6}}</style></head>\
             <body><h1>{}</h1>{signature}</body></html>\n",
            escape(&self.greeting)
        )
    }
}

fn escape(text: &str) -> String {
    text.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}
