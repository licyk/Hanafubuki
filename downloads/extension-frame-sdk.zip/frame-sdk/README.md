# Hanafubuki frame typings

TypeScript declarations for what a frame page imports at run time. Nothing here
is shipped in an extension: the application serves the code and the styles at
`__hanafubuki/` of every package's root.

| File | Types |
| --- | --- |
| `sdk/frame/frame.d.ts` | the frame client, `__hanafubuki/frame.js`: `ready`, `call`, `on`, `state`, `onState`, `getSettings`, `patchSettings`, `openSettings`, `openExternal`, `pickDirectory`, `updateInstance`, `navigateInstance`, `locale`, `onLocale` |
| `sdk/ui/ui.d.ts` | the component bundle, `__hanafubuki/ui.js`: every component of UI API 1 with its props, events and slots, `frameUi`, and the motion helpers |

`ui.d.ts` is generated from the bundle's sources by `bun run
export:frontend-interfaces` in the application's repository, and it imports its
Vue types from `vue`; resolve those to the Vue version the application serves
beside the bundle at `__hanafubuki/vue.js`.

## Referring to them

A page imports the runtime by a relative URL, which `paths` does not resolve:
it names those two URLs in a declaration of its own, and maps the names that
declaration re-exports. Both halves are needed.

```ts title="types/hanafubuki.d.ts"
declare module "*/__hanafubuki/frame.js" {
  export * from "@hanafubuki/frame-types";
}
declare module "*/__hanafubuki/ui.js" {
  export * from "@hanafubuki/ui-types";
}
```

```json title="tsconfig.json"
{
  "compilerOptions": {
    "paths": {
      "@hanafubuki/frame-types": ["./frame-sdk/sdk/frame/frame.d.ts"],
      "@hanafubuki/ui-types": ["./frame-sdk/sdk/ui/ui.d.ts"],
      "vue": ["./node_modules/vue"]
    }
  },
  "include": ["ui/*.js", "types/*.d.ts"]
}
```

Name only the specifiers the page uses if you prefer. Either way, do not write
your own typings: these follow the version of the application you target, and
`engines.hanafubuki` is how you name it.
