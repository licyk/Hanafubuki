# ComfyUI from a repository

A sample instance type that adopts a built-in type's management
([instance-types.md](../../../docs/rules/instance-types.md#adopting-a-built-in-types-management)).
It has no backend: `types/comfyui-fork.toml` is the whole type.

An instance clones the repository you name into its `core`, prepares its
own Python, installs the repository's requirements, and starts `main.py`.
Its descriptor says

```toml
[management]
adopts = "builtin:comfyui"
operations = ["update", "terminal", "versions", "extensions", "models", "environment", "pytorch"]
```

so the instance's management page lists, beside what every instance has:

- **Versions:** the checkout's status, branches and commits, and switching
  between them. It has no Update button: the type's own `update` (Maintenance)
  is its update.
- **Extensions:** the custom nodes in `core/custom_nodes`.
- **Models:** the files in `core/models`, and ComfyUI's model library.
- **Environment:** the environment report for the instance’s Python.
- **PyTorch:** the catalog and the reinstall, into the instance's Python.

Snapshots, the hotpatch, launch arguments, branch variants and the kernel
update stay the built-in types' and are refused for it.

The Launch section lets the user edit the listen address for the next service start. Overview initially includes a shortcut to the instance’s output folder.

## What adopting asserts

The application addresses the instance's `core` as a ComfyUI installation.
That holds for ComfyUI and for a fork that keeps its layout. For another
program:

- Versions only needs `core` to be a Git checkout, and PyTorch only the
  instance's own Python, so a type may adopt for those two alone.
- Extensions and Models act on the adopted type's folders under `core`. In
  a checkout without them they list nothing, or create an empty `models`.

Adopting needs a Python runtime, the `control` role, and a `core` that is
the instance's own (not `external = "allowed"`).

## Trying it

Install the folder as a development link (Settings → Extensions → Install →
Link a folder), turn it on, and create an instance of "ComfyUI (from a
repository)". Installing downloads ComfyUI's requirements, PyTorch among
them.
