# Frame components

The acceptance page of the frame component bundle
([extensions.md](../../../docs/rules/extensions.md#frames),
[extension-protocol.md](../../../docs/extension-protocol.md#the-component-bundle)):
an extension's sandboxed frame running the application's own Vue
components, loaded from the host.

The host serves the bundle under `__hanafubuki/`, beside the frame client
and the UI kit: `vue.js` (Vue's runtime), `ui.js` (the components, built
from `src/ui` by `bun run prepare:assets`) and `ui-components.css` (their
styles). This extension has no backend. Its page, `ui/index.html`, is shown
twice: as a Settings section, where the frame follows the page's height,
and as a page of its own, which takes the height its host gives it.

The page has no static import, so it reports even when a module fails to
load. It loads the files by relative URL, mounts three Vue apps on the one
runtime, each with `frameUi(frame, { openLink })`, and writes into its
**Report** box, newest first:

- each load and mount, every error, Vue warning and CSP violation, the
  language the host sends, and whether the frame has a clipboard;
- what each component of the gallery was asked to do (a row selected, a
  menu item chosen, a card dismissed, a link handed to the page);
- each menu opening and closing (its trigger's `aria-expanded`), each
  listbox, menu, tooltip and dialog (the colour picker's) shown or gone, and
  where it appeared (`clipped` when it went past the frame's edge);
- everything inside the frame that could close a menu: window `resize`
  (with its size), `scroll` (capture, with its target), window `blur` and
  `focus`, `visibilitychange`, `pointerdown`, `focusin` and `focusout`
  (with their targets), each Escape with whether a component prevented it,
  and each height the frame client reports to the host;
- each line with its time since the page started and, once a menu has
  opened, since the last one did (`menu+…ms`).

The box has a fixed height and never scrolls itself: a page that grows
resizes an auto-height frame, and any scroll in the frame hides a tooltip
and closes a context menu.

The top and bottom apps hold the overlays at the frame's edges. The third,
`ui/gallery.js`, is the rest of the bundle, a tab per group, each in a box
of a fixed height for the same reason:

| Tab | Components |
| --- | --- |
| Structure | `PanelHeader` (with `InfoTooltip`, `UpdateHint`, a `StatusBadge`), `SettingsGroup`, `SettingsRow`, `SettingsSwitch`, `BaseCollapsible` |
| Lists and menus | `NavList` (a hover-revealed action per row), `ContextMenu`, `BaseColorPickerPopover`, `RemovableTokenGroups` |
| Status | `AsyncRegion` with `LoadingState` and `EmptyState`, `IconSwap`, `ToolbarSlot`, `InfoBarDetails`, `CornerStatusStack` |
| Forms and text | `SchemaFormFields`, `SchemaFieldControl`, `MarkdownDocument` |

`NativeTooltipHost` is mounted once, by the gallery: every `title` in the
page (the **Native title** button, the rows' actions) is drawn as the
application's bubble.

## Running it

1. Run `bun run tauri dev`.
2. Open **Settings > Extensions > Install extension**, choose **Linked
   folder**, and pick this folder (`examples/extensions/frame-components`).
   Confirm, then turn it on.
3. Open its section in Settings, **Frame components**:
   - hover **Hover: tooltip** and rest there;
   - open **Top dropdown** and pick an option (the first three are the
     application's own strings, in its language);
   - open **Bottom dropdown** at the frame's bottom edge and pick an option;
   - open the tabs' **More tabs** menu and pick a tab;
   - press **Browse** beside **Folder** and pick a folder;
   - Tab to a dropdown and use the arrow keys, Enter and Escape.
4. Go through the gallery's four tabs:
   - **Structure:** hover the help button beside the panel's title and the
     update marker; turn the switch off (the row below greys, On becomes
     Off, in the application's language); open and close the collapsible
     (it expands, the box does not grow).
   - **Lists and menus:** move through the rows with the arrow keys (the
     pill follows); hover a row and press its × (the row closes in place);
     right-click a row and choose an item, with the mouse and with the
     keys; open the colour picker, drag, type a hex value, press Escape;
     remove both token groups (the bar closes) and add one again.
   - **Status:** each **Load** button (spinner, then a fade to the content,
     the empty state or the error); the copy button (the glyph cross-fades);
     **Bring a control in** (the row makes room, the control rises);
     **Details** under the error; then the corner cards: add one of each
     kind (they slide in from the side; a success leaves by itself, a
     failure stays), dismiss one (the others glide), add five (they fold
     into "+N more").
   - **Forms and text:** edit the fields (turning **Cache** on enables the
     folder; **Exact** shows Notes; the values print below); choose each of
     the tri-state's three; click the Markdown's link (the Report says the
     page was handed the address, and nothing navigates) and **Copy** on
     its code (it becomes "Copied" if the frame may write the clipboard;
     if it stays, the Report's `clipboard` line says why).
5. Hover **Native title** in the top app: the application's bubble, not
   the system's.
6. Switch the application's language and theme: the labels and the
   components follow.
7. Do the same on its page, **Frame components**, which the title bar lists.

Send back the text of the Report box, and anything that did not open,
closed by itself, did not move as the application's own does, looked
unlike it, or was cut off by the frame's edge.

## Motion examples and generated documentation

`ui/examples/*.js` are executable modules mounted by `ui/motion-gallery.js`
beside the existing component gallery. Each module exports literal `example`
metadata and `createExample(vue, ui, note)`. The host supplies Vue and the public
UI bundle; these examples have no backend or Tauri access. The interface
exporter reads the metadata and the complete source into `examples.json`, and
the website displays that source directly.

From the repository root:

```sh
bun run export:frontend-interfaces
bun run example:frame:check
bun run example:frame:build
bun run test:frontend -- sdk/ui/examples.test.ts
```

The strict JavaScript type check consumes the generated `sdk/ui/ui.d.ts`.
The build bundles the same modules into a temporary browser artifact and removes
it afterwards; the linked extension runs the original browser-native modules.
Tests mount these exact modules with real Vue and public helpers in happy-dom,
click their controls, exercise reduced motion and unmount cleanup. Geometry and
Web Animations handles are mechanical substitutes because happy-dom does not
render layout or animations. These tests do not prove visual smoothness, native
WebView behavior or desktop acceptance. To inspect that, link this folder in the
application and interact with the examples in both page and settings placement.

Manual host acceptance (requires a desktop session):

1. Install this directory as a development link, enable it, then open both its
   application page and its Settings section. Confirm the Report has no module
   load, Vue or CSP failures.
2. Change light/dark appearance, accent and surface opacity in the host. The
   theme inspector should report the new inherited values. Toggle the local
   swatch override and confirm it affects only the swatch, not the host.
3. Toggle the operating system's reduced-motion preference, reverse the list,
   select a row, swap the panel and expand/collapse details. New content and
   selection must remain usable; movement should honor the preference.
4. Close/reopen or reload the frame during a swap or reorder. Confirm the new
   view has no stuck pinned height or old indicator animation, and the Report
   continues without errors. Check keyboard focus rings are not clipped while
   the panel is at rest.

The automated checks do not replace these desktop observations.
