// The acceptance page of the frame component bundle (docs/rules/extensions.md,
// Frames). It has no static import, so it runs and reports even when a host
// module fails: it records errors and policy violations, then loads the frame
// client, the Vue runtime and the component bundle from `__hanafubuki/` by
// relative URL, mounts three apps on the one runtime (the third is the rest of
// the bundle's components, `gallery.js`), and logs everything that opens,
// closes or could close a menu (useAnchoredPopover dismisses on an
// outside press, Escape, Tab, the window's blur, an ancestor's scroll and a
// window resize), each line with its time since the page started and, once
// a menu has opened, since the last one did.

const lines = [];
const report = document.getElementById("report");
const started = performance.now();
let menuOpenedAt = null;

function note(status, text) {
  const now = performance.now();
  const since = `t=${Math.round(now - started)}ms`;
  const menu = menuOpenedAt === null ? "" : ` menu+${Math.round(now - menuOpenedAt)}ms`;
  const last = lines.at(-1);
  // A run of the same event (a scroll, mostly) is one line with its count and last time.
  if (last && last.status === status && last.text === text) {
    last.count += 1;
    last.time = `${since}${menu}`;
  } else {
    lines.push({ status, text, time: `${since}${menu}`, count: 1 });
  }
  // Newest first, so the report never scrolls itself: any scroll in the
  // frame hides a tooltip and closes a context menu.
  report.textContent = lines
    .toReversed()
    .map(
      (line) =>
        `[${line.status}] ${line.time} ${line.text}${line.count > 1 ? ` (x${line.count})` : ""}`,
    )
    .join("\n");
}

document.getElementById("clear").addEventListener("click", () => {
  lines.length = 0;
  report.textContent = "";
});

window.addEventListener("error", (event) => {
  note("error", `${event.message} (${event.filename}:${event.lineno})`);
});
window.addEventListener("unhandledrejection", (event) => {
  note("error", `unhandled rejection: ${event.reason}`);
});
document.addEventListener("securitypolicyviolation", (event) => {
  note("csp", `${event.violatedDirective} blocked ${event.blockedURI || "(inline)"}`);
});

note("info", `page ${location.href}`);
note("info", `origin ${String(self.origin)}; agent ${navigator.userAgent}`);
const css = document.getElementById("components-css");
note(css.sheet ? "ok" : "fail", `ui-components.css ${css.sheet ? "applied" : "not applied"}`);
// A Markdown document's Copy writes here; a sandboxed frame may have none, or be refused.
note("info", `clipboard ${navigator.clipboard ? "present" : "absent"}`);
watchDismissTriggers();

async function load(label, url) {
  try {
    const module = await import(url);
    note("ok", `${label} loaded`);
    return module;
  } catch (error) {
    note("fail", `${label} did not load: ${error}`);
    return null;
  }
}

const frame = await load("frame.js", "../__hanafubuki/frame.js");
const vue = await load("vue.js", "../__hanafubuki/vue.js");
const ui = await load("ui.js", "../__hanafubuki/ui.js");
const more = await load("gallery.js", "./gallery.js");
const motion = await load("motion-gallery.js", "./motion-gallery.js");

if (frame) {
  frame.ready();
  frame.onLocale((locale) => note("info", `locale ${locale}`));
}
if (vue) note("info", `Vue ${vue.version}`);
if (ui) note("info", `UI_API_VERSION ${ui.UI_API_VERSION}`);
if (frame && vue && ui) mount(frame, vue, ui, more, motion);

function mount(frame, vue, ui, more, motion) {
  const { createApp, h, ref } = vue;
  const { BaseDropdown, BaseSwitch, BaseTabs, FormField, InfoBar, PathInput, StatusBadge } = ui;
  const { Tooltip, frameUi, useUiStrings } = ui;

  /** Ten options, the first three labelled with the application's own strings. */
  function options(strings) {
    const named = ["common.state.notSet", "common.state.enabled", "common.state.disabled"];
    return Array.from({ length: 10 }, (_, index) => ({
      value: `v${index + 1}`,
      label: index < named.length ? strings.t(named[index]) : `Option ${index + 1}`,
      alias: index === 0 ? "first" : undefined,
    }));
  }

  const field = (label, control) =>
    h(FormField, { label }, { default: ({ controlId }) => control(controlId) });

  const Top = {
    setup() {
      const strings = useUiStrings();
      const top = ref("v1");
      const tab = ref("t1");
      const folder = ref("");
      const live = ref(true);
      const tabs = Array.from({ length: 12 }, (_, index) => ({
        value: `t${index + 1}`,
        label: `Tab ${index + 1}`,
      }));
      return () =>
        h("div", { class: "page__app" }, [
          h("div", { class: "page__row" }, [
            h(
              Tooltip,
              { text: "A tooltip at the frame's top edge, asked to show above.", placement: "top" },
              {
                default: () =>
                  h(
                    "button",
                    {
                      class: "btn btn-subtle",
                      type: "button",
                      onPointerenter: () => note("event", "pointerenter on the tooltip trigger"),
                    },
                    "Hover: tooltip",
                  ),
              },
            ),
            h(
              "button",
              { class: "btn btn-subtle", type: "button", title: "A native title" },
              "Native title",
            ),
          ]),
          h(InfoBar, {
            severity: "info",
            title: "Components from the host",
            message:
              "Everything below is the application's own components, served at __hanafubuki/ui.js.",
          }),
          h(BaseTabs, {
            label: "Tabs",
            modelValue: tab.value,
            items: tabs,
            "onUpdate:modelValue": (value) => {
              tab.value = value;
              note("ok", `tab ${value} selected`);
            },
          }),
          field("Top dropdown", (id) =>
            h(BaseDropdown, {
              id,
              label: "Top dropdown",
              modelValue: top.value,
              options: options(strings),
              "onUpdate:modelValue": (value) => {
                top.value = value;
                note("ok", `top dropdown chose ${value}`);
              },
            }),
          ),
          field("Folder", (id) =>
            h(PathInput, {
              id,
              modelValue: folder.value,
              browseLabel: strings.t("common.actions.browseDirectory"),
              "onUpdate:modelValue": (value) => {
                folder.value = value ?? "";
              },
              onPicked: (path) => note("ok", `folder picked ${path}`),
            }),
          ),
          field("Live", (id) =>
            h("div", { class: "page__row" }, [
              h(BaseSwitch, {
                id,
                modelValue: live.value,
                "onUpdate:modelValue": (value) => {
                  live.value = value;
                  note("ok", `switch ${value ? "on" : "off"}`);
                },
              }),
              h(StatusBadge, { tone: live.value ? "success" : "neutral", dot: true }, () =>
                strings.t(live.value ? "common.state.enabled" : "common.state.disabled"),
              ),
            ]),
          ),
        ]);
    },
  };
  const Bottom = {
    setup() {
      const strings = useUiStrings();
      const bottom = ref(null);
      return () =>
        field("Bottom dropdown", (id) =>
          h(BaseDropdown, {
            id,
            label: "Bottom dropdown",
            modelValue: bottom.value,
            options: options(strings),
            placeholder: "Choose…",
            "onUpdate:modelValue": (value) => {
              bottom.value = value;
              note("ok", `bottom dropdown chose ${value}`);
            },
          }),
        );
    },
  };
  // Apps on one runtime, as an extension's widgets would be.
  const apps = [
    [Top, "#app-top"],
    [Bottom, "#app-bottom"],
  ];
  if (more) apps.push([more.gallery(vue, ui, note), "#app-more"]);
  if (motion) apps.push([motion.motionGallery(vue, ui, note), "#app-motion"]);
  // A frame opens no link itself: the page is handed the address.
  const openLink = (url) => note("ok", `link handed to the page: ${url}`);
  for (const [component, target] of apps) {
    try {
      const app = createApp(component);
      app.use(frameUi(frame, { openLink }));
      app.config.errorHandler = (error, _instance, info) =>
        note("error", `Vue (${info}): ${error}`);
      app.config.warnHandler = (message) => note("warn", `Vue: ${message}`);
      app.mount(target);
      note("ok", `${target} mounted`);
    } catch (error) {
      note("fail", `${target} mount failed: ${error}`);
      return;
    }
  }
  watchOverlays();
}

/** A short name for an event's target. */
function describe(target) {
  if (target === window) return "window";
  if (target === document) return "document";
  if (!(target instanceof Element)) return String(target);
  const id = target.id ? `#${target.id}` : "";
  const classes = [...target.classList]
    .slice(0, 2)
    .map((name) => `.${name}`)
    .join("");
  const role = target.getAttribute("role");
  const name = target.getAttribute("aria-label") ?? target.textContent?.trim().slice(0, 24);
  return `${target.tagName.toLowerCase()}${id}${classes}${role ? `[role=${role}]` : ""}${name ? ` "${name}"` : ""}`;
}

/** Everything inside the frame that could dismiss an open menu, and the height the client reports. */
function watchDismissTriggers() {
  window.addEventListener("resize", () =>
    note("event", `window resize ${innerWidth}x${innerHeight}`),
  );
  window.addEventListener(
    "scroll",
    (event) => note("event", `scroll ${describe(event.target)}`),
    true,
  );
  window.addEventListener("blur", () => note("event", "window blur"));
  window.addEventListener("focus", () => note("event", "window focus"));
  document.addEventListener("visibilitychange", () =>
    note("event", `visibilitychange ${document.visibilityState}`),
  );
  window.addEventListener(
    "pointerdown",
    (event) => note("event", `pointerdown ${describe(event.target)}`),
    true,
  );
  document.addEventListener("focusin", (event) =>
    note("event", `focusin ${describe(event.target)}`),
  );
  document.addEventListener("focusout", (event) =>
    note("event", `focusout ${describe(event.target)}`),
  );
  window.addEventListener(
    "keydown",
    (event) => {
      if (event.key !== "Escape") return;
      // Read once every listener has run: the components prevent it when they use it.
      setTimeout(() => note("event", `Escape keydown defaultPrevented=${event.defaultPrevented}`));
    },
    true,
  );
  // What the frame client sends the host as `resize` (its root's height).
  const root = document.documentElement;
  let reported = null;
  new ResizeObserver(() => {
    const height = Math.ceil(root.getBoundingClientRect().height);
    if (height === reported) return;
    note(
      "event",
      `resize message height ${height}${reported === null ? "" : ` (was ${reported})`}`,
    );
    reported = height;
  }).observe(root);
}

/** Each menu opening and closing (its trigger's `aria-expanded`), and each overlay (a colour picker's dialog too) shown or gone. */
function watchOverlays() {
  const shown = new Set();
  const overlays = '[role="listbox"], [role="menu"], [role="tooltip"], [role="dialog"]';
  const check = () => {
    for (const element of document.body.querySelectorAll(overlays)) {
      if (shown.has(element)) continue;
      const rect = element.getBoundingClientRect();
      if (rect.width === 0 && rect.height === 0) continue;
      shown.add(element);
      const clipped =
        rect.top < 0 || rect.bottom > innerHeight || rect.left < 0 || rect.right > innerWidth;
      const box = `top ${Math.round(rect.top)}, bottom ${Math.round(rect.bottom)}, frame ${innerWidth}x${innerHeight}`;
      note(clipped ? "clipped" : "ok", `${element.getAttribute("role")} shown (${box})`);
    }
    for (const element of shown) {
      if (element.isConnected) continue;
      shown.delete(element);
      note("ok", `${element.getAttribute("role")} gone`);
    }
  };
  new MutationObserver((records) => {
    for (const record of records) {
      if (record.type !== "attributes") continue;
      const expanded = record.target.getAttribute("aria-expanded") === "true";
      if (expanded === (record.oldValue === "true")) continue;
      if (expanded) menuOpenedAt = performance.now();
      note("menu", `${expanded ? "open" : "close"} ${describe(record.target)}`);
    }
    requestAnimationFrame(check);
  }).observe(document.body, {
    childList: true,
    subtree: true,
    attributes: true,
    attributeFilter: ["aria-expanded"],
    attributeOldValue: true,
  });
}
