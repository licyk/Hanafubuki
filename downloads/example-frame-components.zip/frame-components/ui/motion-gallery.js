import * as themeTokens from "./examples/theme-tokens.js";
import * as sizeSwap from "./examples/size-swap.js";
import * as flipList from "./examples/flip-list.js";
import * as deferredExpand from "./examples/deferred-expand.js";

/** @param {typeof import('vue')} vue
 * @param {typeof import('../sdk/ui/ui')} ui
 * @param {(status: string, message: string) => void} note
 */
export function motionGallery(vue, ui, note) {
  const { h } = vue;
  const examples = [themeTokens, sizeSwap, flipList, deferredExpand];
  return {
    setup() {
      const components = examples.map((entry) => entry.createExample(vue, ui, note));
      return () =>
        h("section", { class: "page__app" }, [
          h("h2", "Motion examples / 动效示例"),
          ...examples.map((entry, index) =>
            h("section", { key: entry.example.id }, [
              h("h3", entry.example.title.en),
              h("p", entry.example.description.en),
              h(components[index]),
            ]),
          ),
        ]);
    },
  };
}
