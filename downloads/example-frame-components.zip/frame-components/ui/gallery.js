// The rest of the bundle's components, one group per tab, each in a box of a
// fixed height: a collapsible opening or a region swapping its state must not
// change the page's height, which in an auto-height frame resizes it and
// closes an open menu. `page.js` imports this once the host's modules have
// loaded and mounts what `gallery` returns as an app of its own; every
// interaction writes a line into the Report through `note`.

const MARKDOWN = `### A Markdown document

Text with **strong**, \`code\`, and a [link](https://example.com/docs) that the
page is handed, not the frame navigated to.

<b>Authored HTML</b> is shown as text.

\`\`\`sh
bun run prepare:assets
\`\`\`
`;

const literal = (en, zh) => ({ kind: "literal", text: { en, zh } });

/** A form as Rust would declare it, its texts literal: a frame has only the application's `common` keys. */
const FIELDS = [
  {
    key: "name",
    kind: "text",
    label: literal("Name", "名称"),
    help: literal("Any text.", "任意文本。"),
  },
  {
    key: "mode",
    kind: "select",
    label: literal("Mode", "模式"),
    options: [
      { value: "fast", label: literal("Fast", "快速") },
      { value: "exact", label: literal("Exact", "精确") },
    ],
  },
  { key: "steps", kind: "slider", label: literal("Steps", "步数"), min: 1, max: 50, step: 1 },
  { key: "cache", kind: "boolean", label: literal("Cache", "缓存") },
  {
    key: "cacheDir",
    kind: "path",
    pathKind: "directory",
    label: literal("Cache folder", "缓存目录"),
    disabledWhen: { key: "cache", equals: false },
    disabledReason: literal("Turn Cache on first.", "请先打开缓存。"),
  },
  {
    key: "notes",
    kind: "textarea",
    label: literal("Notes", "备注"),
    visibleWhen: { key: "mode", equals: "exact" },
  },
];

export function gallery(vue, ui, note) {
  const { h, reactive, ref } = vue;
  const strings = () => ui.useUiStrings();

  /** A glyph of the page's own: the bundle exports no icons. */
  const glyph = (path) => (props) =>
    h(
      "svg",
      {
        width: props.size ?? 16,
        height: props.size ?? 16,
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        "stroke-width": 2,
        "stroke-linecap": "round",
        "stroke-linejoin": "round",
        "aria-hidden": "true",
      },
      [h("path", { d: path })],
    );
  const Check = glyph("M20 6 9 17l-5-5");
  const Copy = glyph("M8 8h12v12H8zM4 16V4h12");
  const Box = glyph("M3 7l9-4 9 4v10l-9 4-9-4zM3 7l9 4 9-4M12 11v10");

  const demo = (title, content) =>
    h("section", { class: "gallery__demo" }, [
      h("h4", { class: "gallery__title" }, title),
      content,
    ]);

  const Structure = {
    setup() {
      const open = ref(false);
      const on = ref(true);
      const name = ref("");
      return () => [
        demo(
          "PanelHeader, InfoTooltip, UpdateHint",
          h(
            ui.PanelHeader,
            {
              title: "A panel",
              description: "Its description, collapsed into the help button beside the title.",
              descriptionAsHelp: true,
              icon: Box,
            },
            {
              status: () => h(ui.StatusBadge, { tone: "success", dot: true }, () => "Ready"),
              help: () =>
                h(ui.UpdateHint, {
                  text: "An update is available: Update applies it.",
                  label: "Update available",
                }),
              actions: () => [
                h(ui.InfoTooltip, { text: "Help text at the help width, on hover and on focus." }),
                h(
                  "button",
                  {
                    class: "btn btn-sm",
                    type: "button",
                    onClick: () => note("ok", "panel action"),
                  },
                  "Action",
                ),
              ],
            },
          ),
        ),
        demo(
          "SettingsGroup, SettingsRow, SettingsSwitch",
          h(ui.SettingsGroup, { title: "A group of settings" }, () => [
            h(
              ui.SettingsRow,
              {
                title: "A switch",
                description: "On and Off are the application's words.",
                icon: Box,
                controlId: "gallery-switch",
              },
              () =>
                h(ui.SettingsSwitch, {
                  id: "gallery-switch",
                  modelValue: on.value,
                  "onUpdate:modelValue": (value) => {
                    on.value = value;
                    note("ok", `settings switch ${value ? "on" : "off"}`);
                  },
                }),
            ),
            h(
              ui.SettingsRow,
              {
                title: "A field",
                description: "Only shown while the switch is on.",
                nested: true,
                controlId: "gallery-name",
              },
              () =>
                h(ui.BaseInput, {
                  id: "gallery-name",
                  modelValue: name.value,
                  disabled: !on.value,
                  "onUpdate:modelValue": (value) => (name.value = value ?? ""),
                }),
            ),
          ]),
        ),
        demo(
          "BaseCollapsible",
          h(
            ui.BaseCollapsible,
            {
              modelValue: open.value,
              "onUpdate:modelValue": (value) => (open.value = value),
              onToggle: (value) => note("ok", `collapsible ${value ? "opened" : "closed"}`),
            },
            {
              summary: () => "Open in place",
              default: () =>
                h("p", { class: "text-secondary" }, "The content stays mounted while closed."),
            },
          ),
        ),
      ];
    },
  };

  const Lists = {
    setup() {
      const current = ref("b");
      const rows = reactive([
        { id: "a", label: "First row" },
        { id: "b", label: "Second row" },
        { id: "c", label: "Unavailable row", disabled: true, title: "Why it is unavailable" },
        { id: "d", label: "Fourth row" },
      ]);
      const menu = reactive({ open: false, x: 0, y: 0 });
      const items = [
        { id: "open", label: "Open" },
        { id: "rename", label: "Rename", disabledReason: "Nothing to rename here." },
        { id: "delete", label: "Delete", danger: true },
      ];
      const colour = ref("#3a7bd5");
      const picker = ref(false);
      const swatch = ref(null);
      const groups = ref([
        { id: "one", tokens: ["--unknown-flag"] },
        { id: "two", tokens: ["--other", "value"] },
      ]);
      const openMenu = (event) => {
        event.preventDefault();
        Object.assign(menu, { open: true, x: event.clientX, y: event.clientY });
      };
      return () => [
        demo(
          "NavList (arrow keys; hover a row for its action) and ContextMenu (right-click a row)",
          h("nav", { "aria-label": "Rows", onContextmenu: openMenu }, [
            h(
              ui.NavList,
              {
                items: rows,
                current: current.value,
                semantics: "navigation",
                onSelect: (id) => {
                  current.value = id;
                  note("ok", `nav row ${id} selected`);
                },
              },
              {
                actions: ({ item, tabbable }) =>
                  h(
                    "button",
                    {
                      class: "btn btn-subtle btn-icon btn-sm hover-reveal",
                      type: "button",
                      tabindex: tabbable ? 0 : -1,
                      "aria-label": `Remove ${item.label}`,
                      title: `Remove ${item.label}`,
                      onClick: () => {
                        rows.splice(rows.indexOf(item), 1);
                        note("ok", `nav row ${item.id} removed`);
                      },
                    },
                    "×",
                  ),
              },
            ),
            h(ui.ContextMenu, {
              open: menu.open,
              items,
              x: menu.x,
              y: menu.y,
              onSelect: (id) => note("ok", `context menu chose ${id}`),
              onClose: () => (menu.open = false),
            }),
          ]),
        ),
        demo(
          "BaseColorPickerPopover",
          h("div", { class: "page__row" }, [
            h(
              "button",
              {
                ref: swatch,
                class: "btn",
                type: "button",
                "aria-expanded": picker.value,
                onClick: () => (picker.value = !picker.value),
              },
              `Colour ${colour.value}`,
            ),
            h("span", { class: "gallery__swatch", style: { background: colour.value } }),
            h(ui.BaseColorPickerPopover, {
              open: picker.value,
              anchor: swatch.value,
              modelValue: colour.value,
              label: "Colour",
              fieldLabel: "Saturation and brightness",
              hueLabel: "Hue",
              hexLabel: "Hex",
              "onUpdate:modelValue": (value) => (colour.value = value),
              onCommit: (value) => note("ok", `colour committed ${value}`),
              onClose: () => (picker.value = false),
            }),
          ]),
        ),
        demo(
          "RemovableTokenGroups",
          h("div", { class: "gallery__column" }, [
            h(ui.RemovableTokenGroups, {
              groups: groups.value,
              title: "Arguments the WebUI does not know",
              description: "Each row leaves alone; the bar closes after the last.",
              removeLabel: "Remove",
              onRemove: (id) => {
                groups.value = groups.value.filter((group) => group.id !== id);
                note("ok", `token group ${id} removed`);
              },
            }),
            h(
              "button",
              {
                class: "btn btn-sm gallery__start",
                type: "button",
                onClick: () => (groups.value = [{ id: `g${Date.now()}`, tokens: ["--again"] }]),
              },
              "Add a group",
            ),
          ]),
        ),
      ];
    },
  };

  const Status = {
    setup() {
      const state = ref("ready");
      const copied = ref(false);
      const extra = ref(false);
      const entries = ref([]);
      let count = 0;
      const load = (next) => {
        state.value = "loading";
        setTimeout(() => (state.value = next), 1200);
      };
      const report = (kind) => {
        count += 1;
        const id = `e${count}`;
        entries.value = [
          ...entries.value,
          {
            id,
            kind,
            label: `${kind} ${count}`,
            message: kind === "progress" ? "Step 2 of 5" : "What happened, in a line.",
            progress: kind === "progress" ? 40 : undefined,
            dismissible: kind !== "progress",
            interactive: kind === "progress",
            actionTitle: "Open",
            lifetime: kind === "success" ? "toast" : undefined,
          },
        ];
      };
      const dismiss = (id) => {
        entries.value = entries.value.filter((entry) => entry.id !== id);
        note("ok", `status card ${id} dismissed`);
      };
      const stateButton = (label, run) =>
        h("button", { class: "btn btn-sm", type: "button", onClick: run }, label);
      return () => [
        demo(
          "AsyncRegion, LoadingState, EmptyState",
          h("div", { class: "gallery__column" }, [
            h("div", { class: "page__row" }, [
              stateButton("Load, then content", () => load("ready")),
              stateButton("Load, then empty", () => load("empty")),
              stateButton("Load, then error", () => load("error")),
            ]),
            h(
              ui.AsyncRegion,
              { class: "gallery__region", state: state.value, loadingText: "Loading…" },
              {
                default: () => h("p", "The content, which faded in where the spinner was."),
                empty: () => h(ui.EmptyState, { text: "Nothing here yet." }),
                error: () => h(ui.EmptyState, { text: "It could not load.", tone: "danger" }),
              },
            ),
          ]),
        ),
        demo(
          "IconSwap, ToolbarSlot",
          h("div", { class: "page__row gallery__toolbar" }, [
            h(
              "button",
              {
                class: "btn btn-icon",
                type: "button",
                "aria-label": "Copy",
                onClick: () => {
                  copied.value = true;
                  setTimeout(() => (copied.value = false), 1500);
                },
              },
              h(ui.IconSwap, { swapKey: copied.value ? "done" : "copy" }, () =>
                copied.value ? h(Check, { size: 16 }) : h(Copy, { size: 16 }),
              ),
            ),
            h(ui.ToolbarSlot, { when: extra.value }, () =>
              h("button", { class: "btn", type: "button" }, "Sometimes here"),
            ),
            h(
              "button",
              { class: "btn", type: "button", onClick: () => (extra.value = !extra.value) },
              extra.value ? "Take the control away" : "Bring a control in",
            ),
          ]),
        ),
        demo(
          "InfoBarDetails",
          h(ui.InfoBar, { severity: "error", title: "It failed" }, () => [
            "The message says what failed.",
            h(ui.InfoBarDetails, { text: "error: the full text\n  at a line\n  at another line" }),
          ]),
        ),
        demo(
          "CornerStatusStack (docked to this box's corner; add five to fold)",
          h("div", { class: "gallery__corner" }, [
            h("div", { class: "page__row" }, [
              stateButton("Progress", () => report("progress")),
              stateButton("Success (leaves)", () => report("success")),
              stateButton("Info", () => report("info")),
              stateButton("Failure (stays)", () => report("failure")),
            ]),
            h(ui.CornerStatusStack, {
              entries: entries.value,
              dismissLabel: "Dismiss",
              onDismiss: dismiss,
              onOpen: (id) => note("ok", `status card ${id} opened`),
            }),
          ]),
        ),
      ];
    },
  };

  const Forms = {
    setup() {
      const values = reactive({
        name: "",
        mode: "fast",
        steps: 20,
        cache: false,
        cacheDir: null,
        notes: "",
      });
      const single = ref(null);
      const t = strings();
      return () => [
        demo(
          "SchemaFormFields (Cache enables the folder; Exact shows Notes)",
          h("div", { class: "form-grid" }, [
            h(ui.SchemaFormFields, {
              fields: FIELDS,
              modelValue: values,
              "onUpdate:modelValue": (next) => Object.assign(values, next),
            }),
          ]),
        ),
        h("pre", { class: "mono gallery__values" }, JSON.stringify(values)),
        demo(
          "SchemaFieldControl (a nullable boolean, alone)",
          h(ui.FormField, { label: "Tri-state" }, ({ controlId }) =>
            h(ui.SchemaFieldControl, {
              id: controlId,
              label: "Tri-state",
              field: {
                key: "tri",
                kind: "boolean",
                nullable: true,
                label: literal("Tri-state", "三态"),
              },
              modelValue: single.value,
              "onUpdate:modelValue": (value) => (single.value = value),
              onCommit: (reason) =>
                note("ok", `schema control committed (${reason}): ${single.value}`),
            }),
          ),
        ),
        demo(
          "MarkdownDocument (the link reaches the page's openLink; Copy may be refused in a frame)",
          h(ui.MarkdownDocument, {
            source: MARKDOWN,
            copyLabel: "Copy",
            copiedLabel: `Copied (${t.locale()})`,
          }),
        ),
      ];
    },
  };

  const TABS = [
    { value: "structure", label: "Structure", panel: Structure },
    { value: "lists", label: "Lists and menus", panel: Lists },
    { value: "status", label: "Status", panel: Status },
    { value: "forms", label: "Forms and text", panel: Forms },
  ];

  return {
    setup() {
      const tab = ref("structure");
      return () => [
        // Once for the page: every `title` in it is drawn as the application's bubble.
        h(ui.NativeTooltipHost),
        h(ui.BaseTabs, {
          label: "More components",
          modelValue: tab.value,
          items: TABS,
          "onUpdate:modelValue": (value) => {
            tab.value = value;
            note("ok", `gallery ${value}`);
          },
        }),
        h(
          "div",
          { class: "gallery__panel", key: tab.value },
          h(TABS.find((each) => each.value === tab.value).panel),
        ),
      ];
    },
  };
}
