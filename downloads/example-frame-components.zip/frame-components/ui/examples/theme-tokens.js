export const example = {
  id: "theme-tokens",
  title: { en: "Inherited theme and local overrides", zh: "继承主题与局部覆盖" },
  description: {
    en: "Inspect the host's current light/dark theme, accent, surface opacity and reduced-motion preference; override only this sample's swatch.",
    zh: "查看宿主当前浅色／深色主题、强调色、表面透明度和减少动态效果偏好；覆盖仅作用于示例色块。",
  },
  apis: ["prefersReducedMotion"],
  tokens: ["--accent-fill", "--surface-alpha"],
};

/**
 * @param {typeof import('vue')} vue
 * @param {typeof import('../../sdk/ui/ui')} ui
 * @param {(status: string, message: string) => void} note
 */
export function createExample(vue, ui, note) {
  const { h, ref, onMounted, onBeforeUnmount } = vue;
  return {
    setup() {
      const local = ref(false);
      const snapshot = ref("");
      const root = document.documentElement;
      const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
      function read() {
        const style = getComputedStyle(root);
        snapshot.value = `${root.dataset.theme ?? "host default"}; accent=${style.getPropertyValue("--accent-fill").trim()}; surface=${style.getPropertyValue("--surface-alpha").trim()}; reduced=${ui.prefersReducedMotion()}`;
      }
      const observer = new MutationObserver(read);
      onMounted(() => {
        read();
        observer.observe(root, { attributes: true, attributeFilter: ["style", "data-theme"] });
        preference.addEventListener("change", read);
      });
      onBeforeUnmount(() => {
        observer.disconnect();
        preference.removeEventListener("change", read);
      });
      return () =>
        h("section", { class: "surface-card", "data-example": example.id }, [
          h("p", { "data-theme-snapshot": "" }, snapshot.value),
          h(
            "button",
            {
              class: "btn",
              onClick() {
                local.value = !local.value;
                note("ok", local.value ? "local override" : "inherited tokens");
              },
            },
            "Toggle local override",
          ),
          h(
            "div",
            {
              "data-swatch": "",
              style: {
                ...(local.value ? { "--accent-fill": "#75baff", "--surface-alpha": "45%" } : {}),
                background:
                  "color-mix(in srgb, var(--accent-fill) var(--surface-alpha), transparent)",
                padding: "16px",
                borderRadius: "8px",
              },
            },
            local.value ? "Local blue / 45%" : "Inherited accent / surface opacity",
          ),
          h(
            "p",
            "Change appearance in the host to compare light/dark inheritance. This button changes only the swatch; it never writes host settings.",
          ),
        ]);
    },
  };
}
