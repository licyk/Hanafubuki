export const example = {
  id: "deferred-expand",
  title: { en: "Deferred presence and expanding space", zh: "延迟卸载与展开空间" },
  description: {
    en: "Keep content while it leaves, release it on after-leave, and share the gap hooks with the expand transition.",
    zh: "离场时保留内容，after-leave 后释放，并让间距钩子与展开过渡共同工作。",
  },
  apis: ["useDeferredPresence", "expandGapHooks"],
  tokens: ["--motion-grow", "--motion-shrink"],
};

/**
 * @param {typeof import('vue')} vue
 * @param {typeof import('../../sdk/ui/ui')} ui
 * @param {(status: string, message: string) => void} note
 */
export function createExample(vue, ui, note) {
  const { h, ref, Transition } = vue;
  return {
    setup() {
      const value = ref(/** @type {string | null} */ (null));
      const presence = ui.useDeferredPresence(() => value.value);
      return () =>
        h("section", { class: "surface-card", "data-example": example.id }, [
          h(
            "button",
            {
              class: "btn",
              onClick() {
                value.value = value.value ? null : "Content retained through its exit";
                note("ok", value.value ? "opened" : "closing");
              },
            },
            "Toggle details",
          ),
          h("div", { style: { display: "flex", flexDirection: "column", gap: "12px" } }, [
            h("p", "The surrounding rows keep their spacing."),
            presence.present
              ? h(
                  Transition,
                  {
                    name: "expand",
                    appear: true,
                    ...ui.expandGapHooks,
                    /** @param {Element} element */
                    onAfterLeave(element) {
                      ui.expandGapHooks.onAfterLeave(element);
                      presence.closed();
                      note("ok", "closed and released");
                    },
                  },
                  {
                    default: () =>
                      presence.open
                        ? h("div", { class: "expand-region" }, [
                            h("div", { class: "expand-clip" }, presence.value ?? ""),
                          ])
                        : null,
                  },
                )
              : null,
            h("p", "The next row follows the expanded space."),
          ]),
        ]);
    },
  };
}
