export const example = {
  id: "flip-list",
  title: { en: "Reorder and persistent indicator", zh: "重排与持续指示器" },
  description: {
    en: "Capture before changing order, play after rendering, and cancel owned travel on unmount. Reduced motion keeps the new order without travel.",
    zh: "更新前捕获位置，渲染后播放位移，卸载时取消自身动画。减少动态效果时保留新顺序但不位移。",
  },
  apis: [
    "captureLayout",
    "playFlip",
    "settle",
    "usePersistentIndicator",
    "offsetWithin",
    "motionTiming",
    "motionDurationMs",
    "prefersReducedMotion",
  ],
  tokens: ["--motion-indicator"],
};

/**
 * @param {typeof import('vue')} vue
 * @param {typeof import('../../sdk/ui/ui')} ui
 * @param {(status: string, message: string) => void} note
 */
export function createExample(vue, ui, note) {
  const { h, ref, nextTick, onMounted, onBeforeUnmount } = vue;
  return {
    setup() {
      const items = ref(["Alpha", "Beta", "Gamma"]);
      const selected = ref("Alpha");
      const list = ref(/** @type {HTMLElement | null} */ (null));
      const indicator = ui.usePersistentIndicator();
      const rows = () => [...(list.value?.querySelectorAll("button") ?? [])];
      /** @param {boolean} travel */
      function mark(travel) {
        const target = rows().find((row) => row.textContent === selected.value);
        indicator.moveTo(
          target && list.value
            ? { ...ui.offsetWithin(target, list.value), width: target.offsetWidth }
            : null,
          travel,
        );
      }
      async function reverse() {
        const capture = ui.captureLayout(rows());
        items.value = [...items.value].reverse();
        await nextTick();
        if (!list.value) return;
        ui.playFlip(capture, rows());
        mark(false);
        note(
          "ok",
          `reordered; reduced=${ui.prefersReducedMotion()}; duration=${ui.motionDurationMs("--motion-indicator")}; easing=${ui.motionTiming("--motion-indicator").easing}`,
        );
      }
      onMounted(() => mark(false));
      onBeforeUnmount(() => rows().forEach(ui.settle));
      return () =>
        h("section", { class: "surface-card", "data-example": example.id }, [
          h("button", { class: "btn", onClick: reverse }, "Reverse rows"),
          h(
            "div",
            {
              ref: list,
              style: { position: "relative", display: "flex", flexDirection: "column" },
            },
            [
              ...items.value.map((item) =>
                h(
                  "button",
                  {
                    key: item,
                    class: "btn btn-subtle",
                    "aria-pressed": selected.value === item,
                    onClick() {
                      selected.value = item;
                      mark(true);
                      note("ok", `selected ${item}`);
                    },
                  },
                  item,
                ),
              ),
              indicator.placed.value
                ? h("span", {
                    "data-indicator": "",
                    style: {
                      position: "absolute",
                      top: "0",
                      left: "0",
                      height: "2px",
                      background: "var(--accent-fill)",
                      pointerEvents: "none",
                      ...indicator.style.value,
                    },
                  })
                : null,
            ],
          ),
        ]);
    },
  };
}
