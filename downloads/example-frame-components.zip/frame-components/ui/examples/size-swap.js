export const example = {
  id: "size-swap",
  classes: ["lateral-host"],
  title: { en: "Directional size swap", zh: "方向切换与尺寸跟随" },
  description: {
    en: "A local panel follows a directional content swap; leaving content is lifted out of flow.",
    zh: "局部面板跟随内容切换改变高度，离场内容先脱离布局。",
  },
  apis: ["useSizeFollow", "useDirectionalTransition", "liftLeaving", "liftLeavingAt"],
  tokens: ["--motion-grow", "--motion-shrink"],
};

/**
 * @param {typeof import('vue')} vue
 * @param {typeof import('../../sdk/ui/ui')} ui
 * @param {(status: string, message: string) => void} note
 */
export function createExample(vue, ui, note) {
  const { h, ref, Transition } = vue;
  return {
    setup() {
      const active = ref("short");
      const box = ref(/** @type {HTMLElement | null} */ (null));
      const direction = ui.useDirectionalTransition(
        () => active.value,
        () => ["short", "long"],
        "lateral",
      );
      ui.useSizeFollow(() => box.value, active);
      return () =>
        h("section", { class: "surface-card", "data-example": example.id }, [
          h(
            "button",
            {
              class: "btn",
              onClick() {
                active.value = active.value === "short" ? "long" : "short";
                note("ok", `size swap: ${active.value}`);
              },
            },
            "Swap content",
          ),
          h(
            "div",
            {
              ref: box,
              class: "lateral-host",
              style: { position: "relative" },
            },
            [
              h(
                Transition,
                {
                  name: direction.value,
                  onBeforeLeave:
                    direction.value === "lateral-backward"
                      ? ui.liftLeavingAt({ horizontal: "right" })
                      : ui.liftLeaving,
                },
                {
                  default: () =>
                    h(
                      "div",
                      { key: active.value, "data-panel": active.value },
                      active.value === "short"
                        ? "One line."
                        : [
                            h("p", "A longer panel."),
                            h("p", "The container follows its natural height."),
                            h("p", "No window authority is needed."),
                          ],
                    ),
                },
              ),
            ],
          ),
        ]);
    },
  };
}
